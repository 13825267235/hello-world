<?php
namespace Api\Controller;
use Think\Controller;

class ApiBasicController extends Controller{

    protected $userInfo=array();
//    private $apiBasicService;
//    private $AppID = "495431347@qq.com";
//    private $AppSecret = "wuyi^.com";
    private $infoConfig = array(   //信息代码配置
        "10001" =>  "您是授权用户，通过验证。",
        "10002" =>  "非法用户，验证未通过。",
        "10003" =>  "传入的数据为空。",
        "10004" =>  "Token获取失败。",
        "10005" =>  "Token获取成功。",
        "10006" =>  "Token已过期。",
        "10007" =>  "信息获取失败！",
        "10008" =>  "信息获取成功！",
        "10009" =>  "数据不合法!",
        "10010" =>  "登陆成功！",
        "10011" =>  "登陆失败！",
        "10013" =>  "请先登录帐号！",
        "10012" =>  "账号已被注销！"
    );
    public $time = ''; //当前时间戳
    public function __construct()
    {
        parent::__construct();
        //验证token
        $token = I('post.token');
        if(empty($token)){
            echo $this->returnErrorInfo(array("messageCode"=>"10013"));
            exit;
        }else{
            if(!preg_match("/^[a-z0-9]{32}$/", $token)){
                echo $this->returnErrorInfo(array("customMessage" =>"非法token!"));
                exit;
            }
            $model=M('UserToken');
            $result=$model->where(array('token'=>$token))->find();
            $time=time()-$result['create_time'];//过期时间

            if(empty($result) || $time>(86400*15)){//15天过期
                echo $this->returnErrorInfo(array("messageCode"=>"10013",'code'=>20));
                exit;
            }

            $userModel=M('User');
            $user=$userModel->where('id='.$result['uid'])->find();
            if($user['enable']==1){
                echo $this->returnErrorInfo(array("customMessage"=>"帐号被禁止登录，请联系客服",'code'=>30));
                exit;
            }
            $this->userInfo=$result;

       }

    }

    /**
     *生成token
     * $id为用户Id
     */
    public function proToken($name){
        $token = md5($name. strval(time()) . strval(rand(0,999999)));
        return $token;
    }

    //返回成功的信息
    /**
     *  @$parameter：    传递的参数，为数组的形式。
     *                  例如：array("messageCode"=>"100010","customMessage"=>"自定义提示信息。","data"=>data);
     *                  参数顺序不分先后，参数可全部为空，也可全部传入或选择性传入。
     *  @$messageCode：  返回提示信息的代码，$infoConfig配置数组的信息提示代码。可不传入
     *  @$customMessage：  自定义提示信息。可不传入
     *  @$data：  返回的数据。可不传入
     */
    public function returnSuccessInfo($parameter = array())
    {
        $message = isset($parameter["messageCode"]) ? $this->infoConfig[$parameter["messageCode"]] : "";
        $code = isset($parameter["code"]) ? $parameter["code"] : 1;
        $customMessage = isset($parameter["customMessage"]) ? $parameter["customMessage"] : "";
        $ramete["data"] = (object)array();
        $data = isset($parameter["data"]) ? $parameter["data"] : $ramete["data"];
        $message = $message . $customMessage;
        $result = array(
            "code" => $code,
            "message" => $message,
            "data" => $data
        );
        return str_replace("\\/","/",json_encode($result,JSON_UNESCAPED_UNICODE));
    }

    //返回失败的信息
    /**
     *  @$parameter：    传递的参数，为数组的形式。
     *                  例如：array("messageCode"=>"100010","customMessage"=>"自定义提示信息。","data"=>data);
     *                  参数顺序不分先后，参数可全部为空，也可全部传入或选择性传入。
     *  @$messageCode：  返回提示信息的代码，$infoConfig配置数组的信息提示代码。可不传入
     *  @$customMessage：  自定义提示信息。可不传入
     *  @$data：  返回的数据。可不传入
     */
    public function returnErrorInfo($parameter = array())
    {
        $message = isset($parameter["messageCode"]) ? $this->infoConfig[$parameter["messageCode"]] : "";
        $code = isset($parameter["code"]) ? $parameter["code"] : 0;
        $customMessage = isset($parameter["customMessage"]) ? $parameter["customMessage"] : "";
        $ramete["data"] = (object)array();
        $data = isset($parameter["data"]) ? $parameter["data"] : $ramete["data"];
        $message = $message . $customMessage;
        $result = array(
            "code" => $code,
            "message" => $message,
            "data" => $data
        );

        return str_replace("\\/","/",json_encode($result,JSON_UNESCAPED_UNICODE));
    }

    //三维数组降二维
    public function changedimension($array){
        //循环遍历三维数组$arr3
        foreach($array as $value){
            foreach($value as $v){
                $arr2[]=$v;
            }
        }
        unset($result,$value,$v);
        return $arr2;
    }
    /*****************银行代码*********************/
    public function bankcode($bank){
        if($bank=="招商银行"){
            return "1012";
        }elseif($bank=="工商银行"){
            return "1001";
        }elseif($bank=="农业银行"){
            return "1002";
        }elseif($bank=="中国银行"){
            return "1003";
        }elseif($bank=="建设银行"){
            return "1004";
        }elseif($bank=="交通银行"){
            return "1005";
        }elseif($bank=="中信银行"){
            return "1007";
        }elseif($bank=="光大银行"){
            return "1008";
        }elseif($bank=="邮政储蓄银行"){
            return "1006";
        }elseif($bank=="平安银行"){
            return "1011";
        }elseif($bank=="浦发银行"){
            return "1014";
        }elseif($bank=="民生银行"){
            return "1010";
        }elseif($bank=="兴业银行"){
            return "1013";
        }elseif($bank=="华夏银行"){
            return "1019";
        }else {
            return "1012";
        }

    }
}