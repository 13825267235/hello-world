<?php
namespace Api\Controller;

class GainController extends ApiBasicController{

    //构造方法
    public function __construct(){
        parent::__construct();
    }
    /**********我的收益***********/
    public function mygain(){
        $userInfo=$this->userInfo;
        //可分润
        $interestModel=M('Interest');
        $interest=$interestModel->field('SUM(money) as money')->where('state=0 and type=1 and uid='.$userInfo['uid'])->find();
        //推广收益
        $spreadModel=M('Spread');
        $spread=$spreadModel->field('SUM(money) as money')->where('state=0 and uid='.$userInfo['uid'])->find();
        $data['fenrun']=($interest['money']=='')? 0 : $interest['money'];
        $data['tuiguang']=($spread['money']=='')? 0 : $spread['money'];
        $data['all_money']=$data['fenrun']+$data['tuiguang'];
        echo $this->returnSuccessInfo(array("data"=>$data));
        exit;
    }
    //分润提现页面
    public function frcashindex(){
        $userInfo=$this->userInfo;
        $userBankModel=M('UserBank');

        $userBank=$userBankModel->field('id as ids,bank_name,account')->where('type=1 and uid='.$userInfo['uid'])->find();
        if(!$userBank){
            echo $this->returnErrorInfo(array("customMessage"=>"请先绑定银行"));
            exit;
        }else{
            $length=strlen($userBank['account']);
            $userBank['account']=substr($userBank['account'],($length-4),$length);
            echo $this->returnSuccessInfo(array('data'=>$userBank));
            exit;
        }

    }
    //分润提现
    public function frcash(){
        $userInfo=$this->userInfo;
        //可分润
        $interestModel=M('Interest');
        $interest=$interestModel->field('SUM(money) as money')->where('state=0 and type=1 and uid='.$userInfo['uid'])->find();
        $interest['money']=($interest['money']=='')? 0 : $interest['money'];
        if($interest==0){
            echo $this->returnErrorInfo(array("customMessage"=>"无可提现金额"));
            exit;
        }
        $result=true;//模拟提现成功
        if($result){
            $resultOne=$interestModel->where('uid='.$userInfo['uid'])->save(array('state'=>1));
            if($resultOne){
                echo $this->returnSuccessInfo(array("customMessage"=>"提现成功"));
                exit;
            }else{
                echo $this->returnErrorInfo(array("customMessage"=>"提现失败"));
                exit;
            }
        }
    }
    //收益详情
    public function gainlist(){
        $userInfo=$this->userInfo;
        $offset = (I('offset') == null) ? 1 : intval(I('offset'));
        $limit = (I('limit') == null) ? 10 :  intval(I('limit'));
        $offset = $offset*$limit-$limit;
        $type=intval(I('type'));

        $gainModel=M('Interest');
        $array=$gainModel->field('create_time,money')->where('uid='.$userInfo['uid'].' and gain_type='.$type)->limit($limit,$offset)->order('id desc')->select();
        $num=$gainModel->field('create_time,money')->where('uid='.$userInfo['uid'].' and gain_type='.$type)->count();

        foreach($array as $k=>$v){
            $array[$k]['create_time']=date('Y-m-d H:i:s',$v['create_time']);
        }
        $res['page']=ceil($num/$limit);
        $res['data']=$array;
        echo $this->returnSuccessInfo(array("data"=>$res));
        exit;
    }
    //推广提现
    public function spcash(){
        $userInfo=$this->userInfo;
        //可分润
        $spreadModel=M('Spread');
        $spread=$spreadModel->field('SUM(money) as money')->where('state=0 and uid='.$userInfo['uid'])->find();
        $spread['money']=($spread['money']=='')? 0 : $spread['money'];
        if($spread['money']==0){
            echo $this->returnErrorInfo(array("customMessage"=>"提现金额需大于0"));
            exit;
        }
        $result=true;//模拟提现成功
        if($result){
            $resultOne=$spreadModel->where('uid='.$userInfo['uid'])->save(array('state'=>1));
            if($resultOne){
                echo $this->returnSuccessInfo(array("customMessage"=>"提现成功"));
                exit;
            }else{
                echo $this->returnErrorInfo(array("customMessage"=>"提现失败"));
                exit;
            }
        }


    }
    //推广收益详情
    public function splist(){
        $userInfo=$this->userInfo;
        $offset = (I('offset') == null) ? 1 : intval(I('offset'));
        $limit = (I('limit') == null) ? 10 :  intval(I('limit'));
        $offset = $offset*$limit-$limit;

        $gainModel=M('Spread');
        $array=$gainModel->field('create_time,money')->where('uid='.$userInfo['uid'])->limit($limit,$offset)->order('id desc')->select();
        $num=$gainModel->field('create_time,money')->where('uid='.$userInfo['uid'])->count();

        foreach($array as $k=>$v){
            $array[$k]['create_time']=date('Y-m-d H:i:s',$v['create_time']);
        }
        $res['page']=ceil($num/$limit);
        $res['data']=$array;
        echo $this->returnSuccessInfo(array("data"=>$res));
        exit;
    }
    //提现详情
    public function cashlist(){
        $userInfo=$this->userInfo;
        $offset = (I('offset') == null) ? 1 : intval(I('offset'));
        $limit = (I('limit') == null) ? 10 :  intval(I('limit'));
        $offset = $offset*$limit-$limit;
        $type=intval(I('type'));

        $gainModel=M('UserCash');
        $array=$gainModel->field('create_time,amount,order_number,state')->where('uid='.$userInfo['uid'].' and type='.$type)->limit($limit,$offset)->order('id desc')->select();
        $num=$gainModel->field('create_time,amount,order_number,state')->where('uid='.$userInfo['uid'].' and type='.$type)->count();
        foreach ($array as $k=>$v){
            $array[$k]['create_time']=date('Y-m-d H:i:s',$v['create_time']);
        }

        $res['page']=ceil($num/$limit);
        $res['data']=$array;
        echo $this->returnSuccessInfo(array("data"=>$res));
        exit;
    }
    /*********我的代理商**********/
    public function myagents(){
        $userInfo=$this->userInfo;
        $userModel=M('User');
        //大掌柜
        $oneChild=$userModel->field('username,grade')->where(array('parent_id'=>$userInfo['username']))->select();
        foreach($oneChild as $k=>$v){
            $towChilds=$userModel->field('username,grade')->where(array('parent_id'=>$v['username']))->select();
            if($towChilds){
                $towChild[]=$towChilds;
            }
        }
        //2掌柜
        $towChild=$this->changedimension($towChild);
        //3掌柜
        foreach($towChild as $k=>$v){
            $threeChilds=$userModel->field('username,grade')->where(array('parent_id'=>$v['username']))->select();
            if($threeChilds){
                $threeChild[]=$threeChilds;
            }
        }
        $threeChild=$this->changedimension($threeChild);

        $data[1]=0;
        $data[2]=0;
        $data[3]=0;
        $data[4]=0;
        $data[5]=0;
        $data[6]=0;
        $data[7]=0;
        $gradeModel=M('Grade');
        $grade=$gradeModel->field('grade,grade_name')->select();
        /****计算各分层人数****/
        foreach($oneChild as $k=>$v){
            foreach($grade as $key=>$val){
                if($v['grade']==$val['grade']){
                    $data[$val['grade']]++;
                }
            }
//            if($v['grade']==1){
//                $data[1]++;
//            }else if($v['grade']==2){
//                $data[2]++;
//            }else if($v['grade']==3){
//                $data[3]++;
//            }else if($v['grade']==4){
//                $data[4]++;
//            } else if($v['grade']==5){
//                $data[5]++;
//            } else if($v['grade']==6){
//                $data[6]++;
//            }else if($v['grade']==7){
//                $data[7]++;
//            }
        }
        foreach($towChild as $k=>$v){
//            if($v['grade']==1){
//                $data[1]++;
//            }else if($v['grade']==2){
//                $data[2]++;
//            }else if($v['grade']==3){
//                $data[3]++;
//            }else if($v['grade']==4){
//                $data[4]++;
//            } else if($v['grade']==5){
//                $data[5]++;
//            } else if($v['grade']==6){
//                $data[6]++;
//            }else if($v['grade']==7){
//                $data[7]++;
//            }
            foreach($grade as $key=>$val){
                if($v['grade']==$val['grade']){
                    $data[$val['grade']]++;
                }
            }
        }
        foreach($threeChild as $k=>$v){
//            if($v['grade']==1){
//                $data[1]++;
//            }else if($v['grade']==2){
//                $data[2]++;
//            }else if($v['grade']==3){
//                $data[3]++;
//            }else if($v['grade']==4){
//                $data[4]++;
//            } else if($v['grade']==5){
//                $data[5]++;
//            } else if($v['grade']==6){
//                $data[6]++;
//            }else if($v['grade']==7){
//                $data[7]++;
//            }
            foreach($grade as $key=>$val){
                if($v['grade']==$val['grade']){
                    $data[$val['grade']]++;
                }
            }
        }
        $datas['s1']=$data[1];
        $datas['s2']=$data[2];
        $datas['s3']=$data[3];
        $datas['s4']=$data[4];
        $datas['s5']=$data[5];
        $datas['s6']=$data[6];
        $datas['s7']=$data[7];
        echo $this->returnSuccessInfo(array("customMessage"=>"","data"=>$datas));
        exit;
    }
    //四角色
    public function agents(){
        $type=intval(I('post.type'));
        $userInfo=$this->userInfo;
        $userModel=M('User');
        //大掌柜
        $oneChild=$userModel->field('username,grade,id')->where(array('parent_id'=>$userInfo['username']))->select();
        foreach($oneChild as $k=>$v){
            $towChilds=$userModel->field('username,grade,id')->where(array('parent_id'=>$v['username']))->select();
            if($towChilds){
                $towChild[]=$towChilds;
            }
        }
        //2掌柜
        $towChild=$this->changedimension($towChild);
        //3掌柜
        foreach($towChild as $k=>$v){
            $threeChilds=$userModel->field('username,grade,id')->where(array('parent_id'=>$v['username']))->select();
            if($threeChilds){
                $threeChild[]=$threeChilds;
            }
        }
        $threeChild=$this->changedimension($threeChild);

        $data[]=$oneChild;
        $data[]=$towChild;
        $data[]=$threeChild;
        $data=$this->changedimension($data);

        $gradeModel=M('Grade');
        $grade=$gradeModel->select();
        $array=array();
        foreach($data as $k=>$v){
            foreach($grade as $key=>$val){
                if($v['grade']==$val['grade']){
                    $arr[$val['grade']][]['username']=$v['username'];
                }
                if($type==$val['grade']){
                    $array=$arr[$val['grade']];
                }
            }
//            if($v['grade']==1){
//                $arr[1][]['username']=$v['username'];
//            }else if($v['grade']==2){
//                $arr[2][]['username']=$v['username'];
//            }else if($v['grade']==3){
//                $arr[3][]['username']=$v['username'];
//            }else if($v['grade']==4){
//                $arr[4][]['username']=$v['username'];
//            }
        }

        //用户详情
        $interestModel=M('Interest');
        foreach($array as $k=>$v) {
            $agent = $userModel->field('img_url,id')->where('username=' . $v['username'])->find();
            $array[$k]['img_url'] = $agent['img_url'];
            $array[$k]['ids'] = $agent['id'];
            $interest=$interestModel->field('SUM(money) as money')->where('type=1 and child_id='.$agent['id'])->select();//分润
            $array[$k]['fenrun']=$interest[0]['money'] ? $interest[0]['money']:0.00;
        }
        echo $this->returnSuccessInfo(array("customMessage"=>"","data"=>array('data'=>$array)));
        exit;

    }
    /*********我的下级*************/
    public  function mychildren(){
        $userInfo=$this->userInfo;
        $userModel=M('User');
        //大掌柜
        $oneChild=$userModel->field('username')->where(array('parent_id'=>$userInfo['username']))->select();
        foreach($oneChild as $k=>$v){
            $towChilds=$userModel->field('username')->where(array('parent_id'=>$v['username']))->select();
            if($towChilds){
                $towChild[]=$towChilds;
            }
        }
        //2掌柜
        $towChild=$this->changedimension($towChild);
        //3掌柜
        foreach($towChild as $k=>$v){
            $threeChilds=$userModel->field('username')->where(array('parent_id'=>$v['username']))->select();
            if($threeChilds){
                $threeChild[]=$threeChilds;
            }
        }
        $threeChild=$this->changedimension($threeChild);
//        $data['one']=$oneChild;
        $data['one_count']=count($oneChild);
//        $data['tow']=$towChild;
        $data['tow_count']=count($towChild);
//        $data['three']=$threeChild;
        $data['three_count']=count($threeChild);
        echo $this->returnSuccessInfo(array("customMessage"=>"","data"=>$data));
        exit;
    }
    //三掌柜接口
    public function childrens(){
        $userInfo=$this->userInfo;
        $userModel=M('User');
        //大掌柜
        $oneChild=$userModel->field('username,img_url,id as ids')->where(array('parent_id'=>$userInfo['username']))->select();
        foreach($oneChild as $k=>$v){
            $towChilds=$userModel->field('username,img_url,id as ids')->where(array('parent_id'=>$v['username']))->select();
            if($towChilds){
                $towChild[]=$towChilds;
            }
        }
        //2掌柜
        $towChild=$this->changedimension($towChild);
        //3掌柜
        foreach($towChild as $k=>$v){
            $threeChilds=$userModel->field('username,img_url,id as ids')->where(array('parent_id'=>$v['username']))->select();
            if($threeChilds){
                $threeChild[]=$threeChilds;
            }
        }
        $threeChild=$this->changedimension($threeChild);
        $data['one']=$oneChild;
//        $data['one_count']=count($oneChild);
        $data['tow']=$towChild;
//        $data['tow_count']=count($towChild);
        $data['three']=$threeChild;
//        $data['three_count']=count($threeChild);
        $type=intval(I('type'));
        $interestModel=M('Interest');
        $array=array();
        if($type==1){
           $array=$data['one'];
        }else if($type==2){
            $array=$data['tow'];
        }else if($type==3){
            $array=$data['three'];
        }
        foreach($array as $k=>$v){
            $interest=$interestModel->field('SUM(money) as money')->where('type=1 and child_id='.$v['ids'])->select();
            $array[$k]['fenrun']=$interest[0]['money'] ? $interest[0]['money']:0.00;
        }
        echo $this->returnSuccessInfo(array("customMessage"=>"","data"=>array('data'=>$array)));
        exit;
    }
    //掌柜详情
    public function childinfo(){
        $id=intval(I('post.id'));
        $userModel=M('User');
        $user=$userModel->field('username,img_url,grade,parent_id,create_time')->where('id='.$id)->find();
        //代理等级
        $gradeModel=M('Grade');
        $grade=$gradeModel->field('grade_name')->where('grade='.$user['grade'])->find();
        $user['grade']=$grade['grade_name'];
        //分润贡献
        $interestModel=M('Interest');
        $interest=$interestModel->field('SUM(money) as money')->where('type=1 and child_id='.$id)->select();
        $user['fenrun']=$interest[0]['money'] ? $interest[0]['money']:0.00;
        //实名认证
        $userBankModel=M('UserBank');
        $userBank=$userBankModel->where('uid='.$id)->find();
        if($userBank){
            $user['rz']=="已认证";
        }else{
            $user['rz']=="未实名";
        }
        $user['create_time']=date('Y-m-d H:i:s',$user['create_time']);
        //本月分润
        $s_time=strtotime(date('Y-m-01', strtotime(date("Y-m-d"))));
        $e_time=strtotime(date('Y-m-d', strtotime("$s_time +1 month -1 day"))." 23:59:59");
        $interestMon=$interestModel->field('SUM(money) as money')->where('type=1 and child_id='.$id.' and create_time>'.$s_time.' and create_time<'.$e_time)->select();
        $user['fenrun_mon']=$interestMon[0]['money'] ? $interestMon[0]['money']:0.00;
        echo $this->returnSuccessInfo(array("customMessage"=>"","data"=>$user));
        exit;
    }
}