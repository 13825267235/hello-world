<?php

namespace Api\Controller;

use Think\Controller;

class HwuController extends Controller {

    public function register() {
        $rer = I('get.rer');
        if (empty($rer) || is_numeric($rer)) {
            $this->assign('rer', $rer);
            $this->display();
        }
    }

    public function download() {
        $this->display();
    }

    /*
     * 信用卡收款异步通知
     */

    public function notifyUrl() {
        $val = I('request.');
//        $str = file_get_contents("php://input");
//        $val = json_decode($str);
        if ($val) {
            file_put_contents('zhanglin_log.txt', $val, FILE_APPEND);
        } else {
            file_put_contents('zhanglin_log.txt', '出错了', FILE_APPEND);
            echo '出错了，没有获取到结果';
        }
    }

    /*     * **********龙虎榜******** */

    public function lhlist() {
        $type = I('post.type');
        if ($type == "day") {//天榜
            $s_time = strtotime(date('Y-m-d', time()));
            $e_time = strtotime(date('Y-m-d', time()) . "23:59:59");
            $nub = 10;
        } else if ($type == "week") {//周榜
            $now = time();    //当时的时间戳
            $number = date("w", $now);  //当时是周几
            $number = $number == 0 ? 7 : $number; //如遇周末,将0换成7
            $diff_day = $number - 1; //求到周一差几天
            $week = date("Y-m-d", $now - ($diff_day * 60 * 60 * 24));

            $s_time = strtotime($week); //周一
            $e_time = (strtotime($week)) + (86400 * 7); //周末
            $nub = 10;
        } else if ($type == "mon") {//月榜
//            $mon=date('Y-m-01', strtotime(date("Y-m-d")));
//            $s_time=strtotime(date('Y-m-01', strtotime(date("Y-m-d"))));;//月头
//            $e_time=date('Y-m-d', strtotime("$mon +1 month -1 day"))." 23:59:59";//月尾
            $s_time = 0;
            $e_time = time();
            $nub = 20;
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "暂无数据"));
            exit;
        }
        $userModel = M('User');
        $children = $userModel
                ->field('parent_id')
                ->where("create_time >" . $s_time . " and create_time<" . $e_time . " and parent_id<>0")
                ->select();
        $childrens = $userModel
                ->field('parent_id')
                ->where("create_time >" . $s_time . " and create_time<" . $e_time . " and parent_id<>0")
                ->group("parent_id")
                ->select();

        if (count($children) == 0) {
            echo $this->returnSuccessInfo(array("customMessage" => "", "data" => array('data' => array())));
            exit;
        }
        //计算人数推荐
        foreach ($childrens as $key => $value) {
            foreach ($children as $k => $v) {
                if ($v['parent_id'] == $value['parent_id']) {
                    $childrens[$key]['people'] ++;
                }
            }
        }
        //推荐人数排序
        $length = count($childrens);
        for ($i = 1; $i < $length; $i++) { //该层循环用来控制每轮 冒出一个数 需要比较的次数
            for ($k = 0; $k < $length - $i; $k++) {
                if ($childrens[$k]['people'] < $childrens[$k + 1]['people']) {
                    $tmp = $childrens[$k + 1]['people'];
                    $childrens[$k + 1]['people'] = $childrens[$k]['people'];
                    $childrens[$k]['people'] = $tmp;
                    $tmps = $childrens[$k + 1]['parent_id'];
                    $childrens[$k + 1]['parent_id'] = $childrens[$k]['parent_id'];
                    $childrens[$k]['parent_id'] = $tmps;
                }
            }
        }
        //输出10和20个用户
        $data = array();
        for ($i = 0; $i < $nub; $i++) {
            $data[$i]['people'] = $childrens[$i]['people'];
            $data[$i]['username'] = $childrens[$i]['parent_id'];
        }
        foreach ($data as $k => $v) {
            if ($v['username'] != NULL) {
                $result = $userModel
                        ->field('a.username,a.img_url,a.grade,grade.grade_name')
                        ->alias('a')
                        ->join("LEFT JOIN __GRADE__ as grade ON a.grade=grade.grade")
                        ->where("a.username=" . $v['username'])
                        ->find();
                $data[$k]['username'] = substr($v['username'], 0, 3) . "****" . substr($v['username'], 8, 11);
                $data[$k]['grade'] = $result['grade_name'];
                $data[$k]['img_url'] = $result['img_url'];
            }
        }
        echo $this->returnSuccessInfo(array("customMessage" => "", "data" => array('data' => $data)));
        exit;
    }

    //龙虎首页
    public function lhlistindex() {
        $day = $this->lh('day');
        $week = $this->lh('week');
        $mon = $this->lh('mon');
        $data['day'] = $day ? $day['0']['img_url'] : null;
        $data['week'] = $week ? $week['0']['img_url'] : null;
        $data['mon'] = $mon ? $mon['0']['img_url'] : null;
        echo $this->returnSuccessInfo(array("customMessage" => "", "data" => $data));
        exit;
    }

    /*     * **********客服电话****** */

    public function webphone() {
        $configModel = M('Config');
        $config = $configModel->select();
        foreach ($config as $k => $v) {
            $array[$v['name']] = $v['value'];
        }
        $data['web_phone'] = $array['web_phone'];
        echo $this->returnSuccessInfo(array("customMessage" => "", "data" => $data));
        exit;
    }

    //二维数组去掉重复值
    function array_unique_fb($array2D) {
        foreach ($array2D as $v) {
            $v = join(',', $v); //降维,也可以用implode,将一维数组转换为用逗号连接的字符串
            $temp[] = $v;
        }
        $temp = array_unique($temp); //去掉重复的字符串,也就是重复的一维数组
        foreach ($temp as $k => $v) {
            $temp[$k] = explode(',', $v); //再将拆开的数组重新组装
        }
        return $temp;
    }

    //龙虎榜
    public function lh($type) {

        if ($type == "day") {//天榜
            $s_time = strtotime(date('Y-m-d', time()));
            $e_time = strtotime(date('Y-m-d', time()) . "23:59:59");
            $nub = 10;
        } else if ($type == "week") {//周榜
            $now = time();    //当时的时间戳
            $number = date("w", $now);  //当时是周几
            $number = $number == 0 ? 7 : $number; //如遇周末,将0换成7
            $diff_day = $number - 1; //求到周一差几天
            $week = date("Y-m-d", $now - ($diff_day * 60 * 60 * 24));

            $s_time = strtotime($week); //周一
            $e_time = (strtotime($week)) + (86400 * 7); //周末
            $nub = 10;
        } else if ($type == "mon") {//月榜
//            $mon=date('Y-m-01', strtotime(date("Y-m-d")));
//            $s_time=strtotime(date('Y-m-01', strtotime(date("Y-m-d"))));;//月头
//            $e_time=date('Y-m-d', strtotime("$mon +1 month -1 day"))." 23:59:59";//月尾
            $s_time = 0;
            $e_time = time();
            $nub = 20;
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "暂无数据"));
            exit;
        }
        $userModel = M('User');
        $children = $userModel
                ->field('parent_id')
                ->where("create_time >" . $s_time . " and create_time<" . $e_time . " and parent_id<>0")
                ->select();
        $childrens = $userModel
                ->field('parent_id')
                ->where("create_time >" . $s_time . " and create_time<" . $e_time . " and parent_id<>0")
                ->group("parent_id")
                ->select();

        if (count($children) == 0) {
            echo $this->returnSuccessInfo(array("customMessage" => "", "data" => array('data' => array())));
            exit;
        }
        //计算人数推荐
        foreach ($childrens as $key => $value) {
            foreach ($children as $k => $v) {
                if ($v['parent_id'] == $value['parent_id']) {
                    $childrens[$key]['people'] ++;
                }
            }
        }
        //推荐人数排序
        $length = count($childrens);
        for ($i = 1; $i < $length; $i++) { //该层循环用来控制每轮 冒出一个数 需要比较的次数
            for ($k = 0; $k < $length - $i; $k++) {
                if ($childrens[$k]['people'] < $childrens[$k + 1]['people']) {
                    $tmp = $childrens[$k + 1]['people'];
                    $childrens[$k + 1]['people'] = $childrens[$k]['people'];
                    $childrens[$k]['people'] = $tmp;
                    $tmps = $childrens[$k + 1]['parent_id'];
                    $childrens[$k + 1]['parent_id'] = $childrens[$k]['parent_id'];
                    $childrens[$k]['parent_id'] = $tmps;
                }
            }
        }
        //输出10和20个用户
        $data = array();
        for ($i = 0; $i < $nub; $i++) {
            $data[$i]['people'] = $childrens[$i]['people'];
            $data[$i]['username'] = $childrens[$i]['parent_id'];
        }
        foreach ($data as $k => $v) {
            if ($v['username'] != NULL) {
                $result = $userModel
                        ->field('a.username,a.img_url,a.grade,grade.grade_name')
                        ->alias('a')
                        ->join("LEFT JOIN __GRADE__ as grade ON a.grade=grade.grade")
                        ->where("a.username=" . $v['username'])
                        ->find();
                $data[$k]['username'] = substr($v['username'], 0, 3) . "****" . substr($v['username'], 8, 11);
                $data[$k]['grade'] = $result['grade_name'];
                $data[$k]['img_url'] = $result['img_url'];
            }
        }
        return $data;
    }

    /**
     *  @$parameter：    传递的参数，为数组的形式。
     *                  例如：array("messageCode"=>"100010","customMessage"=>"自定义提示信息。","data"=>data);
     *                  参数顺序不分先后，参数可全部为空，也可全部传入或选择性传入。
     *  @$messageCode：  返回提示信息的代码，$infoConfig配置数组的信息提示代码。可不传入
     *  @$customMessage：  自定义提示信息。可不传入
     *  @$data：  返回的数据。可不传入
     */
    public function returnSuccessInfo($parameter = array()) {
        $message = isset($parameter["messageCode"]) ? $this->infoConfig[$parameter["messageCode"]] : "";
        $code = isset($parameter["code"]) ? $parameter["code"] : 1;
        $customMessage = isset($parameter["customMessage"]) ? $parameter["customMessage"] : "";
        $ramete["data"] = (object) array();
        $data = isset($parameter["data"]) ? $parameter["data"] : $ramete["data"];
        $message = $message . $customMessage;
        $result = array(
            "code" => $code,
            "message" => $message,
            "data" => $data
        );
        return str_replace("\\/", "/", json_encode($result, JSON_UNESCAPED_UNICODE));
    }

    //返回失败的信息
    /**
     *  @$parameter：    传递的参数，为数组的形式。
     *                  例如：array("messageCode"=>"100010","customMessage"=>"自定义提示信息。","data"=>data);
     *                  参数顺序不分先后，参数可全部为空，也可全部传入或选择性传入。
     *  @$messageCode：  返回提示信息的代码，$infoConfig配置数组的信息提示代码。可不传入
     *  @$customMessage：  自定义提示信息。可不传入
     *  @$data：  返回的数据。可不传入
     */
    public function returnErrorInfo($parameter = array()) {
        $message = isset($parameter["messageCode"]) ? $this->infoConfig[$parameter["messageCode"]] : "";
        $code = isset($parameter["code"]) ? $parameter["code"] : 0;
        $customMessage = isset($parameter["customMessage"]) ? $parameter["customMessage"] : "";
        $ramete["data"] = (object) array();
        $data = isset($parameter["data"]) ? $parameter["data"] : $ramete["data"];
        $message = $message . $customMessage;
        $result = array(
            "code" => $code,
            "message" => $message,
            "data" => $data
        );

        return str_replace("\\/", "/", json_encode($result, JSON_UNESCAPED_UNICODE));
    }

}
