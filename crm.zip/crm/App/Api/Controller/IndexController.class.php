<?php

namespace Api\Controller;

class IndexController extends ApiBasicController {

    public function index() {
        
    }

    /*     * ************app版本检测************* */

    public function edition() {
        $request['app_id'] = I('post.app_id'); //app ID
        $request['server_version'] = I('post.server_version'); //版本号
        $request['equipment'] = I('post.equipment');
        $request['app_id'] = 1; //app ID
        $request['server_version'] = 3; //版本号
        $request['equipment'] = 1;
        $IndexService = new IndexService();
        echo $appVersion = $IndexService->editionService($request);
    }

    /*     * ************还款信用卡列表*************** */

    public function rc() {
        $userInfo = $this->userInfo;
        $rcModel = M('Rc');
        $data = $rcModel
                ->field('id as ids,bank_name,user,nub,cvn,end_time,limit_money,bill_day,end_remoney,status')
                ->where("is_bind=0 and username=" . $userInfo['username'])
                ->select();
        if (count($data) == 0) {
            echo $this->returnErrorInfo(array("customMessage" => "添加信用卡!"));
            exit;
        } else {
            echo $this->returnSuccessInfo(array("customMessage" => "", 'data' => array('data' => $data)));
            exit;
        }
    }

    //还款信用卡添加
    public function rcadd() {

        $userInfo = $this->userInfo;
        $data['user'] = I('post.user');
        $data['nub'] = I('post.nub');
        $data['cvn'] = I('post.cvn');
        $data['end_time'] = I('post.end_time');
        $data['limit_money'] = I('post.limit_money');
        $data['bill_day'] = I('post.bill_day');
        $data['end_remoney'] = I('post.end_remoney');
        $data['phone'] = I('post.phone');
        $data['code'] = I('post.code');
        $data['bank_id'] = intval(I('post.bank_id'));
        $data['bank_name'] = I('post.bank_name');
        if (!preg_match("/^[\x{4e00}-\x{9fa5}]{2,30}$/u", $data['bank_name'])) {
            echo $this->returnErrorInfo(array("customMessage" => "银行格式有误"));
            exit;
        }
        if (!preg_match("/^[\x{4e00}-\x{9fa5}]{2,6}$/u", $data['user'])) {
            echo $this->returnErrorInfo(array("customMessage" => "名字格式有误"));
            exit;
        }
        if (!is_numeric($data['nub'])) {
            echo $this->returnErrorInfo(array("customMessage" => "卡号有误"));
            exit;
        }
        if (!preg_match("/^\d{3}$/u", $data['cvn'])) {
            echo $this->returnErrorInfo(array("customMessage" => "CVN格式有误"));
            exit;
        }
        if (!preg_match("/^\d{4}$/u", $data['end_time'])) {
            echo $this->returnErrorInfo(array("customMessage" => "有效期格式有误"));
            exit;
        }
        if (!preg_match("/^\d{3,10}$/u", $data['limit_money'])) {
            echo $this->returnErrorInfo(array("customMessage" => "卡限额格式有误"));
            exit;
        }
        if (!preg_match("/^\d{1,2}$/u", $data['bill_day']) || $data['bill_day'] > 31 || $data['bill_day'] < 1) {
            echo $this->returnErrorInfo(array("customMessage" => "账单日格式有误"));
            exit;
        }
        if (!preg_match("/^\d{1,2}$/u", $data['end_remoney']) || $data['end_remoney'] > 31 || $data['end_remoney'] < 1) {
            echo $this->returnErrorInfo(array("customMessage" => "最后还款日格式有误"));
            exit;
        }
        if (!preg_match('/^\d{11}$/', $data['phone'])) {
            echo $this->returnErrorInfo(array("customMessage" => "手机号格式有误"));
            exit;
        }
        if (!is_numeric($data['code'])) {
            echo $this->returnErrorInfo(array("customMessage" => "验证码有误"));
            exit;
        }
        //短信验证码
        $smsModel = M('SmsLog');
        $checkSms = $smsModel->where(array('username' => $data['phone'], 'log_type' => 5, 'log_captcha' => $data['code']))->find();
        if (!$checkSms) {
            echo $this->returnErrorInfo(array("customMessage" => "验证码错误!"));
            exit;
        } else {
            if (($checkSms['add_time'] - time()) < -300) {
                echo $this->returnErrorInfo(array("customMessage" => "验证码超时!"));
                exit;
            }
        }

        /*         * **************银行卡四要素验证******************** */
        //获取用户的身份证号
        $user_info = M("user_bank")->field("ic,realname")->where('uid=' . $userInfo['uid'])->find();
        $idcard = $user_info['ic'];

        $realName = new \Common\Check\RealName();
        $rel = $realName->checkId($data['user'], $idcard, $data['nub'], $data['phone']);

        if ($rel['reason']) {
            //其他情况
            echo $this->returnErrorInfo(array("customMessage" => $rel['reason']));
            exit;
        }
        if ($rel['customMessage']) {
            //匹配失败
            if ($user_info['realname'] != $data['user']) {
                echo $this->returnErrorInfo(array("customMessage" => '姓名不正确'));
                exit;
            }
            echo $this->returnErrorInfo(array("customMessage" => '请输入正确信息'));
            exit;
        }


        //插入rc表
        $rcModel = M('Rc');
        $check = $rcModel->where(array('nub' => $data['nub']))->find();
        if ($check) {
            echo $this->returnErrorInfo(array("customMessage" => "信用卡已存在!"));
            exit;
        }
        $data['username'] = $userInfo['username'];
        $data['create_time'] = time();
        $result = $rcModel->add($data);
        if ($result) {
            echo $this->returnSuccessInfo(array("customMessage" => "添加成功!"));
            exit;
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "添加失败!"));
            exit;
        }
    }

    //绑定还款信用卡短信
    public function rcsent() {
        $username = I('post.phone');
        if (!$username || !preg_match('/^\d{11}$/', $username)) {
            echo $this->returnErrorInfo(array("customMessage" => "请输入11位正确手机号码!"));
            exit;
        }
        $userModel = M('User');
        //验证手机号码绑定
//        $checkUser = $userModel->where(array('username'=>$username))->find();
//        if(!empty($checkUser)) {
//            echo $this->returnErrorInfo(array("customMessage" =>"帐号已被注册!"));
//            exit;
//        }
        //发送频率验证
        $sms_mobile = M('sms_log');
        $member_common_info = $sms_mobile->where(array('username' => $username, 'log_type' => 5))->find();

        if ($member_common_info) {
            if (date('Ymd', $member_common_info['add_time']) != date('Ymd', time())) {
                $data = array();
                $data['log_num'] = 0;
                $update = $sms_mobile->where((array('username' => $username, 'log_type' => 5)))->save($data);
                $member_common_info = $sms_mobile->where(array('username' => $username, 'log_type' => 5))->find();
            } else {
                if (time() - $member_common_info['add_time'] < 60) {
                    echo $this->returnErrorInfo(array("customMessage" => "请60s以后再发送"));
                    exit;
                } else {
                    if ($member_common_info['log_num'] >= 10) {
                        echo $this->returnErrorInfo(array("customMessage" => "今天短信已超10条，无法发送!"));
                        exit;
                    }
                }
            }
        }

        $verify_code = rand(100, 999) . rand(100, 999);
        $sms = new \Common\Sms\Sms();
        $result = $sms->mysend_aliyun($username, $verify_code); //发送短信调用
//        $result=true;
        if ($result) {
            $data = array();
            $update_data['log_phone'] = $username;
            $update_data['log_captcha'] = $verify_code;
            $update_data['log_msg'] = "";
            $update_data['add_time'] = time();
            ;
            $update_data['uid'] = 0;
            $update_data['username'] = $username;
            $update_data['log_type'] = 5;
            $update_data['log_num'] = $member_common_info['log_num'] + 1;
            if ($member_common_info) {
                $result = $sms_mobile->where((array('username' => $username, 'log_type' => 5)))->save($update_data);
            } else {
                $result = $sms_mobile->add($update_data);
            }
            if ($result) {
                echo $this->returnSuccessInfo(array("customMessage" => "验证码发送成功!"));
                exit;
            }
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "验证码发送失败!"));
            exit;
        }
    }

    //解绑信用卡
    public function deleterc() {
        $id = intval(I('post.id'));
        $rcModel = M('Rc');
        $userInfo = $this->userInfo;
        $result = $rcModel->where(array('id' => $id, "username" => $userInfo['username']))->save(array('is_bind' => 1));
        if ($result) {
            echo $this->returnSuccessInfo(array("customMessage" => "解绑成功!"));
            exit;
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "解绑失败!"));
            exit;
        }
    }

    //修改还款信用卡
    public function updaterc() {
        $userInfo = $this->userInfo;
        $data['id'] = intval(I('post.id'));
        $data['user'] = I('post.user');
        $data['nub'] = I('post.nub');
        $data['cvn'] = I('post.cvn');
        $data['end_time'] = I('post.end_time');
        $data['limit_money'] = I('post.limit_money');
        $data['bill_day'] = I('post.bill_day');
        $data['end_remoney'] = I('post.end_remoney');
        if (!preg_match("/^[\x{4e00}-\x{9fa5}]{2,6}$/u", $data['user'])) {
            echo $this->returnErrorInfo(array("customMessage" => "名字格式有误"));
            exit;
        }
        if (!is_numeric($data['nub'])) {
            echo $this->returnErrorInfo(array("customMessage" => "卡号有误"));
            exit;
        }
        if (!preg_match("/^\d{3}$/u", $data['cvn'])) {
            echo $this->returnErrorInfo(array("customMessage" => "CVN格式有误"));
            exit;
        }
        if (!preg_match("/^\d{4}$/u", $data['end_time'])) {
            echo $this->returnErrorInfo(array("customMessage" => "有效期格式有误"));
            exit;
        }
        if (!preg_match("/^\d{3,10}$/u", $data['limit_money'])) {
            echo $this->returnErrorInfo(array("customMessage" => "卡限额格式有误"));
            exit;
        }
        if (!preg_match("/^\d{1,2}$/u", $data['bill_day']) || $data['bill_day'] > 31 || $data['bill_day'] < 1) {
            echo $this->returnErrorInfo(array("customMessage" => "账单日格式有误"));
            exit;
        }
        if (!preg_match("/^\d{1,2}$/u", $data['end_remoney']) || $data['end_remoney'] > 31 || $data['end_remoney'] < 1) {
            echo $this->returnErrorInfo(array("customMessage" => "最后还款日格式有误"));
            exit;
        }

        $rcModel = M('Rc');
        $result = $rcModel->save($data);
        if ($result) {
            echo $this->returnSuccessInfo(array("customMessage" => "修改成功!", 'data' => $data));
            exit;
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "修改失败!"));
            exit;
        }
    }

    /*     * **************还款计划************************* */

    public function planlist() {
        $userInfo = $this->userInfo;
        $offset = (I('offset') == null) ? 1 : intval(I('offset'));
        $limit = (I('limit') == null) ? 10 : intval(I('limit'));
        $offset = $offset * $limit - $limit;
        $type = intval(I('type'));
        $where = "a.username=" . $userInfo['username'];
        if ($type != 3) {
            $where .= " and a.type=" . $type;
        }
        $payrcModel = M('Payrc');
        $array = $payrcModel
                ->field('a.rc_id,
                   a.id as ids,
                   a.username,
                   a.username,
                   a.pay_money,
                   a.pay_mub,
                   a.s_time,
                   a.e_time,
                   a.pay_fee,
                   a.pay_fee,
                   a.type,
                   rc.nub,
                   rc.bank_name')
                ->alias('a')
                ->join('LEFT JOIN __RC__ as rc ON a.rc_id=rc.id')
                ->where($where)
                ->limit($offset, $limit)
                ->order('a.id desc')
                ->select();
        $num = $payrcModel
                ->field('a.rc_id,
                    a.username,
                    a.username,
                    a.pay_money,
                    a.pay_mub,
                    a.pay_fee,
                    a.pay_fee,
                    rc.nub')
                ->alias('a')
                ->join('LEFT JOIN __RC__ as rc ON a.rc_id=rc.id')
                ->where($where)
                ->count();
        foreach ($array as $k => $v) {
            $no = strlen($v['nub']);
            $array[$k]['nub'] = substr($v['nub'], ($no - 4), $no);
            $array[$k]['s_time'] = date('Y.m.d', $v['s_time']);
            $array[$k]['e_time'] = date('Y.m.d', $v['e_time']);
        }
        $res['page'] = ceil($num / $limit);
        $res['data'] = $array;
        echo $this->returnSuccessInfo(array("data" => $res));
        exit;
    }

    //新增还款计划
    public function addpay() {
        $data['rc_id'] = intval(I('post.id'));

        if ($data['rc_id'] == 0) {
            echo $this->returnErrorInfo(array("customMessage" => "非法信用卡id"));
            exit;
        }
        $data['s_time'] = strtotime(I('post.s_time'));
        $data['e_time'] = strtotime(I('post.e_time'));
        $data['pay_money'] = I('post.pay_money');
        $data['pay_fee'] = I('post.pay_fee');
        $pay_list = json_decode(htmlspecialchars_decode(I('post.pay_list')), true); //清单
        if ($data['s_time'] <= strtotime(date('Y-m-d', time()))) {
            echo $this->returnErrorInfo(array("customMessage" => "开始时间不得小于今天"));
            exit;
        }
        if ($data['e_time'] - $data['s_time'] < (86400 * 5)) {
            echo $this->returnErrorInfo(array("customMessage" => "时间不得小于五天"));
            exit;
        }
//        if ($data['pay_money'] < 1000) {
//            echo $this->returnErrorInfo(array("customMessage" => "还款金额不得小于1000"));
//            exit;
//        }


        if ($data['pay_money'] < 20) {
            echo $this->returnErrorInfo(array("customMessage" => "还款金额不得小于20"));
            exit;
        }

        //验证手续费
        $userInfo = $this->userInfo;
        $userModel = M('User');
        $uclass = $userModel->field('grade,parent_id,id')->where(array('id' => $userInfo['uid']))->find();
        $gradeModel = M('Grade');
        $grade = $gradeModel->where((array('grade' => $uclass['grade'])))->find();
        $pay_fee = $data['pay_money'] * $grade['repay_rate'] * 0.01 + 11; //手续费
        $pay_fee = sprintf("%.2f", $pay_fee);
        if ($pay_fee > $data['pay_fee']) {
            echo $this->returnErrorInfo(array("customMessage" => "手续费有误"));
            exit;
        }

        //验证是否同一张信用卡(仅允许一张信用卡还款)
        $reModel = M('Rc');
        $check = $reModel->where(array('id' => $data['rc_id'], 'is_bind' => 0, 'status' => 1))->find();
        if ($check) {
            echo $this->returnErrorInfo(array("customMessage" => "该信用卡正在还款中"));
            exit;
        }

        //验证清单
        if ($pay_list == NUll) {
            echo $this->returnErrorInfo(array("customMessage" => "请列出订单"));
            exit;
        }
        foreach ($pay_list['data'] as $k => $v) {
            if (strtotime($pay_list['data'][$k]['create_time']) > strtotime(I('post.e_time') . " 23:59:59") || strtotime($pay_list['data'][$k]['create_time']) < $data['s_time']) {
                echo $this->returnErrorInfo(array("customMessage" => "订单时间有误"));
                exit;
            }
        }

        //插入payrc表
        try {
            $data['username'] = $userInfo['username'];
            $data['create_time'] = time();
            $data['pay_order'] = "WY" . $userInfo['uid'] . date('YmdHms', time()) . rand(0, 999);
            $data['pay_mub'] = 22;
            $payrecModel = M('Payrc');
            $result = $payrecModel->add($data);
            //修改该信用卡状态
            $result2 = $reModel->where(array('id' => $data['rc_id']))->save(array('status' => 1));
            //写入清单
            $costModel = M('PayrcCost');
            $repayModel = M('PayrcRepay');
            $repayModel->startTrans(); //开启事物
            $array = array();
            $array['payrc_id'] = $result; //计划还款id
            $array['status'] = 0;        //还款状态0未完成1已经完成2失败
            $array['create_time'] = time(); //创建时间
            foreach ($pay_list['data'] as $k => $v) {
                if ($v['type'] == 1) {//写入还款流水表
                    $array['money'] = $pay_list['data'][$k]['money']; //金额
                    $array['times'] = $pay_list['data'][$k]['times']; //期数
                    $array['pay_time'] = strtotime($pay_list['data'][$k]['create_time']); //还款时间
                    $array['pay_order'] = $data['pay_order'] . $pay_list['data'][$k]['times']; //订单=计划表订单+期数
                    $sign = $repayModel->add($array);
                    if (!$sign) {
                        $repayModel->rollback(); //如果添加失败事物回滚
                    }
                } else if ($v['type'] == 2) {//写入消费流水表
                    $array['money'] = $pay_list['data'][$k]['money']; //金额
                    $array['times'] = $pay_list['data'][$k]['times']; //期数
                    $array['pay_time'] = strtotime($pay_list['data'][$k]['create_time']); //还款时间
                    $array['pay_order'] = $data['pay_order'] . $pay_list['data'][$k]['times']; //订单=计划表订单+期数
                    $costModel->add($array);
                }
            }
            //写入用户分润
            $interestModel = M('Interest');
            if ($data['pay_money'] >= 10000) {
                /*                 * ******************************一级******************************************* */
                $co = floor($data['pay_money'] / 10000); //系数(向下取整)
                $one = $userModel->where('username=' . '"' . $uclass['parent_id'] . '"')->find();
                if ($one && $one['grade'] != 1) {//直推
                    if ($one['grade'] == 2) {//vip分润
                        $money = $co * 15;
                    } elseif ($one['grade'] == 3) {//高级vip
                        $money = $co * 25;
                    } elseif ($one['grade'] == 4) {//市级代理
                        $money = $co * 29;
                    } elseif ($one['grade'] == 5) {//省级代理
                        $money = $co * 32;
                    } elseif ($one['grade'] == 6) {//合伙人
                        $money = $co * 35;
                    } elseif ($one['grade'] == 7) {//运营中心
                        $money = $co * 37;
                    }
                    $oneInterest['uid'] = $one['id'];
                    $oneInterest['username'] = $one['username'];
                    $oneInterest['money'] = $money;
                    $oneInterest['create_time'] = time();
                    $oneInterest['child_id'] = $uclass['id'];
                    $oneInterest['pay_order'] = $data['pay_order'];
                    $oneInterest['gain_type'] = 1;
                    $interestModel->add($oneInterest);
                    $two = $userModel->where('username=' . '"' . $one['parent_id'] . '"')->find();
                }
                /*                 * ******************************二级******************************************* */
                if ($two['grade'] > 2 && $two['grade'] > 1) {
                    if ($two['grade'] == 3 && $grade['grade'] == 2) {//高级vip
                        $money = $co * 10;
                    } elseif ($two['grade'] == 4 && $grade['grade'] == 2) {//市级代理
                        $money = $co * 14;
                    } elseif ($two['grade'] == 4 && $grade['grade'] == 3) {//市级代理
                        $money = $co * 4;
                    } elseif ($two['grade'] == 5 && $grade['grade'] == 2) {//省级代理
                        $money = $co * 17;
                    } elseif ($two['grade'] == 5 && $grade['grade'] == 3) {//省级代理
                        $money = $co * 7;
                    } elseif ($two['grade'] == 5 && $grade['grade'] == 4) {//省级代理
                        $money = $co * 3;
                    } elseif ($two['grade'] == 6 && $grade['grade'] == 2) {//合伙人
                        $money = $co * 14;
                    } elseif ($two['grade'] == 6 && $grade['grade'] == 3) {//合伙人
                        $money = $co * 4;
                    } elseif ($two['grade'] == 6 && $grade['grade'] == 4) {//合伙人
                        $money = $co * 4;
                    } elseif ($two['grade'] == 6 && $grade['grade'] == 5) {//合伙人
                        $money = $co * 4;
                    } elseif ($two['grade'] == 7 && $grade['grade'] == 2) {//运营中心
                        $money = $co * 22;
                    } elseif ($two['grade'] == 7 && $grade['grade'] == 3) {//运营中心
                        $money = $co * 12;
                    } elseif ($two['grade'] == 7 && $grade['grade'] == 4) {//运营中心
                        $money = $co * 8;
                    } elseif ($two['grade'] == 7 && $grade['grade'] == 5) {//运营中心
                        $money = $co * 5;
                    } elseif ($two['grade'] == 7 && $grade['grade'] == 6) {//运营中心
                        $money = $co * 2;
                    }
                    $twoInterest['uid'] = $two['id'];
                    $twoInterest['username'] = $two['username'];
                    $twoInterest['money'] = $money;
                    $twoInterest['create_time'] = time();
                    $twoInterest['child_id'] = $uclass['id'];
                    $twoInterest['pay_order'] = $data['pay_order'];
                    $twoInterest['gain_type'] = 1;
                    $interestModel->add($twoInterest);
                    $three = $userModel->where('username=' . '"' . $two['parent_id'] . '"')->find();
                }
                /*                 * ******************************三级******************************************** */
                if ($three['grade'] > 2 && $three['grade'] > 1) {
                    if ($three['grade'] == 3 && $grade['grade'] == 2) {//高级vip
                        $money = $co * 10;
                    } elseif ($three['grade'] == 4 && $grade['grade'] == 2) {//市级代理
                        $money = $co * 14;
                    } elseif ($three['grade'] == 4 && $grade['grade'] == 3) {//市级代理
                        $money = $co * 4;
                    } elseif ($three['grade'] == 5 && $grade['grade'] == 2) {//省级代理
                        $money = $co * 17;
                    } elseif ($three['grade'] == 5 && $grade['grade'] == 3) {//省级代理
                        $money = $co * 7;
                    } elseif ($three['grade'] == 5 && $grade['grade'] == 4) {//省级代理
                        $money = $co * 3;
                    } elseif ($three['grade'] == 6 && $grade['grade'] == 2) {//合伙人
                        $money = $co * 14;
                    } elseif ($three['grade'] == 6 && $grade['grade'] == 3) {//合伙人
                        $money = $co * 4;
                    } elseif ($three['grade'] == 6 && $grade['grade'] == 4) {//合伙人
                        $money = $co * 4;
                    } elseif ($three['grade'] == 6 && $grade['grade'] == 5) {//合伙人
                        $money = $co * 4;
                    } elseif ($three['grade'] == 7 && $grade['grade'] == 2) {//运营中心
                        $money = $co * 22;
                    } elseif ($three['grade'] == 7 && $grade['grade'] == 3) {//运营中心
                        $money = $co * 12;
                    } elseif ($three['grade'] == 7 && $grade['grade'] == 4) {//运营中心
                        $money = $co * 8;
                    } elseif ($three['grade'] == 7 && $grade['grade'] == 5) {//运营中心
                        $money = $co * 5;
                    } elseif ($three['grade'] == 7 && $grade['grade'] == 6) {//运营中心
                        $money = $co * 2;
                    }
                    $threeInterest['uid'] = $three['id'];
                    $threeInterest['username'] = $three['username'];
                    $threeInterest['money'] = $money;
                    $threeInterest['create_time'] = time();
                    $threeInterest['child_id'] = $uclass['id'];
                    $threeInterest['pay_order'] = $data['pay_order'];
                    $threeInterest['gain_type'] = 1;
                    $interestModel->add($twoInterest);
                }
            }
            $repayModel->commit(); //commit事物提交
            if ($result && $result2) {
                echo $this->returnSuccessInfo(array("customMessage" => "申请成功!"));
                exit;
            } else {
                echo $this->returnErrorInfo(array("customMessage" => "申请失败"));
                exit;
            }
        } catch (Exception $e) {
            $e->getMessage();
        }
    }

    //详情页面
    public function planlists() {
        $userInfo = $this->userInfo;
        $id = intval(I('post.id'));
        $payrcModel = M('Payrc');
        //查询计划
        $payrc = $payrcModel->where(array('username' => $userInfo['username'], 'id' => $id))->find();
        $repayModel = M('PayrcRepay');
        $have_repay_no = $repayModel->where('type=1 and payrc_id=' . $payrc['id'])->count(); //已还次数
        $repay_no = $repayModel->where('type=0 and payrc_id=' . $payrc['id'])->count(); //未还次数

        $data['ids'] = $payrc['id']; //还款ID
        $data['pay_money'] = $payrc['pay_money'];
        $data['s_time'] = date('Y.m.d', $payrc['s_time']);
        $data['e_time'] = date('Y.m.d', $payrc['e_time']);
        $data['have_repay_no'] = $have_repay_no; //已还次数
        $data['repay_no'] = $repay_no; //未还次数
        $data['pay_mub'] = $payrc['pay_mub']; //消费
        $data['pay_fee'] = $payrc['pay_fee']; //手续费
        $data['pay_order'] = $payrc['pay_order']; //订单号
        $data['type'] = $payrc['type']; //还款状态
        $data['create_time'] = date('Y-m-d', $payrc['create_time']);
        echo $this->returnSuccessInfo(array("data" => $data));
        exit;
    }

    //还款详情
    public function repaylist() {
        $id = intval(I('post.id'));
        $type = intval(I('post.type'));
        $model = M('PayrcRepay');
        $data = $model->field('money,times,pay_time,pay_order')->where(array("payrc_id" => $id, "status" => $type))->select();
        foreach ($data as $k => $v) {
            $data[$k]['pay_time'] = date('Y-m-d H:i:s', $v['pay_time']);
        }
        echo $this->returnSuccessInfo(array("data" => array('data' => $data)));
        exit;
    }

    //消费详情(只查询已还记录)
    public function costlist() {
        $id = intval(I('post.id'));
        $model = M('PayrcCost');
        $data = $model->field('money,times,pay_time,pay_order')->where(array("payrc_id" => $id, "status" => 1))->select();
        foreach ($data as $k => $v) {
            $data[$k]['pay_time'] = date('Y-m-d H:i:s', $v['pay_time']);
        }
        echo $this->returnSuccessInfo(array("data" => $data));
        exit;
    }

    /*     * **************信用卡收款********************* */

    /*
     * 收款第一步：
     * 返回收付信息
     * return 信用卡信息
     * return 储蓄卡信息
     */

    public function income() {
        $userInfo = $this->userInfo;
        //查询是否绑定信用卡
        $defrayModel = M('Defrayrc');
        $defray = $defrayModel->field('id,bank_name,nub')->where('is_bind=0 and username=' . $userInfo['username'])->find();
        if ($defray) {
            $length = strlen($defray['nub']);
            $defray['nub'] = substr($defray['nub'], ($length - 4), $length);
        }
        //查询是否绑定银行卡
        $userBankModel = M('UserBank');
        $userBank = $userBankModel->field('id,bank_name,account')->where('type=1 and uid=' . $userInfo['uid'])->find();
        if ($userBank) {
            $length = strlen($userBank['account']);
            $userBank['account'] = substr($userBank['account'], ($length - 4), $length);
        }
        //角色费率
        $userModel = M('User');
        $uclass = $userModel->field('grade')->where(array('id' => $userInfo['uid']))->find();
        $gradeModel = M('Grade');
        $grade = $gradeModel->field('collection_rate')->where((array('grade' => $uclass['grade'])))->find();

        //信用卡信息
        $data['rc_bank_id'] = $defray['id'];
        $data['rc_bank_name'] = $defray['bank_name'];
        $data['nub'] = $defray['nub'];
        //储蓄卡信息
        $data['user_bank_id'] = $userBank['id'];
        $data['bank_name'] = $userBank['bank_name'];
        $data['account'] = $userBank['account'];

        $data['rate'] = $grade['collection_rate'] . "+2.00元";
        //升级
        $grades = $gradeModel->field('grade_name,collection_rate')->where((array('grade' => ($uclass['grade'] + 1))))->find();

        $data['grade'] = $grades['grade_name'];
        $data['up_rate'] = $grades['collection_rate'];

        echo $this->returnSuccessInfo(array("data" => $data));
        exit;
    }

    //添加支付信用卡
    public function defrayrcadd() {
        $data['user'] = I('post.user');
        $data['nub'] = I('post.nub');
        $data['cvn'] = I('post.cvn');
        $data['end_time'] = I('post.end_time');
        $data['phone'] = I('post.phone');
        $data['code'] = I('post.code');
        $data['bank_id'] = intval(I('post.bank_id'));
        $data['bank_name'] = I('post.bank_name');
        if (!preg_match("/^[\x{4e00}-\x{9fa5}]{2,30}$/u", $data['bank_name'])) {
            echo $this->returnErrorInfo(array("customMessage" => "银行格式有误"));
            exit;
        }
        if (!preg_match("/^[\x{4e00}-\x{9fa5}]{2,6}$/u", $data['user'])) {
            echo $this->returnErrorInfo(array("customMessage" => "名字格式有误"));
            exit;
        }
        if (!is_numeric($data['nub'])) {
            echo $this->returnErrorInfo(array("customMessage" => "卡号有误"));
            exit;
        }
        if (!preg_match("/^\d{3}$/u", $data['cvn'])) {
            echo $this->returnErrorInfo(array("customMessage" => "CVN格式有误"));
            exit;
        }
        if (!preg_match("/^\d{4}$/u", $data['end_time'])) {
            echo $this->returnErrorInfo(array("customMessage" => "有效期格式有误"));
            exit;
        }
        if (!preg_match('/^\d{11}$/', $data['phone'])) {
            echo $this->returnErrorInfo(array("customMessage" => "手机号格式有误"));
            exit;
        }
        if (!is_numeric($data['code'])) {
            echo $this->returnErrorInfo(array("customMessage" => "验证码有误"));
            exit;
        }
        //短信验证码
        $smsModel = M('SmsLog');
        $checkSms = $smsModel->where(array('username' => $data['phone'], 'log_type' => 5, 'log_captcha' => $data['code']))->find();
        if (!$checkSms) {
            echo $this->returnErrorInfo(array("customMessage" => "验证码错误!"));
            exit;
        } else {
            if (($checkSms['add_time'] - time()) > 300) {
                echo $this->returnErrorInfo(array("customMessage" => "验证码超时!"));
                exit;
            }
        }
        $rcModel = M('Defrayrc');
        $check = $rcModel->where(array('nub' => $data['nub'], 'is_bind' => 0))->find();
        if ($check) {
            echo $this->returnErrorInfo(array("customMessage" => "信用卡已存在!"));
            exit;
        }
        $userInfo = $this->userInfo;
        $data['username'] = $userInfo['username'];
        $data['create_time'] = time();
        $result = $rcModel->add($data);
        if ($result) {
            echo $this->returnSuccessInfo(array("customMessage" => "添加成功!"));
            exit;
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "添加失败!"));
            exit;
        }
    }

    //添加支付信用卡短信
    public function defrayrcaddsent() {
        $username = I('post.phone');
        if (!$username || !preg_match('/^\d{11}$/', $username)) {
            echo $this->returnErrorInfo(array("customMessage" => "请输入11位正确手机号码!"));
            exit;
        }
        $userModel = M('User');
        //验证手机号码绑定
//        $checkUser = $userModel->where(array('username'=>$username))->find();
//        if(!empty($checkUser)) {
//            echo $this->returnErrorInfo(array("customMessage" =>"帐号已被注册!"));
//            exit;
//        }
        //发送频率验证
        $sms_mobile = M('sms_log');
        $member_common_info = $sms_mobile->where(array('username' => $username, 'log_type' => 6))->find();

        if ($member_common_info) {
            if (date('Ymd', $member_common_info['add_time']) != date('Ymd', time())) {
                $data = array();
                $data['log_num'] = 0;
                $update = $sms_mobile->where((array('username' => $username, 'log_type' => 6)))->save($data);
                $member_common_info = $sms_mobile->where(array('username' => $username, 'log_type' => 6))->find();
            } else {
                if (time() - $member_common_info['add_time'] < 60) {
                    echo $this->returnErrorInfo(array("customMessage" => "请60s以后再发送"));
                    exit;
                } else {
                    if ($member_common_info['log_num'] >= 10) {
                        echo $this->returnErrorInfo(array("customMessage" => "今天短信已超10条，无法发送!"));
                        exit;
                    }
                }
            }
        }

        $verify_code = rand(100, 999) . rand(100, 999);
        $sms = new \Common\Sms\Sms();
        $result = $sms->mysend_aliyun($username, $verify_code); //发送短信调用
//        $result=true;
        if ($result) {
            $data = array();
            $update_data['log_phone'] = $username;
            $update_data['log_captcha'] = $verify_code;
            $update_data['log_msg'] = "";
            $update_data['add_time'] = time();
            ;
            $update_data['uid'] = 0;
            $update_data['username'] = $username;
            $update_data['log_type'] = 6;
            $update_data['log_num'] = $member_common_info['log_num'] + 1;
            if ($member_common_info) {
                $result = $sms_mobile->where((array('username' => $username, 'log_type' => 6)))->save($update_data);
            } else {
                $result = $sms_mobile->add($update_data);
            }
            if ($result) {
                echo $this->returnSuccessInfo(array("customMessage" => "验证码发送成功!"));
                exit;
            }
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "验证码发送失败!"));
            exit;
        }
    }

    //已绑定支付信用卡
    public function defraylist() {
        $userInfo = $this->userInfo;
        $defrayModel = M('Defrayrc');
        $defray = $defrayModel->field('id as ids,bank_name,nub')->where('is_bind=0 and username=' . $userInfo['username'])->select();
        foreach ($defray as $k => $v) {
            $length = strlen($v['nub']);
            $defray[$k]['nub'] = substr($v['nub'], ($length - 4), $length);
        }

        echo $this->returnSuccessInfo(array('data' => array('data' => $defray)));
        exit;
    }

    /*
     * 信用卡收款(第二步：获取验证码）
     * 原第三方所写
     */

    public function cashsent() {
        $userInfo = $this->userInfo;
        $I['rc_bank_id'] = intval(I('post.rc_bank_id'));
        $I['user_bank_id'] = intval(I('post.user_bank_id'));
        $I['money'] = I('post.money');
        if (empty($I['rc_bank_id']) || empty($I['money'])) {
            echo $this->returnErrorInfo(array("customMessage" => "金额和信用卡不能为空!"));
            exit;
        }
        if (!preg_match("/^[1-9][0-9]*$/", $I['money']) || $I['money'] < 0) {
            echo $this->returnErrorInfo(array("customMessage" => "金额必须是大于0的整数!"));
            exit;
        }
        //个人信息
        $ubankModel = M('UserBank');
        $ubank = $ubankModel->where('uid=' . $userInfo['uid'])->find();
        $rcModel = M('Defrayrc');
        $rc = $rcModel->where('id=' . $I['rc_bank_id'])->find();
        $userModel = M('User');
        $user = $userModel->where('id=' . $userInfo['uid'])->find();
        $gradeModel = M('grade');
        $grade = $gradeModel->where('grade=' . $user['grade'])->find();
        $fee = $I['money'] * $grade['collection_rate'] / 100; //手续费

        $par = array();
        $par['ic'] = $ubank['ic']; //身份证
        $par['realname'] = $ubank['realname']; //姓名
        $par['bank_name'] = $rc['bank_name']; //银行名
        $par['nub'] = $rc['nub']; //卡号
        $par['phone'] = $rc['phone']; //手机
        $par['bankcode'] = $this->bankcode($rc['bank_name']); //银行代码
        $par['uid'] = $userInfo['uid'];
        $par['money'] = ($fee + $I['money'] + 2) * 100;

        $verify = $this->collectSent();
        echo $this->returnSuccessInfo(array("customMessage" => $verify['customMessage']));
//        exit;
//        echo $this->returnSuccessInfo(array("customMessage" => $verify['customMessage']));
//        exit;
//        if ($result['code'] == 1) {
//            //写入表defrayrc_log
//            $logModel = M('DefrayrcLog');
//            $log['rc_id'] = $rc['id'];
//            $log['bank_id'] = $I['user_bank_id'];
//            $log['uid'] = $userInfo['uid'];
//            $log['username'] = $userInfo['username'];
//            $log['money'] = $I['money'];
//            $log['fee'] = $fee;
//            $log['pay_order'] = $result['data']['order'];
//            $log['interface_no'] = $result['data']['pay_order'];
//            $log['in_status'] = 0;
//            $log['out_status'] = 0;
//            $log['create_time'] = time();
//            $add = $logModel->add($log);
//            echo $this->returnSuccessInfo(array("customMessage" => "发送成功", 'data' => array('data' => $result['data'])));
//            exit;
//        } else {
//            echo $this->returnErrorInfo(array("customMessage" => "发送失败", 'data' => array('data' => $result['data'])));
//            exit;
//        }
    }

    /*
     * 确认收款
     * 修改者：@林
     * 收款第三步：确认支付信息，调用第三方接口
     */

    public function cash() {
        $userInfo = $this->userInfo;
        $I['pay_order'] = I('post.pay_order'); //收款金额
        $cardId = I('post.cardId'); //支付卡ID
        $acctCardno = I('post.acctCardno'); //银行卡ID
        if (!$I['pay_order'] || !$cardId || !$acctCardno) {
            echo $this->returnErrorInfo(array("customMessage" => "请填写完整的参数!"));
            exit;
        }
        $user_info = M("user_bank")->alias('ub')->join('wy_rc as r on ub.username=r.username')->field('ub.ic,ub.account,r.phone,r.cvn,r.end_time,r.user,r.nub')->where('ub.uid=' . $userInfo['uid'] . " and r.id=" . $cardId)->find();
//        echo $this->returnErrorInfo(array("customMessage" => "参数!",'data'=>$user_info));
//            exit;
        $I['cardId'] = $user_info['nub']; //支付卡号
        $I['acctCardno'] = $user_info['account']; //结算卡号
        $I['ic'] = $user_info['ic']; //证件号
        $I['cvn2'] = $user_info['cvn']; //cvn2
        $I['expDt'] = $user_info['end_time']; //有效期
        $I['phone'] = $user_info['phone']; //电话
        $I['realname'] = $user_info['user']; //姓名
        $I['uid'] = $userInfo['uid'];
//         echo $this->returnErrorInfo(array("customMessage" => "参数信息",'data'=>$I));
//            exit;
//        $I['code'] = I('post.code');
//        if (!is_numeric($I['code'])) {
//            echo $this->returnErrorInfo(array("customMessage" => "验证号码只能为数字"));
//            exit;
//        }
//        $data['rc_id'] = I('post.rc_bank_id'); //信用卡号
//        $data['bank_id'] = I('post.user_bank_id'); //储蓄卡号
//        $data['order'] = I('post.order');//商户订单号
//        $data['rc_bank_id'] = I('post.rc_bank_id');
        //提现
        //获取通道信息（同名进出）
        $route_info = M("Route")->field('url')->where('type=0 and is_used=1')->find();
        if ($route_info['url'] == 'http://api.palmf.cn/api/cash/apply') {//判断通道类型，选择支付通道
            //掌灵科技家通道
            $pay = new \Common\Pay\CashPay();
            $result = $pay->cash($I);
            if ($result['data']['code'] == 10000) {
                //写入表defrayrc_log
                $user = M('user')->field('grade')->where('id=' . $userInfo['uid'])->find();
                $gradeModel = M('grade');
                $grade = $gradeModel->where('grade=' . $user['grade'])->find();
                $fee = $I['pay_order'] * $grade['collection_rate'] / 100;
                $logModel = M('defrayrc_log');
                $id_info = M('user_bank')->alias('ub')->join('wy_defrayrc as d on ub.username=d.username')->field('ub.id as bank_id,d.id as rc_id')->where('ub.uid=' . $userInfo['uid'] . ' and d.nub=' . $user_info['nub'])->find();
                $log['rc_id'] = $id_info['rc_id']; //支付信用卡ID，在defrayrc表
                $log['bank_id'] = $id_info['bank_id']; //储蓄卡ID，user_bank表
                $log['uid'] = $userInfo['uid'];
                $log['username'] = $userInfo['username'];
                $log['money'] = $I['pay_order']; //收款金额
                $log['fee'] = $fee; //手续费
                $log['pay_order'] = $result['data']['mchntOrderNo']; //订单号
                $log['interface_no'] = $result['data']['orderNo']; //交易单号
                $log['in_status'] = 0;
                $log['out_status'] = 0;
                $log['create_time'] = time();
                $log['route_type'] = 'zhangling'; //支付通道
                $add = $logModel->add($log);

                //成功，跳转至支付页面
//            header('location:' . $result['data']['payInfo']);
                echo $this->returnSuccessInfo(array("customMessage" => "签名成功!", 'data' => $result['data']['payInfo']));
                exit;
            } else {
                if ($result['data']['code'] == 10001) {
                    echo $this->returnErrorInfo(array("customMessage" => "请求接口异常!"));
                    exit;
                }elseif ($result['data']['code'] == 10005) {
                    echo $this->returnErrorInfo(array("customMessage" => "缺少必填项参数!"));
                    exit;
                } elseif ($result['data']['code'] == 10002) {
                    echo $this->returnErrorInfo(array("customMessage" => "校验请求参数时异常!"));
                    exit;
                } elseif ($result['data']['code'] == 10006) {
                    echo $this->returnErrorInfo(array("customMessage" => "参数值长度不符合规定!"));
                    exit;
                } elseif ($result['data']['code'] == 20001) {
                    echo $this->returnErrorInfo(array("customMessage" => "appid无效!"));
                    exit;
                } elseif ($result['data']['code'] == 20002) {
                    echo $this->returnErrorInfo(array("customMessage" => "Md5签名校验失败!"));
                    exit;
                } elseif ($result['data']['code'] == 20015) {
                    echo $this->returnErrorInfo(array("customMessage" => "生成订单失败!"));
                    exit;
                } elseif ($result['data']['code'] == 20016) {
                    echo $this->returnErrorInfo(array("customMessage" => "订单重复!"));
                    exit;
                } elseif ($result['data']['code'] == 20019) {
                    echo $this->returnErrorInfo(array("customMessage" => "订单不存在!"));
                    exit;
                } elseif ($result['data']['code'] == 20020) {
                    echo $this->returnErrorInfo(array("customMessage" => "无效的token!"));
                    exit;
                } elseif ($result['data']['code'] == 20022) {
                    echo $this->returnErrorInfo(array("customMessage" => "订单已支付或已关闭!"));
                    exit;
                } elseif ($result['data']['code'] == 20032) {
                    echo $this->returnErrorInfo(array("customMessage" => "收款金额不能小于100元!"));
                    exit;
                } elseif ($result['data']['code'] == 20031) {
                    echo $this->returnErrorInfo(array("customMessage" => "收款金额不能大于20000元!"));
                    exit;
                } elseif ($result['data']['code'] == 20030) {
                    echo $this->returnErrorInfo(array("customMessage" => "商户未配置风控!"));
                    exit;
                } elseif ($result['data']['code'] == 20035) {
                    echo $this->returnErrorInfo(array("customMessage" => "交易时间不允许!"));
                    exit;
                } elseif ($result['data']['code'] == 20033) {
                    echo $this->returnErrorInfo(array("customMessage" => "日总交易额超限!"));
                    exit;
                } elseif ($result['data']['code'] == 20034) {
                    echo $this->returnErrorInfo(array("customMessage" => "日总交易笔数超限!"));
                    exit;
                } elseif ($result['data']['code'] == 20054) {
                    echo $this->returnErrorInfo(array("customMessage" => "订单重复发起支付请求!"));
                    exit;
                } else {
                    echo $this->returnErrorInfo(array("customMessage" => '出错了，请稍后再试!'));
                    exit;
                }
            }
        } elseif ($route_info['url'] == 'http://106.14.249.7/api/payment-gate-web/do') {
            $I['requestNo'] = 'wyh' . date('YmdHis') . rand(99, 999);
            $I['orderNo'] = "JX" . date("YmdHis") . rand(99, 999);
            //写入表defrayrc_log
            $user = M('user')->field('grade')->where('id=' . $userInfo['uid'])->find();
            $gradeModel = M('grade');
            $grade = $gradeModel->where('grade=' . $user['grade'])->find();
            $fee = $I['pay_order'] * $grade['collection_rate'] / 100;
            $logModel = M('defrayrc_log');
            $newModel = M('user_bank');
            $id_info = $newModel->alias('ub')->join('wy_defrayrc as d on ub.username=d.username')->field('ub.id as bank_id,d.id as rc_id')->where('ub.uid=' . $userInfo['uid'] . ' and d.nub=' . $user_info['nub'])->find();
//            $abc=$newModel->getlastsql();//getlastsql()函数获取最近一条执行的sql语句
//            echo $this->returnErrorInfo(array("customMessage" => "sql语句!", 'data' => $abc));
//            exit;
            $log['rc_id'] = $id_info['rc_id']; //支付信用卡ID，在defrayrc表
            $log['bank_id'] = $id_info['bank_id']; //储蓄卡ID，user_bank表
            $log['uid'] = $userInfo['uid'];
            $log['username'] = $userInfo['username'];
            $log['money'] = $I['pay_order']; //收款金额
            $log['fee'] = $fee; //手续费
            $log['pay_order'] = $I['orderNo']; //订单号
            $log['interface_no'] = $I['requestNo']; //交易单号
            $log['in_status'] = 0;
            $log['out_status'] = 0;
            $log['create_time'] = time();
            $log['route_type'] = 'sam'; //支付通道
            $add = $logModel->add($log);

            //sam家通道

            $pay = new \Common\Pay\SamCash();
            $result = $pay->cash($I);
            $respDesc_first = stripos($result['data'], 'respDesc');
            if ($respDesc_first) {
                $returnUrl_first = stripos($result['data'], 'returnUrl');
                $respDesc = substr($result['data'], $respDesc_first + 9, $returnUrl_first - $respDesc_first - 10); //返回结果描述
            }

            if ($respDesc) {
                //失败，返回错误描述
                 echo $this->returnErrorInfo(array("customMessage" => '描述','data'=>$result));
//                echo $this->returnErrorInfo(array("customMessage" => $respDesc));
                exit;
            } else {
                //成功，跳转至支付页面
                echo $result['data']; //该结果为支付地址
                exit;
            }
        }

        echo $this->returnErrorInfo(array("customMessage" => "下单接口返回结果!", 'data' => $result));
        exit;
        //判断订单状态，该步骤待定
//        $logModel = M('DefrayrcLog');
//        $check = $logModel->where('out_status=0 and uid=' . $userInfo['uid'] . ' and pay_order=' . '"' . $data['order'] . '"')->find();
//        if (!$check) {
//            echo $this->returnErrorInfo(array("customMessage" => "订单不存在或已完成!"));
//            exit;
//        }



        $userModel = M('User');
        $uclass = $userModel->field('grade,parent_id,id')->where(array('id' => $userInfo['uid']))->find();
        $gradeModel = M('Grade');
        $grade = $gradeModel->where((array('grade' => $uclass['grade'])))->find();
        $logModel = M('DefrayrcLog');
        $check = $logModel->where('out_status=0 and uid=' . $userInfo['uid'] . ' and pay_order=' . '"' . $data['order'] . '"')->find();
        if (!$check) {
            echo $this->returnErrorInfo(array("customMessage" => "订单不存在或已完成!"));
            exit;
        }
        $pay = new \Common\Pay\OnlinePay(); //原有外包公司写的第三方通道对接接口
        $result = $pay->cheakPay($I);
        if ($result['code'] == 1) {
            //修改借款记录表
            $result1 = $logModel->where('uid=' . $userInfo['uid'] . ' and pay_order=' . '"' . $data['order'] . '"')->save(array('out_status' => 1));
            //写入用户分润
            $interestModel = M('Interest');
            if ($data['pay_money'] >= 10000) {
                /*                 * ******************************一级******************************************* */
                $co = floor($data['pay_money'] / 10000); //系数(向下取整)
                $one = $userModel->where('username=' . '"' . $uclass['parent_id'] . '"')->find();
                if ($one && $one['grade'] != 1) {//直推
                    if ($one['grade'] == 2) {//vip分润
                        $money = $co * 5;
                    } elseif ($one['grade'] == 3) {//高级vip
                        $money = $co * 7;
                    } elseif ($one['grade'] == 4) {//市级代理
                        $money = $co * 10;
                    } elseif ($one['grade'] == 5) {//省级代理
                        $money = $co * 12;
                    } elseif ($one['grade'] == 6) {//合伙人
                        $money = $co * 15;
                    } elseif ($one['grade'] == 7) {//运营中心
                        $money = $co * 17;
                    }
                    $oneInterest['uid'] = $one['id'];
                    $oneInterest['username'] = $one['username'];
                    $oneInterest['money'] = $money;
                    $oneInterest['create_time'] = time();
                    $oneInterest['child_id'] = $uclass['id'];
                    $oneInterest['pay_order'] = $data['pay_order'];
                    $oneInterest['gain_type'] = 2;
                    $interestModel->add($oneInterest);
                    $two = $userModel->where('username=' . '"' . $one['parent_id'] . '"')->find();
                }
                /*                 * ******************************二级******************************************* */
                if ($two['grade'] > 2 && $two['grade'] > 1) {
                    if ($two['grade'] == 3 && $grade['grade'] == 2) {//高级vip
                        $money = $co * 2;
                    } elseif ($two['grade'] == 4 && $grade['grade'] == 2) {//市级代理
                        $money = $co * 5;
                    } elseif ($two['grade'] == 4 && $grade['grade'] == 3) {//市级代理
                        $money = $co * 3;
                    } elseif ($two['grade'] == 5 && $grade['grade'] == 2) {//省级代理
                        $money = $co * 7;
                    } elseif ($two['grade'] == 5 && $grade['grade'] == 3) {//省级代理
                        $money = $co * 5;
                    } elseif ($two['grade'] == 5 && $grade['grade'] == 4) {//省级代理
                        $money = $co * 2;
                    } elseif ($two['grade'] == 6 && $grade['grade'] == 2) {//合伙人
                        $money = $co * 12;
                    } elseif ($two['grade'] == 6 && $grade['grade'] == 3) {//合伙人
                        $money = $co * 10;
                    } elseif ($two['grade'] == 6 && $grade['grade'] == 4) {//合伙人
                        $money = $co * 5;
                    } elseif ($two['grade'] == 6 && $grade['grade'] == 5) {//合伙人
                        $money = $co * 3;
                    } elseif ($two['grade'] == 7 && $grade['grade'] == 2) {//运营中心
                        $money = $co * 12;
                    } elseif ($two['grade'] == 7 && $grade['grade'] == 3) {//运营中心
                        $money = $co * 10;
                    } elseif ($two['grade'] == 7 && $grade['grade'] == 4) {//运营中心
                        $money = $co * 7;
                    } elseif ($two['grade'] == 7 && $grade['grade'] == 5) {//运营中心
                        $money = $co * 5;
                    } elseif ($two['grade'] == 7 && $grade['grade'] == 6) {//运营中心
                        $money = $co * 2;
                    }
                    $twoInterest['uid'] = $two['id'];
                    $twoInterest['username'] = $two['username'];
                    $twoInterest['money'] = $money;
                    $twoInterest['create_time'] = time();
                    $twoInterest['child_id'] = $uclass['id'];
                    $twoInterest['pay_order'] = $data['pay_order'];
                    $twoInterest['gain_type'] = 2;
                    $interestModel->add($twoInterest);
                    $three = $userModel->where('username=' . '"' . $two['parent_id'] . '"')->find();
                }
                /*                 * ******************************三级******************************************** */
                if ($three['grade'] > 2 && $three['grade'] > 1) {
                    if ($three['grade'] == 3 && $grade['grade'] == 2) {//高级vip
                        $money = $co * 2;
                    } elseif ($three['grade'] == 4 && $grade['grade'] == 2) {//市级代理
                        $money = $co * 5;
                    } elseif ($three['grade'] == 4 && $grade['grade'] == 3) {//市级代理
                        $money = $co * 3;
                    } elseif ($three['grade'] == 5 && $grade['grade'] == 2) {//省级代理
                        $money = $co * 7;
                    } elseif ($three['grade'] == 5 && $grade['grade'] == 3) {//省级代理
                        $money = $co * 5;
                    } elseif ($three['grade'] == 5 && $grade['grade'] == 4) {//省级代理
                        $money = $co * 2;
                    } elseif ($three['grade'] == 6 && $grade['grade'] == 2) {//合伙人
                        $money = $co * 12;
                    } elseif ($three['grade'] == 6 && $grade['grade'] == 3) {//合伙人
                        $money = $co * 10;
                    } elseif ($three['grade'] == 6 && $grade['grade'] == 4) {//合伙人
                        $money = $co * 5;
                    } elseif ($three['grade'] == 6 && $grade['grade'] == 5) {//合伙人
                        $money = $co * 3;
                    } elseif ($three['grade'] == 7 && $grade['grade'] == 2) {//运营中心
                        $money = $co * 12;
                    } elseif ($three['grade'] == 7 && $grade['grade'] == 3) {//运营中心
                        $money = $co * 10;
                    } elseif ($three['grade'] == 7 && $grade['grade'] == 4) {//运营中心
                        $money = $co * 7;
                    } elseif ($three['grade'] == 7 && $grade['grade'] == 5) {//运营中心
                        $money = $co * 5;
                    } elseif ($three['grade'] == 7 && $grade['grade'] == 6) {//运营中心
                        $money = $co * 2;
                    }
                    $threeInterest['uid'] = $three['id'];
                    $threeInterest['username'] = $three['username'];
                    $threeInterest['money'] = $money;
                    $threeInterest['create_time'] = time();
                    $threeInterest['child_id'] = $uclass['id'];
                    $threeInterest['pay_order'] = $data['pay_order'];
                    $threeInterest['gain_type'] = 2;
                    $interestModel->add($twoInterest);
                }
            }
            if ($result1) {
                echo $this->returnSuccessInfo(array("customMessage" => "提款成功!"));
                exit;
            } else {
                echo $this->returnErrorInfo(array("customMessage" => "提款失败!"));
                exit;
            }
        }
    }

    /*
     * 掌灵科技家
     * 信用卡收款同步跳转接口
     */

    public function returnUrl() {
        //返回的原串
//        http://crm.szinternet.com/Api/Index/returnUrl?acctCardno=6226190680382664&amount=50000&appid=0000002535&cardId=4033920015722897&fee=173&mchntId=0000002128&mchntOrderNo=JX201806131747571712&mobileNo=13902449153&orderNo=15288832775230028551&paySt=2&powerId=9000000001&signature=87c4d756eaf9fb296f944d8eb4d4f3fc

        header('Content-type:text/json;charset=utf-8');
        $request = I("get.");
        if ($request['paySt'] == 2) {
            echo $this->returnSuccessInfo(array("customMessage" => "收款成功!"));
            exit;
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "收款失败!"));
            exit;
        }
    }

    /*
     * 信用卡收款自主查询
     * 调用第三方查询接口
     */

    public function queryCashOrder() {
        $param['service'] = 'service.api.cash.query';
        $param['appid'] = "0000002535";
        //查询当前用户所有的收款记录
        $userInfo = $this->userInfo;
        $user = M("defrayrc_log")->where('uid=' . $userInfo['uid'])->select();
        foreach ($user as $k => $v) {
            $param['mchntOrderNo'] = $v['pay_order']; //跟下面的参数两选一，商户交易订单号
            $param['orderNo'] = $v['interface_no']; //支付平台订单号
            $obj = new \Common\Pay\CashPay();
            $info[] = $obj->queryOrder($param);
        }

        echo $this->returnSuccessInfo(array("customMessage" => "收款列表!", 'data' => $info));
        exit;
    }

    /*
     * 信用卡收款短信
     */

    public function collectSent() {
        $username = $this->userInfo;
        $username = $username['username'];
        //发送频率验证
        $sms_mobile = M('sms_log');
        $member_common_info = $sms_mobile->where(array('username' => $username, 'log_type' => 5))->find();

        if ($member_common_info) {
            if (date('Ymd', $member_common_info['add_time']) != date('Ymd', time())) {
                $data = array();
                $data['log_num'] = 0;
                $update = $sms_mobile->where((array('username' => $username, 'log_type' => 5)))->save($data);
                $member_common_info = $sms_mobile->where(array('username' => $username, 'log_type' => 5))->find();
            } else {
                if (time() - $member_common_info['add_time'] < 60) {
                    echo $this->returnErrorInfo(array("customMessage" => "请60s以后再发送"));
                    exit;
                } else {
                    if ($member_common_info['log_num'] >= 10) {
                        echo $this->returnErrorInfo(array("customMessage" => "今天短信已超10条，无法发送!"));
                        exit;
                    }
                }
            }
        }

        $verify_code = rand(100, 999) . rand(100, 999);
        $sms = new \Common\Sms\Sms();
        $result = $sms->mysend_aliyun($username, $verify_code); //发送短信调用
//        $result=true;
        if ($result) {
            $data = array();
            $update_data['log_phone'] = $username;
            $update_data['log_captcha'] = $verify_code;
            $update_data['log_msg'] = "";
            $update_data['add_time'] = time();
            ;
            $update_data['uid'] = 0;
            $update_data['username'] = $username;
            $update_data['log_type'] = 5;
            $update_data['log_num'] = $member_common_info['log_num'] + 1;
            if ($member_common_info) {
                $result = $sms_mobile->where((array('username' => $username, 'log_type' => 5)))->save($update_data);
            } else {
                $result = $sms_mobile->add($update_data);
            }
            if ($result) {
                echo $this->returnSuccessInfo(array("customMessage" => "验证码发送成功!"));
                exit;
            }
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "验证码发送失败!"));
            exit;
        }
    }

    //交易记录
    public function defraylog() {
        $userInfo = $this->userInfo;
        $delogModel = M('DefrayrcLog');
        $delog = $delogModel
                ->field('a.*,
                    b.bank_name,
                    b.nub')
                ->alias('a')
                ->join('LEFT JOIN __DEFRAYRC__ as b ON a.rc_id=b.id')
                ->where('a.uid=' . $userInfo['uid'])
                ->order('a.id desc')
                ->select();
        foreach ($delog as $k => $v) {
            $data[$k]['id'] = $v['id'];
            $data[$k]['bank_name'] = $v['bank_name'];
            $data[$k]['money'] = $v['money'];
            $data[$k]['fee'] = $v['fee'];
            $data[$k]['pay_order'] = $v['pay_order'];
            $data[$k]['create_time'] = date('Y-m-d', $v['create_time']);
            $data[$k]['out_status'] = $v['out_status'];
            $data[$k]['in_status'] = $v['in_status'];
        }

        echo $this->returnSuccessInfo(array("data" => array('data' => $data)));
    }

    /*     * *******************二维码推广******************* */

    public function qr() {
        $userInfo = $this->userInfo;
        $data['qr_url'] = 'http://crm.szinternet.com/Api/Hwu/register?rer=' . $userInfo['username'];
        echo $this->returnSuccessInfo(array("data" => $data));
    }

    //下载地址
    public function url() {
        $data['url'] = 'http://crm.szinternet.com/Api/Hwu/download';
        echo $this->returnSuccessInfo(array("data" => $data));
    }

//$data=array('data'=>array(
//"0"=>array('type'=>"1",'times'=>"1",'money'=>"20",'create_time'=>"2018-01-19"),
//"1"=>array('type'=>"1",'times'=>"2",'money'=>"20",'create_time'=>"2018-01-19"),
//"2"=>array('type'=>"1",'times'=>"3",'money'=>"20",'create_time'=>"2018-01-19"),
//"3"=>array('type'=>"1",'times'=>"4",'money'=>"20",'create_time'=>"2018-01-19"),
//"4"=>array('type'=>"2",'times'=>"1",'money'=>"10",'create_time'=>"2018-01-19"),
//"5"=>array('type'=>"2",'times'=>"2",'money'=>"10",'create_time'=>"2018-01-19"),
//"6"=>array('type'=>"2",'times'=>"3",'money'=>"10",'create_time'=>"2018-01-19"),
//"7"=>array('type'=>"2",'times'=>"4",'money'=>"10",'create_time'=>"2018-01-19"),
//"8"=>array('type'=>"2",'times'=>"5",'money'=>"10",'create_time'=>"2018-01-19"),
//"9"=>array('type'=>"2",'times'=>"6",'money'=>"10",'create_time'=>"2018-01-19"),
//"10"=>array('type'=>"2",'times'=>"7",'money'=>"10",'create_time'=>"2018-01-19"),
//"11"=>array('type'=>"2",'times'=>"8",'money'=>"10",'create_time'=>"2018-01-19")));
}
