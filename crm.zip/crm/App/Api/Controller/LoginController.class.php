<?php
namespace Api\Controller;
use Think\Controller;
//use Common\Sms\Sms;
class LoginController extends Controller{

	public function __construct(){

		parent::__construct();

	}
    /*******用户登录*******/
    public function login(){
        $data['username'] = I('post.username');//用户名
        $data['password'] = I('post.password');//用户密码
        $data['client'] = intval(I('post.client'));//设备
//         $information['username'] = 'NI125O';//用户名
//         $information['password'] = 'NI125O';//用户密码
        if(!preg_match("/^1[34578]{1}\d{9}$/",$data['username'])){
            echo $this->returnErrorInfo(array("customMessage" =>"请输入11位正确手机号码!"));
            exit;
        }
        if(!preg_match('/^[a-zA-Z0-9]{6,15}$/',$data['password'])){
            echo $this->returnErrorInfo(array("customMessage" =>"请输入6-15位正确密码!"));
            exit;
        }
        $userModel=M('User');
        $check=$userModel->where(array('username'=>$data['username'],'password'=>MD5($data['password'])))->find();
        if(empty($check)){
            echo $this->returnErrorInfo(array("customMessage" =>"手机号与密码不正确!"));
            exit;
        }else if($check['enable']==1){
            echo $this->returnErrorInfo(array("customMessage"=>"帐号被禁止登录，请联系客服"));
            exit;
        }else{
            $token=$this->proToken($check['username']);
            $utoken['uid']=$check['id'];
            $smsModel=M('UserToken');
            $smsResult=$smsModel->where(array('uid'=>$check['id']))->find();
            if($smsResult){//更新状态
                $smsModel->where(array('uid'=>$check['id']))->save(array('token'=>$token,'create_time'=>time(),'client_type'=>$data['client'], 'login_ip'=>get_client_ip(),));
            }else{//插入数据
                $smsModel->add(array('uid'=>$check['id'],
                                      'username'=>$check['username'],
                                      'token'=>$token,
                                      'create_time'=>time(),
                                      'login_ip'=>get_client_ip(),
                                      'client_type'=>$data['client']));
            }
            $array['username']=$check['username'];
            $array['nickname']=$check['nickname'];
            $array['token']=$token;
            $array['img_url']=$check['img_url'];
            $array['parent_id']=$check['parent_id'];
            //会员等级
            $gradeModel=M('Grade');
            $grade=$gradeModel->field('grade_name')->where('grade='.$check['grade'])->find();
            $array['grade']=$grade['grade_name'];
            //是否实名认证
            $userBankModel=M('UserBank');
            $userBank=$userBankModel->where(array('username'=>$data['username'],'type'=>1))->find();
            if($userBank){
                $array['real']="have";
            }else{
                $array['real']="no";
            }
            $array['expire']=14400;
            $userBank=M('');
            session(C('APP_SESSION'),$array);
            echo $this->returnSuccessInfo(array("customMessage" =>"登录成功!",'data'=>$array));
            exit;
        }

    }
    public function aa(){
        $aa= new \Common\Pay\Pay();
        $aa->pay();

    }
    /********用户退出**********/
    public function logout(){
        $token=I('post.token');

        if(!preg_match("/^[a-z0-9]{32}$/", $token)){
            echo $this->returnErrorInfo(array("customMessage" =>"非法token!"));
            exit;
        }
        $userToken=M('UserToken');
        $checkToken=$userToken->where(array('token'=>$token))->find();

        if(!$checkToken){
            echo $this->returnErrorInfo(array("customMessage" =>"注销失败!"));
            exit;
        }else{
            $userToken->where(array('uid'=>$checkToken['uid']))->save(array('token'=>'1'));
            echo $this->returnSuccessInfo(array("customMessage" =>"退出帐号成功!"));
            exit;
        }

    }
    /********用户注册******/
    public function register(){
        $username = I('post.username');
        $password = I('post.password');
        $code= I('code');
        $rer = I('rer');
        if(!preg_match("/^1[34578]{1}\d{9}$/",$username)){
            echo $this->returnErrorInfo(array("customMessage" =>"请输入11位正确手机号码!"));
            exit;
        }
        $userModel=M('User');
        if(!preg_match('/^[a-zA-Z0-9]{6,15}$/',$password)){
            echo $this->returnErrorInfo(array("customMessage" =>"请输入6-15位密码!"));
            exit;
        }
        if(!empty($rer)){
            if(!preg_match("/^1[34578]{1}\d{9}$/",$rer)){
                echo $this->returnErrorInfo(array("customMessage" =>"请输入正确推荐人号码!"));
                exit;
            }
            if($username==$rer){
                echo $this->returnErrorInfo(array("customMessage" =>"推荐人号码与帐号不能相同!"));
                exit;
            }
            $rerResult=$userModel->where(array('username'=>$rer))->find();
            if(!$rerResult){
                echo $this->returnErrorInfo(array("customMessage" =>"推荐人号码不存在!"));
                exit;
            }
            $array['parent_id']=$rer;
        }
        if(!is_numeric($code)){
            echo $this->returnErrorInfo(array("customMessage" =>"请输入正确验证码格式!"));
            exit;
        }

//        if(!preg_match('/^[a-zA-Z0-9]{6,15}$/',$password_re)){
//            echo $this->returnErrorInfo(array("customMessage" =>"请输入6-15位确认密码!"));
//            exit;
//        }
//        if($password!=$password_re){
//            echo $this->returnErrorInfo(array("customMessage" =>"密码和确认密码不正确!"));
//            exit;
//        }
        $userResult=$userModel->where(array('username'=>$username))->find();
        if($userResult){
            echo $this->returnErrorInfo(array("customMessage" =>"帐号已注册!"));
            exit;
        }
        //验证码查询
        $smsModel=M('SmsLog');
        $smsResult=$smsModel->where(array('username'=>$username,'log_type'=>1,'log_captcha'=>$code))->find();
        if(!$smsResult){
            echo $this->returnErrorInfo(array("customMessage" =>"验证码错误!"));
            exit;
        }else{
            if((time()-$smsResult['add_time'])>300){
                echo $this->returnErrorInfo(array("customMessage" =>"验证码超时!"));
                exit;
            }
        }

        //插入user表
        $array['username']=$username;
        $array['password']=MD5($password);
        $array['reg_ip']=get_client_ip();
        $array['update_time']=time();
        $array['create_time']=time();
        $array['img_url']=C('API_IMG')."default.jpg";
        $result=$userModel->add($array);
        //插入token表
        $token=$this->proToken($username);
        $array2['uid']=$result;
        $array2['username']=$username;
        $array2['token']=$token;
        $array2['login_ip']=get_client_ip();
        $array2['create_time']=time();
        $array2['client_type']=0;
        $tokenModel=M('UserToken');
        $id=$tokenModel->add($array2);

        if($result){
            echo $this->returnSuccessInfo(array("customMessage" =>"注册成功!",'data'=>array('username'=>$username,'token'=>$token,'uid'=>$result)));
            exit;
        }else{
            echo $this->returnErrorInfo(array("customMessage" =>"注册失败!"));
            exit;
        }
    }
    /********忘记密码**************/
    public function updatepwd(){
        $username = I('post.username');
        $password = I('post.password');
        $password_re = I('post.password_re');
        $code= I('code');
        if(!preg_match("/^1[34578]{1}\d{9}$/",$username)){
            echo $this->returnErrorInfo(array("customMessage" =>"请输入11位正确手机号码!"));
            exit;
        }
        if(!preg_match('/^[a-zA-Z0-9]{6,15}$/',$password)){
            echo $this->returnErrorInfo(array("customMessage" =>"请输入6-15位密码!"));
            exit;
        }
        if(!preg_match('/^[a-zA-Z0-9]{6,15}$/',$password_re)){
            echo $this->returnErrorInfo(array("customMessage" =>"请输入6-15位密码!"));
            exit;
        }
        if(!is_numeric($code)){
            echo $this->returnErrorInfo(array("customMessage" =>"请输入正确验证码格式!"));
            exit;
        }
        if($password!=$password_re){
            echo $this->returnErrorInfo(array("customMessage" =>"密码和确认密码不相同!"));
            exit;
        }
        $userModel=M('User');
        $userResult=$userModel->where(array('username'=>$username))->find();
        if(empty($userResult)){
            echo $this->returnErrorInfo(array("customMessage" =>"帐号不存在!"));
            exit;
        }
        //验证码查询
        $smsModel=M('SmsLog');
        $smsResult=$smsModel->where(array('username'=>$username,'log_type'=>3,'log_captcha'=>$code))->find();
        if(!$smsResult){
            echo $this->returnErrorInfo(array("customMessage" =>"验证码错误!"));
            exit;
        }else{
            if((time()-$smsResult['add_time'])>300){
                echo $this->returnErrorInfo(array("customMessage" =>"验证码超时!"));
                exit;
            }
        }
        //修改user表
        $result=$userModel->where('id='.$userResult['id'])->save(array('password'=>MD5($password)));

        if($result){
            echo $this->returnSuccessInfo(array("customMessage" =>"修改成功!"));
            exit;
        }else{
            echo $this->returnErrorInfo(array("customMessage" =>"修改失败!"));
            exit;
        }
    }

    /**
     *生成token
     * $id为用户Id
     */
    public function proToken($name){
        $token = md5($name. strval(time()) . strval(rand(0,999999)));
        return $token;
    }
    /**
     * @describe 注册发送短信
     */
    public function registersent(){
        $username=I('post.username');
        if (!$username || !preg_match('/^\d{11}$/',$username)) {
            echo $this->returnErrorInfo(array("customMessage" =>"请输入11位正确手机号码!"));
            exit;
        }
        $userModel= M('User');
        //验证手机号码绑定
        $checkUser = $userModel->where(array('username'=>$username))->find();
        if(!empty($checkUser)) {
            echo $this->returnErrorInfo(array("customMessage" =>"帐号已被注册!"));
            exit;
        }
        //发送频率验证
        $sms_mobile= M('sms_log');
        $member_common_info= $sms_mobile->where(array('username'=>$username,'log_type'=>1))->find();

        if($member_common_info){
            if(date('Ymd',$member_common_info['add_time']) != date('Ymd',time())){
                $data = array();
                $data['log_num'] = 0;
                $update = $sms_mobile->where((array('username'=>$username,'log_type'=>1)))->save($data);
                $member_common_info= $sms_mobile->where(array('username'=>$username,'log_type'=>1))->find();
            }else{
                if (time() - $member_common_info['add_time'] < 60) {
                    echo $this->returnErrorInfo(array("customMessage" =>"请60s以后再发送"));
                    exit;
                } else {
                    if ($member_common_info['log_num'] >= 10) {
                        echo $this->returnErrorInfo(array("customMessage" =>"今天短信已超10条，无法发送!"));
                        exit;
                    }
                }
            }

        }

        $verify_code = rand(100,999).rand(100,999);
        $sms = new \Common\Sms\Sms();
        $result = $sms->mysend_aliyun($username,$verify_code); //发送短信调用
//        $result=true;
        if ($result) {
            $data = array();
            $update_data['log_phone'] = $username;
            $update_data['log_captcha'] = $verify_code;
            $update_data['log_msg'] = "";
            $update_data['add_time'] = time();;
            $update_data['uid'] = 0;
            $update_data['username'] = $username;
            $update_data['log_num'] = $member_common_info['log_num']+1;
            if($member_common_info){
                $result=$sms_mobile->where((array('username'=>$username,'log_type'=>1)))->save($update_data);
            }else{
                $result=$sms_mobile->add($update_data);
            }
            if($result){
                echo $this->returnSuccessInfo(array("customMessage" =>"验证码发送成功!"));
                exit;
            }

        } else {
            echo $this->returnErrorInfo(array("customMessage" =>"验证码发送失败!"));
            exit;
        }

    }
    /**
     * @describe 忘了密码发送短信
     */
    public function updatepwdsent(){
        $username=I('post.username');
        if (!$username || !preg_match('/^\d{11}$/',$username)) {
            echo $this->returnErrorInfo(array("customMessage" =>"请输入11位正确手机号码!"));
            exit;
        }
        $userModel= M('User');
        //验证手机号码绑定
        $checkUser = $userModel->where(array('username'=>$username))->find();
        if(empty($checkUser)) {
            echo $this->returnErrorInfo(array("customMessage" =>"帐号不存在!"));
            exit;
        }
        //发送频率验证
        $sms_mobile= M('sms_log');
        $member_common_info= $sms_mobile->where(array('username'=>$username,'log_type'=>3))->find();

        if($member_common_info){
            if(date('Ymd',$member_common_info['add_time']) != date('Ymd',time())){
                $data = array();
                $data['log_num'] = 0;
                $update = $sms_mobile->where((array('username'=>$username,'log_type'=>3)))->save($data);
                $member_common_info= $sms_mobile->where(array('username'=>$username,'log_type'=>3))->find();
            }else{
                if (time() - $member_common_info['add_time'] < 60) {
                    echo $this->returnErrorInfo(array("customMessage" =>"请60s以后再发送"));
                    exit;
                } else {
                    if ($member_common_info['log_num'] >= 10) {
                        echo $this->returnErrorInfo(array("customMessage" =>"今天短信已超10条，无法发送!"));
                        exit;
                    }
                }
            }

        }

        $verify_code = rand(100,999).rand(100,999);
        $sms = new \Common\Sms\Sms();
        $result = $sms->mysend_aliyun($username,$verify_code); //发送短信调用
//        $result=true;
        if ($result) {
            $data = array();
            $update_data['log_phone'] = $username;
            $update_data['log_captcha'] = $verify_code;
            $update_data['log_msg'] = "";
            $update_data['add_time'] = time();;
            $update_data['uid'] = 0;
            $update_data['username'] = $username;
            $update_data['log_type'] = 3;
            $update_data['log_num'] = $member_common_info['log_num']+1;
            if($member_common_info){
                $result=$sms_mobile->where((array('username'=>$username,'log_type'=>3)))->save($update_data);
            }else{
                $result=$sms_mobile->add($update_data);
            }
            if($result){
                echo $this->returnSuccessInfo(array("customMessage" =>"验证码发送成功!"));
                exit;
            }

        } else {
            echo $this->returnErrorInfo(array("customMessage" =>"验证码发送失败!"));
            exit;
        }
    }


    /**
     *  @$parameter：    传递的参数，为数组的形式。
     *                  例如：array("messageCode"=>"100010","customMessage"=>"自定义提示信息。","data"=>data);
     *                  参数顺序不分先后，参数可全部为空，也可全部传入或选择性传入。
     *  @$messageCode：  返回提示信息的代码，$infoConfig配置数组的信息提示代码。可不传入
     *  @$customMessage：  自定义提示信息。可不传入
     *  @$data：  返回的数据。可不传入
     */
    public function returnSuccessInfo($parameter = array())
    {
        $message = isset($parameter["messageCode"]) ? $this->infoConfig[$parameter["messageCode"]] : "";
        $code = isset($parameter["code"]) ? $parameter["code"] : 1;
        $customMessage = isset($parameter["customMessage"]) ? $parameter["customMessage"] : "";
        $ramete["data"] = (object)array();
        $data = isset($parameter["data"]) ? $parameter["data"] : $ramete["data"];
        $message = $message . $customMessage;
        $result = array(
            "code" => $code,
            "message" => $message,
            "data" => $data
        );
        return str_replace("\\/","/",json_encode($result,JSON_UNESCAPED_UNICODE));
    }
    //返回失败的信息
    /**
     *  @$parameter：    传递的参数，为数组的形式。
     *                  例如：array("messageCode"=>"100010","customMessage"=>"自定义提示信息。","data"=>data);
     *                  参数顺序不分先后，参数可全部为空，也可全部传入或选择性传入。
     *  @$messageCode：  返回提示信息的代码，$infoConfig配置数组的信息提示代码。可不传入
     *  @$customMessage：  自定义提示信息。可不传入
     *  @$data：  返回的数据。可不传入
     */
    public function returnErrorInfo($parameter = array())
    {
        $message = isset($parameter["messageCode"]) ? $this->infoConfig[$parameter["messageCode"]] : "";
        $code = isset($parameter["code"]) ? $parameter["code"] : 0;
        $customMessage = isset($parameter["customMessage"]) ? $parameter["customMessage"] : "";
        $ramete["data"] = (object)array();
        $data = isset($parameter["data"]) ? $parameter["data"] : $ramete["data"];
        $message = $message . $customMessage;
        $result = array(
            "code" => $code,
            "message" => $message,
            "data" => $data
        );

        return str_replace("\\/","/",json_encode($result,JSON_UNESCAPED_UNICODE));
    }

}