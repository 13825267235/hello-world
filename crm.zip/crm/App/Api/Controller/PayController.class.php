<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Api\Controller;

use Think\Controller;

/*
 * 支付通道（所有）
 * 所有同步、异步通知都返回到这里
 * @林
 */

class PayController extends Controller {
    /*
     * sam家异步通知
     */

    public function samNotifyUrl() {
        //支付成功才会有异步通知
        //此通道已经成功刷卡200元，扣费1.3
        $val = I('post.');
        if ($val) {
            file_put_contents('sam_log.txt', $val, FILE_APPEND);
        } else {
            file_put_contents('sam_log.txt', '出错了', FILE_APPEND);
            echo '出错了，没有获取到结果';
        }
    }

    /*
     * sam家同步通知
     */

    public function samReturnUrl() {
        $info = I("post.");
        print_r($info);
    }

}
