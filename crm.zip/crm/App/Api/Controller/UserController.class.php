<?php

namespace Api\Controller;

class UserController extends ApiBasicController {

    //构造方法
    public function __construct() {
        parent::__construct();
    }

    //主页
    public function index() {
        $userInfo = $this->userInfo;
        //是否实名认证
        $userBankModel = M('UserBank');
        $userBank = $userBankModel->where(array('username' => $userInfo['$userInfo']))->find();
    }

    //上传头像
    public function upload() {
        $userInfo = $this->userInfo;
        //上传文件
        $file = $_FILES['img'];
//
        if ($file['tmp_name'] == "") {
            echo $this->returnErrorInfo(array("customMessage" => "上传图片不能为空!"));
            exit;
        }
        //验证文件大小
        if ($file['size'] == 0) {
            echo $this->returnErrorInfo(array("customMessage" => "上传图片大小不能为0!"));
            exit;
        }
        if ($file['size'] > 1024 * 1024) {
            echo $this->returnErrorInfo(array("customMessage" => "上传图片大小不能超过1M!"));
            exit;
        }
        //验证文件类型
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION); //获取文件扩展名
        $arrExt = array('gif', 'jpg', 'jpeg', 'bmp', 'png', 'swf', 'tbi');
        if (!in_array($ext, $arrExt)) {
            echo $this->returnErrorInfo(array("customMessage" => "不支持此类型文件的上传!"));
            exit;
        }
        //检查是否为有效图片
        if (!@getimagesize($file['tmp_name'])) {
            echo $this->returnErrorInfo(array("customMessage" => "不是有效图片!"));
            exit;
        }

        $filenamestime = $userInfo['uid'] . ((time()) + 1);
        $filenames = $filenamestime . '.' . $ext;

        if (move_uploaded_file($file['tmp_name'], substr(C('API_IMG'), 1) . $filenames)) {
            $userModel = M('User');
            $result = $userModel->where('id=' . $userInfo['uid'])->save(array('img_url' => C('API_IMG') . $filenames));
            if ($result) {
                echo $this->returnSuccessInfo(array("customMessage" => "上传成功!", 'data' => array('img_url' => C('API_IMG') . $filenames)));
                exit;
            } else {
                echo $this->returnErrorInfo(array("customMessage" => "上传失败!"));
                exit;
            }
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "上传失败!"));
            exit;
        }
    }

    /*     * *******修改密码******* */

    public function updatepwd() {
        $password = I('post.password');
        $newpassword = I('post.newpassword');
        $newpasswords = I('post.newpasswords');
        if (!preg_match('/^[a-zA-Z0-9]{6,15}$/', $password)) {
            echo $this->returnErrorInfo(array("customMessage" => "请输入6-15位旧密码,密码为字母或数字!"));
            exit;
        }
        if (!preg_match('/^[a-zA-Z0-9]{6,15}$/', $newpassword)) {
            echo $this->returnErrorInfo(array("customMessage" => "请输入6-15位新密码,密码为字母或数字!"));
            exit;
        }
        if (!preg_match('/^[a-zA-Z0-9]{6,15}$/', $newpasswords)) {
            echo $this->returnErrorInfo(array("customMessage" => "请输入6-15位确认密码,密码为字母或数字!"));
            exit;
        }
        if ($newpassword != $newpasswords) {
            echo $this->returnErrorInfo(array("customMessage" => "两次密码不相同!"));
            exit;
        }
        //查询密码
        $userModel = M('User');
        $userInfo = $this->userInfo;
        $checkPwd = $userModel->where('id=' . $userInfo['uid'])->find();
        if ($checkPwd['password'] != MD5($password)) {
            echo $this->returnErrorInfo(array("customMessage" => "旧密码不正确!"));
            exit;
        }
        if ($password == $newpassword) {
            echo $this->returnErrorInfo(array("customMessage" => "新密码不能与旧密码相同!"));
            exit;
        }
        $result = $userModel->where('id=' . $userInfo['uid'])->setField('password', MD5($newpassword));
        if ($result) {
            session(C('APP_SESSION'), null);
            echo $this->returnSuccessInfo(array("customMessage" => "修改成功!"));
            exit;
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "修改失败!"));
            exit;
        }
    }

    /*     * ******实名认证***** */

    public function realname() {
        $userInfo = $this->userInfo;
        $data['uid'] = $userInfo['uid'];
        $data['username'] = $userInfo['username'];
        $nickname = I('post.nickname');
        $data['realname'] = I('post.realname');
        $data['ic'] = I('post.ic');
        $data['bank_id'] = I('post.bank_id');
        $data['bank_name'] = I('post.bank_name');
        $data['account'] = I('post.account');
        $data['countname'] = I('post.countname');
        $data['phone'] = I('post.phone');
        $data['create_time'] = time();
        $data['type'] = 1;
        $data['code'] = I('post.code');
        $data['image'] = I('post.image'); //人脸头像

        /*         * *******************实名认证****************** */

//        $bankModel=M('UserBank');
        $bankModel = M('user_bank');
        $checkBank = $bankModel->where("uid=" . $userInfo['uid'] . " and type =0")->find();
        if ($checkBank) {
            echo $this->returnErrorInfo(array("customMessage" => "正在审核", 'code' => 3));
            exit;
        }
        $checkBanks = $bankModel->field('realname,ic')->where("uid=" . $userInfo['uid'] . " and type =1")->find();
        if ($checkBanks) {
            $userModel = M('User');
            $user = $userModel->field('nickname')->where(array('id=' . $userInfo['uid']))->find();

            $checkBanks['nickname'] = $user['nickname'];
            echo $this->returnErrorInfo(array("customMessage" => '', 'data' => $checkBanks, 'code' => 2));
            exit;
        }
        if (!preg_match("/^[\x{4e00}-\x{9fa5}]{2,6}$/u", $data['realname'])) {
            echo $this->returnErrorInfo(array("customMessage" => "名字格式有误"));
            exit;
        }
        if (!is_numeric($data['ic'])) {
            echo $this->returnErrorInfo(array("customMessage" => "身份证格式不对!"));
            exit;
        }
        if (!is_numeric($data['bank_id'])) {
            echo $this->returnErrorInfo(array("customMessage" => "银行ID非法!"));
            exit;
        }
        if (!preg_match("/^[\x{4e00}-\x{9fa5}]{2,20}$/u", $data['bank_name'])) {
            echo $this->returnErrorInfo(array("customMessage" => "银行名格式有误"));
            exit;
        }
        if (!is_numeric($data['account'])) {
            echo $this->returnErrorInfo(array("customMessage" => "银行卡号格式有误"));
            exit;
        }
        if (!preg_match("/^[\x{4e00}-\x{9fa5}]{1,50}$/u", $data['countname'])) {
            echo $this->returnErrorInfo(array("customMessage" => "开户支行格式位大写汉字"));
            exit;
        }
        if (!is_numeric($data['phone'])) {
            echo $this->returnErrorInfo(array("customMessage" => "手机格式有误"));
            exit;
        }
        if (!is_numeric($data['code'])) {
            echo $this->returnErrorInfo(array("customMessage" => "验证码有误"));
            exit;
        }

        //检测身份证是否已经验证  待商议

        /*         * *****银行卡验证接口******** */
        $realName = new \Common\Check\RealName();
        $rel = $realName->checkId($data['realname'], $data['ic'], $data['account'], $data['phone']);

        if ($rel['reason']) {
            //其他情况
            echo $this->returnErrorInfo(array("customMessage" => $rel['reason']));
            exit;
        }

        if ($rel['customMessage']) {
            //获取用户的身份证号
            $user_info = M("user_bank")->field("ic,realname")->where('uid=' . $userInfo['uid'])->find();
            //匹配失败
            if ($user_info['realname'] != $data['realname']) {
                echo $this->returnErrorInfo(array("customMessage" => '姓名不正确'));
                exit;
            }
            echo $this->returnErrorInfo(array("customMessage" => '请输入正确信息'));
            exit;
        }


        //银行名字
        $banksModel = M('bank');
        $banks = $banksModel->where(array('id=' . $data['bank_id']))->find();
        $data['bank_name'] = $banks['bank_name'];
        //短信验证码
        $smsModel = M('SmsLog');
        $checkSms = $smsModel->where(array('username' => $data['phone'], 'log_type' => 4, 'log_captcha' => $data['code']))->find();
        if (!$checkSms) {
            echo $this->returnErrorInfo(array("customMessage" => "验证码错误!"));
            exit;
        } else {
            if (($checkSms['add_time'] - time()) < -300) {
                echo $this->returnErrorInfo(array("customMessage" => "验证码超时!"));
                exit;
            }
        }

        //插入user_bank表
        $result = $bankModel->add($data);
        //跟新昵称 认证信息
        $userModel = M('User');
        $result2 = $userModel->where(array('id' => $userInfo['uid']))->save(array('nickname' => $nickname, 'is_realname' => 1, 'id_card' => $data['ic']));

        if ($result) {
            echo $this->returnSuccessInfo(array("customMessage" => "提交成功"));
            exit;
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "提交失败"));
            exit;
        }
    }

    /*
     * 实名认证
     * 增加头像认证
     */

    public function checkMan() {


        /**         * ****实名验证接口******** */
        $data['realname'] = I('post.realname');
        $data['idcard'] = I('post.idcard');
        $data['image'] = I('post.image');

        $realName = new \Common\Check\RealName();
        $rel = $realName->checkMan($data['realname'], $data['idcard'], $data['image']);
        if ($rel['customMessage']['Code'] == 0 && $rel['customMessage']['Data'] > 75) {
            echo $this->returnSuccessInfo(array("customMessage" => "实名认证成功", 'data' => $data));
            exit;
        } else {
            print_r($rel);
//            echo $this->returnErrorInfo(array("customMessage" => $rel['customMessage']['Msg'], 'code' => 1));
            exit;
        }
    }

    /*
     * 人脸比对初始化接口
     */

    public function getInitInfo() {

        $bizId = 'wy_' . date("YmdHis") . rand(100, 999); //接入方请求的唯一标识，由字母、数字、下划线组成，须确保其唯一性
        $realname = I("post.realname");
        $idcard = I('post.idcard');
        $metainfo1 = I('post.metainfo'); //环境参数，需要通过客户端SDK获取,详见刷脸认证iOS和Android客户端接入指南
//        $metainfo1 = '{&quot;zimVer&quot;:&quot;3.0.0&quot;,&quot;appVersion&quot;:&quot;1&quot;,&quot;bioMetaInfo&quot;:&quot;3.3.0:98304,4&quot;,&quot;appName&quot;:&quot;com.moresc.phone&quot;,&quot;deviceType&quot;:&quot;ios&quot;,&quot;osVersion&quot;:&quot;iOS11.3.1&quot;,&quot;apdidToken&quot;:&quot;/37uEFYwmNJG47nmbbwgDym2rPu8kGBQQ1cNP9xVi8AR8TTdYwEAAA==&quot;,&quot;deviceModel&quot;:&quot;iPhone9,2&quot;}';

        $a = htmlspecialchars_decode($metainfo1);
        $b = json_decode($a, true);
        $metainfo = $b;

        if (empty($realname) || empty($idcard) || empty($metainfo)) {
            echo $this->returnErrorInfo(array("customMessage" => '请传入必须的参数'));
            exit;
        }

        $inits = new \Common\Check\RealName();
        $data = $inits->faceVerifyInit($bizId, $realname, $idcard, $metainfo);
        $datas['bizId'] = $bizId;
        $datas['zimId'] = $data['customMessage'];
        $datas['realname'] = $realname; //这两个参数看情况再决定给还是不给
        $datas['idcard'] = $idcard;
        if ($data) {
            //初始化sdk成功
            echo $this->returnSuccessInfo(array("customMessage" => 'SDK初始化成功', 'data' => $datas));
            exit;
        } else {
            //初始化失败
            echo $this->returnErrorInfo(array("customMessage" => 'SDK初始化失败'));
            exit;
        }
    }

    /*
     * 人脸比对认证结束
     * 返回认证结果给客户端，告知用户
     */

    public function getVerifyInfo() {
        //获取客户端传送过来的信息
        $bizId = I('post.bizId'); //初始化时传入的bizId
        $zimId = I('post.zimId'); //初始化时获得的id
        //以下data用于下一步
        $data['username'] = I("post.realname");
        $data['idcard'] = I('post.idcard');

        $info = new \Common\Check\RealName();
        $infos = $info->faceVerifyFetch($bizId, $zimId);

//        $bb = str_replace('{', '', $infos);
//        $bb = str_replace('}', '', $bb);
//        $bb = explode(',', $bb);
//        foreach ($bb as $k => $v) {
//            $info = explode(':', $v);
//            $key = str_replace('"', '', $info[0]);
//            $value = str_replace('"', '', $info[1]);
//            $result[$key] = $value;
//        }
//        
//        echo $this->returnErrorInfo(array("customMessage" => '第三方返回的结果', 'data' => $infos));
//        exit;

        $result=$infos;
        if ($result['resultCode'] == 'Z8300') {
            echo $this->returnSuccessInfo(array("customMessage" => '刷脸认证成功', 'data' => $data));
            exit;
        } else if ($result['resultCode'] == 'Z8301') {//17个代码数字
            echo $this->returnErrorInfo(array("customMessage" => '传入参数不正确'));
            exit;
        } else if ($result['resultCode'] == 'Z1146') {
            echo $this->returnErrorInfo(array("customMessage" => '刷脸认证未通过'));
            exit;
        } else if ($result['resultCode'] == 'Z8399' || $result['resultCode'] == 'Z5137') {
            echo $this->returnErrorInfo(array("customMessage" => '出错了，请稍后再试'));
            exit;
        } else if ($result['resultCode'] == 'Z8302') {
            echo $this->returnErrorInfo(array("customMessage" => '当前租户未开通刷脸认证产品'));
            exit;
        }

//        if ($result['resultCode'] == 'OK') {
//            echo $this->returnSuccessInfo(array("customMessage" => '刷脸认证成功', 'data' => $data));
//            exit;
//        } else if ($result['resultCode'] == 'INVALID_PARAMETER') {//17个代码数字
//            echo $this->returnErrorInfo(array("customMessage" => '传入参数不正确'));
//            exit;
//        } else if ($result['resultCode'] == 'NOT_SAME_PERSON') {
//            echo $this->returnErrorInfo(array("customMessage" => '刷脸认证未通过'));
//            exit;
//        } else if ($result['resultCode'] == 'SYSTEM_ERROR' || $result['resultCode'] == 'PROCESSING') {
//            echo $this->returnErrorInfo(array("customMessage" => '出错了，请稍后再试'));
//            exit;
//        } else if ($result['resultCode'] == 'PRODUCT_NOT_OPEN') {
//            echo $this->returnErrorInfo(array("customMessage" => '当前租户未开通刷脸认证产品'));
//            exit;
//        }
    }

    //实名短信发送
    public function realnamesent() {
        $username = I('post.phone');
        if (!$username || !preg_match('/^\d{11}$/', $username)) {
            echo $this->returnErrorInfo(array("customMessage" => "请输入11位正确手机号码!"));
            exit;
        }
        $userModel = M('User');
        //验证手机号码绑定
//        $checkUser = $userModel->where(array('username'=>$username))->find();
//        if(!empty($checkUser)) {
//            echo $this->returnErrorInfo(array("customMessage" =>"帐号已被注册!"));
//            exit;
//        }
        //发送频率验证
        $sms_mobile = M('sms_log');
        $member_common_info = $sms_mobile->where(array('username' => $username, 'log_type' => 4))->find();

        if ($member_common_info) {
            if (date('Ymd', $member_common_info['add_time']) != date('Ymd', time())) {
                $data = array();
                $data['log_num'] = 0;
                $update = $sms_mobile->where((array('username' => $username, 'log_type' => 4)))->save($data);
                $member_common_info = $sms_mobile->where(array('username' => $username, 'log_type' => 4))->find();
            } else {
                if (time() - $member_common_info['add_time'] < 60) {
                    echo $this->returnErrorInfo(array("customMessage" => "请60s以后再发送"));
                    exit;
                } else {
                    if ($member_common_info['log_num'] >= 10) {
                        echo $this->returnErrorInfo(array("customMessage" => "今天短信已超10条，无法发送!"));
                        exit;
                    }
                }
            }
        }

        $verify_code = rand(100, 999) . rand(100, 999);
        $sms = new \Common\Sms\Sms();
        $result = $sms->mysend_aliyun($username, $verify_code); //发送短信调用
//        $result=true;
        if ($result) {
            $data = array();
            $update_data['log_phone'] = $username;
            $update_data['log_captcha'] = $verify_code;
            $update_data['log_msg'] = "";
            $update_data['add_time'] = time();
            ;
            $update_data['uid'] = 0;
            $update_data['username'] = $username;
            $update_data['log_type'] = 4;
            $update_data['log_num'] = $member_common_info['log_num'] + 1;
            if ($member_common_info) {
                $result = $sms_mobile->where((array('username' => $username, 'log_type' => 4)))->save($update_data);
            } else {
                $result = $sms_mobile->add($update_data);
            }
            if ($result) {
                echo $this->returnSuccessInfo(array("customMessage" => "验证码发送成功!"));
                exit;
            }
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "验证码发送失败!"));
            exit;
        }
    }

    //银行列表
    public function banklist() {
        $bankModel = M('bank');
        $bank = $bankModel->field('id as ids,bank_name')->where('is_used=0 and bank_type=0')->select();
        echo $this->returnSuccessInfo(array("customMessage" => "", 'data' => array('data' => $bank)));
        exit;
    }

    /*     * ******我的消息** */

    public function mynews() {
        $userInfo = $this->userInfo;
        //系统消息
        $newsModel = M('News');
        $sysnews = $newsModel->field('id,titles,contents,create_time')->where('is_delete=0')->order('id desc')->find();
        if ($sysnews) {
            $sysnews['create_time'] = date('Y-m-d', $sysnews['create_time']);
        }
        //分润消息
        $interestModel = M('Interest');
        $interest = $interestModel
                        ->field('a.money,
                  a.create_time,
                  a.gain_type,
                  b.username')
                        ->alias('a')
                        ->join('LEFT JOIN __USER__ as b ON a.child_id=b.id')
                        ->where('a.type=1 and a.username=' . $userInfo['username'])
                        ->order('a.id desc')->find();
        if ($interest) {
            $interest['create_time'] = date('Y-m-d', $interest['create_time']);
            if ($interest['gain_type'] == 1) {
                $interest['gain_type'] = '还款分润';
            } else if ($interest['gain_type'] == 2) {
                $interest['gain_type'] = '收款分润';
            }
        }

        //推广消息
        $spreadModel = M('Spread');
        $spread = $spreadModel
                        ->field('a.money,
                  a.create_time,
                  b.username')
                        ->alias('a')
                        ->where('a.username=' . $userInfo['username'])
                        ->join('LEFT JOIN __USER__ as b ON a.child_id=b.id')
                        ->order('a.id desc')->find();
        if ($spread) {
            $spread['create_time'] = date('Y-m-d', $spread['create_time']);
        }
        $data['sys'] = $sysnews;
        $data['fenrun'] = $interest;
        $data['tuiguang'] = $spread;
        echo $this->returnSuccessInfo(array("customMessage" => "", 'data' => $data));
        exit;
    }

    //系统消息
    public function sysnews() {
        $newsModel = M('News');
        $data = $newsModel->field('id,titles,contents,create_time')->where('is_delete=0')->order('id desc')->select();
        foreach ($data as $k => $v) {
            $data[$k]['create_time'] = date('Y-m-d', $v['create_time']);
        }
        echo $this->returnSuccessInfo(array("customMessage" => "", 'data' => array('data' => array())));
        exit;
    }

    //分润消息
    public function frnews() {
        $userInfo = $this->userInfo;
        $offset = (I('offset') == null) ? 1 : intval(I('offset'));
        $limit = (I('limit') == null) ? 10 : intval(I('limit'));
        $offset = $offset * $limit - $limit;
        $time = (I('time') == null) ? $where = "" : $where = ' and a.create_time>' . strtotime(I('time'));
        $interestModel = M('Interest');
        $interest = $interestModel
                ->field('a.money,
                  a.create_time,
                  a.gain_type,
                  b.username')
                ->alias('a')
                ->join('LEFT JOIN __USER__ as b ON a.child_id=b.id')
                ->where('a.type=1 and a.username=' . $userInfo['username'] . $where)
                ->limit($limit, $offset)
                ->order('a.id desc')
                ->select();
        $num = $interestModel
                ->field('a.money,
                  a.create_time,
                  a.gain_type,
                  b.username')
                ->alias('a')
                ->join('LEFT JOIN __USER__ as b ON a.child_id=b.id')
                ->where('a.type=1 and a.username=' . $userInfo['username'] . $where)
                ->order('a.id desc')
                ->count();
        foreach ($interest as $k => $v) {
            $interest[$k]['create_time'] = date('Y-m-d', $v['create_time']);
            if ($v['gain_type'] == 1) {
                $interest[$k]['gain_type'] = '还款分润';
            } else if ($v['gain_type'] == 2) {
                $interest[$k]['gain_type'] = '收款分润';
            }
        }
        $res['page'] = ceil($num / $limit);
        $res['data'] = $interest;

        echo $this->returnSuccessInfo(array("customMessage" => "", 'data' => $res));
        exit;
    }

    //推广消息
    public function tgnews() {
        $userInfo = $this->userInfo;
        $offset = (I('offset') == null) ? 1 : intval(I('offset'));
        $limit = (I('limit') == null) ? 10 : intval(I('limit'));
        $offset = $offset * $limit - $limit;
        $time = (I('time') == null) ? $where = "" : $where = ' and a.create_time>' . strtotime(I('time'));
        $spreadModel = M('Spread');
        $spread = $spreadModel
                ->field('a.money,
                  a.create_time,

                  b.username')
                ->alias('a')
                ->join('LEFT JOIN __USER__ as b ON a.child_id=b.id')
                ->where('a.username=' . $userInfo['username'] . $where)
                ->limit($limit, $offset)
                ->order('a.id desc')
                ->select();
        $num = $spreadModel
                ->field('a.money,
                  a.create_time,
                  b.username')
                ->alias('a')
                ->join('LEFT JOIN __USER__ as b ON a.child_id=b.id')
                ->where('a.username=' . $userInfo['username'] . $where)
                ->order('a.id desc')
                ->count();
        foreach ($spread as $k => $v) {
            $spread[$k]['create_time'] = date('Y-m-d', $v['create_time']);
        }
        $res['page'] = ceil($num / $limit);
        $res['data'] = $spread;

        echo $this->returnSuccessInfo(array("customMessage" => "", 'data' => $res));
        exit;
    }

    /*     * *******结算费率***** */

    public function accrate() {
        $userInfo = $this->userInfo;
        $userModel = M('User');
        //查询等级费率
        $class = $userModel->field('grade')->where(array('id' => $userInfo['uid']))->find();
        $gradeModel = M('Grade');
        $grade = $gradeModel->where(array('grade' => $class['grade']))->find();
        $data['huai'] = $grade['repay_rate'] . "%+1";
        $data['shou'] = $grade['collection_rate'] . "%+2";

        echo $this->returnSuccessInfo(array("customMessage" => "", 'data' => $data));
        exit;
    }

    /*     * *******我的等级***** */

    public function mygrade() {
        $userInfo = $this->userInfo;
        $userModel = M('User');
        //查询等级费率
        $class = $userModel->field('grade')->where(array('id' => $userInfo['uid']))->find();
        $gradeModel = M('Grade');
        $myGrade = $gradeModel->where(array('grade' => $class['grade']))->find();
        $upClass = $gradeModel->field('grade,grade_name,up_money,repay_rate,collection_rate,info')->where('grade >' . $class['grade'])->select();
        $data['myGrade'] = $myGrade['grade_name'];
        $data['upClass'] = $upClass;

//        $array=array(
//            array('msg'=>'1.享受直推的用户代还1万元可得15元返佣;享受直推的用户收款1万元可得5元返佣'),
//            array('msg'=>'2.直推用户付费升级可得升级费用50%返佣;间接推荐10%返佣,再间接推荐10%返佣;用户升级为VIP会员,可得34元/人;升级为高级VIP,可得94元/人;升级为市级代理,可得490元/人;升级为省级代理,可得1490元/人;升级为合伙人代理,可得3440元/人;升级为运营中心代理,可得4900元/人.'
//    ));
//         echo json_en($array,true);die;
        foreach ($data['upClass'] as $k => $v) {
            $data['upClass'][$k]['info'] = json_decode($v['info']);
        }

        echo $this->returnSuccessInfo(array("customMessage" => "", 'data' => $data));
        ;
        die;
    }

    //立刻升级
    public function upclass() {
        $gradeId = intval(I('post.grade'));
        $gradeModel = M('Grade');
        $grade = $gradeModel->where(array('grade' => $gradeId))->find();
        $data['huai'] = $grade['repay_rate'] . "%+1";
        $data['shou'] = $grade['collection_rate'] . "%+2";
        $data['upMoney'] = $grade['up_money'];
        $data['grade'] = $grade['grade'];
        echo $this->returnSuccessInfo(array("customMessage" => "", 'data' => $data));
        exit;
    }

    //立即升级短信
    public function upgradesent() {
        $userInfo = $this->userInfo;
        $I['grade'] = intval(I('post.grade'));
        $I['id'] = intval(I('post.id'));
        $I['type'] = intval(I('post.type'));
        if (empty($I['id'])) {
            echo $this->returnErrorInfo(array("customMessage" => "请选择支付信用卡"));
            exit;
        }
        $userModel = M('User');
        $checkUser = $userModel->where('id=' . $userInfo['uid'])->find();
        if ($checkUser['grade'] >= $I['grade']) {//检测等级
            echo $this->returnErrorInfo(array("customMessage" => "只能选择更高级别的会员"));
            exit;
        }
        //个人信息
        $ubankModel = M('UserBank');
        $ubank = $ubankModel->where('uid=' . $userInfo['uid'])->find();
        $rcModel = M('Defrayrc');
        $rc = $rcModel->where('id=' . $I['id'])->find();
        $gradeModel = M('grade');
        $grade = $gradeModel->where('grade=' . $I['grade'])->find();

        $par = array();
        $par['ic'] = $ubank['ic']; //身份证
        $par['realname'] = $ubank['realname']; //姓名
        $par['bank_name'] = $rc['bank_name']; //银行名
        $par['nub'] = $rc['nub']; //卡号
        $par['phone'] = $rc['phone']; //手机
        $par['bankcode'] = $this->bankcode($rc['bank_name']); //银行代码
        $par['uid'] = $userInfo['uid'];
        $par['money'] = $grade['up_money'] * 100;

        $pay = new \Common\Pay\OnlinePay();
        $result = $pay->pay($par);
        if ($result['code'] == 1) {
            //写入user_recharge表
            $rechargeModel = M('user_recharge');
            $recharge['uid'] = $userInfo['uid'];
            $recharge['username'] = $userInfo['username'];
            $recharge['rc_id'] = $rc['id'];
            $recharge['pay_order'] = $result['data']['order'];
            $recharge['amount'] = $grade['up_money'];
            $recharge['state'] = 1;
            $recharge['type'] = $I['grade'];
            $recharge['recharge_type'] = $I['type'];
            $recharge['create_time'] = time();
            $recharge['interface_no'] = $result['data']['pay_order'];
            $add = $rechargeModel->add($recharge);
            echo $this->returnSuccessInfo(array("customMessage" => "发送成功", 'data' => array('data' => $result['data'])));
            exit;
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "发送失败", 'data' => array('data' => $result['data'])));
            exit;
        }
    }

    //升级VIP
    public function upgrade() {
        $userInfo = $this->userInfo;
        $I['pay_order'] = I('post.pay_order');
        $I['code'] = I('post.code');
        $pay_order = I('post.order');
        $gra = intval(I('post.grade'));
        if (!is_numeric($I['code'])) {
            echo $this->returnErrorInfo(array("customMessage" => "验证号码只能为数字"));
            exit;
        }if (empty($I['pay_order']) || empty($pay_order)) {
            echo $this->returnErrorInfo(array("customMessage" => "三方平台号或平台订单号不能为空"));
            exit;
        }
        $rechargeModel = M('UserRecharge');
        $check = $rechargeModel->where('state=1 and uid=' . $userInfo['uid'] . ' and pay_order=' . '"' . $pay_order . '"')->find();
        if (!$check) {
            echo $this->returnErrorInfo(array("customMessage" => "订单不存在或已完成!"));
            exit;
        }
        $pay = new \Common\Pay\OnlinePay();
        $result = $pay->cheakPay($I);
//        $result['code']=1;
        if ($result['code'] == 1) {
            try {
                $gradeModel = M('grade');
                $userModel = M('User');
                $grade = $gradeModel->where('grade=' . $check['type'])->find(); //查询升级
                //修改user_recharge充值状态
                $rechargeModel->startTrans(); //开启
                $result1 = $rechargeModel->where('uid=' . $userInfo['uid'] . ' and pay_order=' . '"' . $pay_order . '"')->save(array('state' => 2, "recharge_time" => time()));
                //修改user会员状态
                $result2 = $userModel->where('id=' . $userInfo['uid'])->save(array('grade' => $check['type']));
                //上级分润逻辑
                $spreadModel = M('Spread');
                $user = $userModel->field('parent_id')->where('id=' . $userInfo['uid'])->find();
                if ($user['parent_id'] != 0) {
                    $one = $userModel->where('username=' . '"' . $user['parent_id'] . '"')->find();

                    if ($one) {//一级
                        $add1 = $spreadModel->add(array('uid' => $one['id'],
                            'username' => $one['username'],
                            'child_id' => $userInfo['uid'],
                            'money' => $grade['up_money'] * 0.5,
                            'create_time' => time()));
                        $two = $userModel->where('username=' . '"' . $one['parent_id'] . '"')->find();
                    }
                    if ($two) {//二级
                        $add2 = $spreadModel->add(array('uid' => $two['id'],
                            'username' => $two['username'],
                            'child_id' => $userInfo['uid'],
                            'money' => $grade['up_money'] * 0.1,
                            'create_time' => time()));
                        $three = $userModel->where('username=' . '"' . $two['parent_id'] . '"')->find();
                    }
                    if ($three) {
                        $add3 = $spreadModel->add(array('uid' => $three['id'],
                            'username' => $three['username'],
                            'child_id' => $userInfo['uid'],
                            'money' => $grade['up_money'] * 0.1,
                            'create_time' => time()));
                    }
                }
                if ($result1) {
                    $rechargeModel->commit();
                } else {
                    $rechargeModel->rollback();
                }
                if ($result1) {
                    echo $this->returnSuccessInfo(array("customMessage" => "升级成功！", 'data' => array('grade' => $grade['grade_name'])));
                    exit;
                } else {
                    echo $this->returnErrorInfo(array("customMessage" => "升级失败！"));
                    exit;
                }
            } catch (Exception $e) {
                echo $e->getMessage();
            }
        } else {
            echo $this->returnErrorInfo(array("customMessage" => $result['data']));
            exit;
        }
    }

    /*     * ********银行卡管理******** */

    public function mybank() {
        //储蓄卡
        $userInfo = $this->userInfo;
        $userBankModel = M('UserBank');
        $userBank = $userBankModel->field('bank_name,account')->where(array('type' => 1, 'uid' => $userInfo['uid']))->find();
        $length = strlen($userBank['account']);
        $userBank['account'] = "************" . substr($userBank['account'], ($length - 4), $length);
        //信用卡
        $defrayModel = M('Defrayrc');
        $defray = $defrayModel->field('id as ids,bank_name,nub')->where(array('is_bind' => 0, 'username' => $userInfo['username']))->select();
        foreach ($defray as $k => $v) {
            $length = strlen($v['nub']);
            $defray[$k]['nub'] = "************" . substr($v['nub'], ($length - 4), $length);
        }
        $data['chuxu'] = $userBank;
        $data['rc'] = $defray;

        if (empty($userBank)) {
            echo $this->returnErrorInfo(array("customMessage" => "你当前尚未绑定银行卡"));
            exit;
        } else {
            echo $this->returnSuccessInfo(array("customMessage" => "", 'data' => $data));
            exit;
        }
    }

    //解除信用卡
    public function deleterc() {
        $userInfo = $this->userInfo;
        $id = I('post.id');
        $defrayModel = M('Defrayrc');
        $result = $defrayModel->where(array('id' => $id, "username" => $userInfo['username']))->save(array("is_bind" => 1));
        if ($result) {
            echo $this->returnSuccessInfo(array("customMessage" => "解绑成功"));
            exit;
        } else {
            echo $this->returnErrorInfo(array("customMessage" => "解绑失败"));
            exit;
        }
    }

    /*     * *************手续费比例**************** */

    public function fee() {
        $userInfo = $this->userInfo;
        $userModel = M('User');
        $user = $userModel->field('grade')->where('id=' . $userInfo['uid'])->find();
        $gradeModel = M('Grade');
        $grade = $gradeModel->where('grade=' . $user['grade'])->find();
        $grades['up_money'] = $grade['up_money'];
        $grades['repay_rate'] = $grade['repay_rate'];
        $grades['collection_rate'] = $grade['collection_rate'];
        echo $this->returnSuccessInfo(array('data' => $grades));
        exit;
    }

    //我的保险
    public function myinsurance() {
        $userInfo = $this->userInfo;
        $ubankModel = M('UserBank');
        $check = $ubankModel->where('type=1 and uid=' . $userInfo['uid'])->find();
        if (!$check) {
            echo $this->returnErrorInfo(array('customMessage' => '您先实名制绑定银行卡!'));
            exit;
        }
        $data['in_ob'] = "被保人名下所有银行卡";
        $data['in_order'] = "4657663530093" . $userInfo['uid'] . substr($check['ic'], 0, 6);
        $data['in_orders'] = "4657663530093" . $userInfo['uid'] . substr($check['ic'], 0, 6);
        $data['in_er'] = $check['realname'];
        $data['in_stime'] = date('Y-m-d', $check['create_time']);

        $data['in_etime'] = date('Y-m-d', ($check['create_time'] + 31536000));
        $data['in_money'] = "10000.00";
        $data['in_moneys'] = "10.00";
        $data['in_phone'] = "95511";

        echo $this->returnSuccessInfo(array('data' => $data));
        exit;
    }

}
