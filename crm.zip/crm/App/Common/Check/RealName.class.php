<?php

namespace Common\Check;

//认证接口
/*
 * 该接口尚需进行调整，有待商量
 */
class RealName {

    private $code = "b06bb3b53ee347f8991a7ad328a1cda0";
    private $url = "http://v.juhe.cn/verifybankcard4/query";

    /*     * *************实名认证******************* */

    /**
     * 银行卡四要素验证
     * @param $realname
     * @param $idcard
     * @param $bankcard
     * @param $mobile
     */
    public function checkId($realname, $idcard, $bankcard, $mobile) {

        $host = "http://verifybankcard4-ali.juheapi.com";
        $path = "/verifybankcard4/query";
        $method = "GET";
        $appcode = $this->code;
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $appcode);
        $querys = "bankcard=" . $bankcard . "&idcard=" . $idcard . "&mobile=" . $mobile . "&realname=" . $realname;
        $bodys = "";
        $url = $host . $path . "?" . $querys;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, false);
        if (1 == strpos("$" . $host, "https://")) {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }
        $result = json_decode(curl_exec($curl), true);

        if ($result['result']['res'] == 1 && $result['reason'] == "成功 ") {
            //匹配成功
            return false;
        } elseif ($result['result']['res'] != 1 && $result['reason'] == "成功 ") {
            //匹配不成功
            return array("customMessage" => $result['result']);
        } else {
            //其他情况
            return array("reason" => $result['reason']);
        }
    }

    /*
     * 人脸比对初始化
     * 刷脸验证用户是否为本人和真人
     */

    public function faceVerifyInit($bizId, $username, $idcard, $metainfo) {
        //应第三方要求， 换成这个测试一下
        $host = "https://faceverify.market.alicloudapi.com";
        $path = "/faceVerifyInitSimply";
        $method = "GET";
//        $appcode = $this->code;
        $appcode = 'a2c8e32007f84acfb32342b4e932285b';
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $appcode);
        //实践证明，下面的meta info写死是有用的
//        $metainfo='{"zimVer":"3.0.0","appVersion":"1","bioMetaInfo":"3.3.0:98304,4","appName":"com.moresc.phone","deviceType":"ios","osVersion":"iOS11.3.1","apdidToken":"\/37uEFYwmNJG47nmbbwgDym2rPu8kGBQQ1cNP9xVi8AR8TTdYwEAAA==","deviceModel":"iPhone9,2"}';

        $querys = "bizId=" . urlencode($bizId) . "&certName=" . urlencode($username) . "&certNo=" . urlencode($idcard) . "&certType=" . urlencode("IDCARD") . "&metainfo='" . urlencode($metainfo) . "'";

        $url = $host . $path . "?" . $querys;
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, true);
        if (1 == strpos("$" . $host, "https://")) {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }
        $result = curl_exec($curl);

        //zimId字符串第一次出现的位置
        $zimId_first = stripos($result, 'zimId');

        //resultCodeSub第一次出现的位置
        $resultCodeSub_first = stripos($result, 'resultCodeSub');
        $sub_len = $resultCodeSub_first - $zimId_first;

        $zimId = substr($result, $zimId_first + 8, $sub_len - 11);


        return array("customMessage" => $zimId);

//        return array("customMessage" => $result);
//       ?token=9233270f7f6c17bccdd32e1ae57a15c5&bizId=wy_147258369&certName=林志锋&certNo=441481199304033631&certType=IDCARD&metainfo=123456789
//        $host = "https://faceverify.market.alicloudapi.com";
//        $path = "/faceVerifyInit";
//        $method = "POST";
//        $appcode = $this->code;
//        $headers = array();
//        array_push($headers, "Authorization:APPCODE " . $appcode);
//        //根据API的要求，定义相对应的Content-Type
//        array_push($headers, "Content-Type" . ":" . "application/json; charset=UTF-8");
//
////        $bodys = "{\"bizId\":\"ZSTP2018013076546767654695203625\",//接入方请求的唯一标识，由字母、数字、下划线组成，须确保其唯一性。\"certName\":\"张三\",//认证者姓名\"certNo\":\"210111197911052510\",//认证者证件号码\"certType\":\"IDCARD\",//证件类型，请填写IDCARD\"metainfo\":\"{...}\"//环境参数，需要通过客户端SDK获取（详见刷脸认证iOS和Android客户端接入指南）}";
////        $bodys = "{\"bizId\":\"{$bizId}\",//接入方请求的唯一标识，由字母、数字、下划线组成，须确保其唯一性。\"certName\":\"{$username}\",//认证者姓名\"certNo\":\"{$idcard}\",//认证者证件号码\"certType\":\"IDCARD\",//证件类型，请填写IDCARD\"metainfo\":\"{$metainfo}\"//环境参数，需要通过客户端SDK获取（详见刷脸认证iOS和Android客户端接入指南）}";
//
////        $bodys = "{\"bizId\":\"{$bizId}\",\"certName\":\"{$username}\",\"certNo\":\"{$idcard}\",\"certType\":\"IDCARD\",\"metainfo\":\"{$metainfo}\"}";
//        $bodys = '{"bizId":'.$bizId.",certName:".$username.",certNo:".$idcard.",certType:IDCARD".",metainfo:".$metainfo.'}';
////return $bodys;exit;
//        $url = $host . $path;
//
//
//        $curl = curl_init();
//        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
//        curl_setopt($curl, CURLOPT_URL, $url);
//        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
//        curl_setopt($curl, CURLOPT_FAILONERROR, false);
//        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
//        curl_setopt($curl, CURLOPT_HEADER, true);
//        if (1 == strpos("$" . $host, "https://")) {
//            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
//            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
//        }
//        curl_setopt($curl, CURLOPT_POSTFIELDS, $bodys);
////        $result = json_decode(curl_exec($curl), true);
//      
//        $result = curl_exec($curl);
//        
////        if ($result['zimId']) {
////            $result['bizId'] = $bizId;
////        }
//      
//        return array("customMessage" => $result);
    }

    /*
     * 比对完成获取认证结果
     * 返回认证结果给客户端，告知用户认证成功与否
     */

    public function faceVerifyFetch($bizId, $zimId) {
        $host = "https://faceverify.market.alicloudapi.com";
        $path = "/faceVerifyFetch";
        $method = "GET";
//        $appcode = $this->code;
        $appcode = 'a2c8e32007f84acfb32342b4e932285b';
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $appcode);


//        $querys = "bizId={$bizId}&zimId={$zimId}";

        $querys = "bizId=" . urlencode($bizId) . "&zimId=" . urlencode($zimId);
        $url = $host . $path . "?" . $querys;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, true);
        if (1 == strpos("$" . $host, "https://")) {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }
        $result = curl_exec($curl);

        //resultCode字符串第一次出现的位置
//        $resultCode_first = stripos($result, 'resultCode');
        //resultMsg第一次出现的位置
//        $resultMsg_first = stripos($result, 'resultMsg');
//        $sub_len = $resultMsg_first - $resultCode_first;

        $resultCodeSub_first = stripos($result, 'resultCodeSub');
        $resultCodeSub_len = strlen('resultCodeSub');

//         $resultCode = substr($result, $resultCode_first + 13, $sub_len-10);
        $resultCode = substr($result, $resultCodeSub_first + $resultCodeSub_len + 3, 5);

        //下面的操作不是写在这里就是在接口处
//        $bb = str_replace('{', '', $result);
//        $bb = str_replace('}', '', $bb);
//        $bb = explode(',', $bb);
//        foreach ($bb as $k => $v) {
//            $info = explode(':', $v);
//            $key = str_replace('"', '', $info[0]);
//            $value = str_replace('"', '', $info[1]);
//            $metainfo[$key] = $value;
//        }
//         return array($metainfo);

        return array('resultCode' => $resultCode);
    }

    /*
     * 实名验证，通过将用户输入的姓名、身份证号，拍摄的人脸照片发送到对应接口，比对是否属于同一个人
     * realname:姓名
     * idcard：身份证号
     * image：人脸照片
     */

    public function checkMan($realname, $idcard, $image) {
        $host = "https://facecheck.market.alicloudapi.com";
        $path = "/facecheck";
        $method = "POST";
        $appcode = $this->code;
        $headers = array();
        array_push($headers, "Authorization:APPCODE " . $appcode);
        //根据API的要求，定义相对应的Content-Type
        array_push($headers, "Content-Type" . ":" . "application/x-www-form-urlencoded; charset=UTF-8");
//        $bodys = "idCardNum=411329199002060056&image=5rWL6K%2BV5Zu%2B54mH5YaF5a65%3D&realName=%E5%BC%A0%E4%B8%89";
//        $bodys = "idCardNum={$idcard}&image={$image}&realName={$realname}";

        $bodys = "idCardNum=" . $idcard . "&image=" . $image . "&realName=" . $realname;

        $url = $host . $path;

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($curl, CURLOPT_FAILONERROR, false);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_HEADER, true);
        if (1 == strpos("$" . $host, "https://")) {
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        }
        curl_setopt($curl, CURLOPT_POSTFIELDS, $bodys);
        $result = json_decode(curl_exec($curl), true);


//        return array("customMessage" => array('xiaoxiao','xiaoming','xiaodong'));//正常返回array
        return array('customMessage' => $result);


//       if ($result['Code'] == 0) {
//            return array("customMessage" => $result);
//        } elseif ($result['Code'] == 3 ) {
//            return '认证失败';
//        } else {
//            return '输入的信息有误';
//        }
    }

    //curl请求（post)
    public function httpClient($data, $url) {
        $postdata = http_build_query($data);
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
            $res = curl_exec($ch);
            curl_close($ch);
            return $res;
        } catch (Exception $e) {
            $errorMsg = $e->getMessage();
            return false;
        }
    }

}
