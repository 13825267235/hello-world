<?php
return array(
    /*************************项目配置**********************************/
    'MODEL_NAME'                =>'Home',//模块名称
//    'MULTI_MODULE'              =>false, //隐藏模块名
//    'DEFAULT_MODULE'            =>'Home', //隐藏模块名
    'APP'                        => '/App/',//模块路径
    'URL_MODEL'                 =>  2 ,       // URL访问模式,可选参数0、1、2、3,代表以下四种模式： 0 (普通模式); 1 (PATHINFO 模式); 2 (REWRITE  模式); 3 (兼容模式)  默认为PATHINFO 模式
    'DEFAULT_FILTER'           => 'htmlspecialchars,stripslashes,trim',// 定义 I 函数过滤方法
    /*************************资源目录配置**********************************/
     'PUBLIC_PLUGIN'            =>'/Public/Plugin/',  //插件目录
     'PUBLIC_IMG'                =>'/Public/img/',  //图片目录
     'PUBLIC_JS'                 =>'/Public/js/',   //JS目录
     'PUBLIC_CSS'                =>'/Public/css/',   //CS目录
     'API_IMG'                    =>'/upload/Api/img/',//Api图片
    /*************************session设置**********************************/
    'ADMIN_SESSION'               =>'admin_session', //后台用户登录 session
    'APP_SESSION'               =>'app_session', //app用户登录 session
//    'SESSION_OPTIONS'           =>array('name'=>'APP_SESSION','expire'=>10),//session过期时间
    /*************************分页默认配置**********************************/
    'PAGE_ING' => 10,
    /*************************Msql链接方式**********************************/
    'DB_TYPE'   => 'mysql', // 数据库类型
    'DB_HOST'   => 'localhost', // 服务器地址
    'DB_NAME'   => 'wy', // 数据库名
    //'DB_USER'   => 'jixian_mysql', // 用户名
    //'DB_PWD'    => 'zkyZKY138', // 密码

   'DB_USER'   =>'root',
//   'DB_PWD'    =>'zhongkeyun138',
       'DB_PWD'    =>'',


    'DB_PORT'   => 3306, // 端口
    'DB_PREFIX' => 'wy_', // 数据库表前缀
    'DB_CHARSET'=> 'utf8mb4', // 字符集
    'DB_DEBUG'  =>  true, // 数据库调试模式 开启后可以记录SQL日志 3.2.3新增

);
