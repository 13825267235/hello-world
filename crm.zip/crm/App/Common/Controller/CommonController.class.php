<?php
namespace Common\Controller;

use Think\Controller;

class CommonController extends Controller{

    public function _initialize(){

        $module = strtolower(MODULE_NAME);//访问的模块

        $controller = strtolower(CONTROLLER_NAME);//访问的控制器

        $action = strtolower(ACTION_NAME);//访问的方法

        //过滤不需要登录的操作
        $NOUser = array('login', 'logout','getverify');
        //检测是否登录
        if (!in_array($action, $NOUser)) {
            $this->CheckUser(false);
        }
        //导航栏渲染
        $res=$this->nav();
        //权限
        $userInfo=$this->checkJurisdiction();
        $userInfos=session(C('ADMIN_SESSION'));

        $identificationJson = json_encode($userInfos['res']);
        $userRes['identificationJson'] = $identificationJson;
//dump($userInfos);die

        $this->assign('userInfos',$userInfos);
        $this->assign("userRes",$userRes);
        $this->assign("nav",$res);
        $this->assign("userInfo",$userInfo);
    }
    //权限
    public function checkJurisdiction(){

        $userInfo = session(C('ADMIN_SESSION')); //用户信息
//        dump($userInfo);
        if($userInfo){
            $returnArr=$userInfo['res'];
            return $returnArr;
        }
    }
    //导航栏
    public function nav(){
        $resModel=M('Res');
        $res=$resModel->where('is_delete=0 and parentid=0')->order('sort ASC')->select();
        foreach($res as $k=>$v){
            $res[$k]['children']=$resModel->where('is_delete=0 and is_hide=0 and parentid='.$v['id'])->order('sort ASC')->select();
            foreach($res[$k]['children'] as $i=>$j){
                $res[$k]['children'][$i]['data']=$resModel->where('is_delete=0 and parentid='.$j['id'])->order('sort ASC')->select();
            }
        }
        return $res;
    }


    /**
     * @describe 绝对跳转登录
     * @author eleven
     * @param string $mode
     */
    public function thoroughRedirect(){
        session(C('ADMIN_SESSION'),NULL);
        $this->redirect(''.C('MODEL_NAME').'/Login/login');
    }
    /**
     * 登录检测*/
    public function CheckUser($isrebiret=true)
    {
        $userInfo = session(C('ADMIN_SESSION')); //用户信息
        //检查是否登录
        if (isset($userInfo)) {
            $this->userInfo = $userInfo; //信息
//            $this->updateSessionTime($userInfo['onLineid']);
            return true;
        } else {
            session('link', MODULE_NAME . '/' . CONTROLLER_NAME . '/' . ACTION_NAME);
            if($isrebiret){
                return false;
            }else{
                $this->thoroughRedirect();
            }
        }
    }

    /**
     * 提示
     **/
    public function jumpInfo($arr = array())
    {
        $arr['status'] = isset($arr['status']) ? 'n' : 'y'; //状态
        $arr['isClose'] = isset($arr['isClose']) ? 0 : 1; //是否关闭弹窗 0=关闭，1=不关闭
        $arr['info'] = isset($arr['info']) ? $arr['info'] : ''; //提示信息
        $arr['msg'] = isset($arr['msg']) ? $arr['msg'] : '3秒钟后自动跳转，如果不想等待，直接点击确定跳转'; //附属信息
        $arr['type'] = isset($arr['type']) ? 'error' : 'success'; //返回类型
        $arr['url'] = isset($arr['url']) ? $arr['url'] : '';//跳转地址
        $arr['timer'] = isset($arr['timer']) ? $arr['timer'] : 3000; // 多少秒以后关闭窗口(默认3秒)
        $arr['data'] = isset($arr['data']) ? $arr['data'] : ''; // 返回的参数
        $myjson = json_encode($arr);
        echo $myjson;
        exit;
    }

    //登陆日志
    public function addLog( $doing,$action,$status=1) {

        $userInfo = session(C('ADMIN_SESSION')); //用户信息

        $logData = M('ActionLog');

        $data = array();

        if (isset($userInfo)) {
            $data['user_name'] = $userInfo['username'];
            $data['user_id'] = $userInfo['id'];
        }

        $data['ip']    = get_client_ip();
        $data['time']  = time();
        $data['module'] = MODULE_NAME;
        $data['type'] = 2;
        $data['create_time']=$data['time'];
        $data['action_info'] = $doing;
        $data['action'] = $action;
        $data['status'] = $status;
        $logData->add($data);
    }

    //三维数组降二维
    public function changedimension($array){
        //循环遍历三维数组$arr3
        foreach($array as $value){
            foreach($value as $v){
                $arr2[]=$v;
            }
        }
        unset($result,$value,$v);
        return $arr2;
    }
}