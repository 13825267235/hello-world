<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * 提现
 * 掌灵科技家通道
 */

namespace Common\Pay;

class CashPay {

    //请求
    public function cash($par) {
        $data = array();
        $gymchtKey = 'b27976286445992a26614e84143e277f'; //掌灵给商户应用分配的MD5key（可以去商户后台自取）
        $data['service'] = 'service.api.cash.apply'; //接口类型
        $data['appid'] = '0000002535'; //应用编号，商户后台可自取
        $data['mchntOrderNo'] = 'JX' . date('YmdHis') . rand(1000, 9999); //商户订单号       
        $data['powerId'] = '9000000001'; //支付功能编号
        $data['subject'] = urlencode('虚拟卡'); //订单标题、商品标题

        $pay_order = $par['pay_order'] . "00"; //单位为分
        $data['amount'] = $pay_order; //交易金额                                       $par['pay_order']
        $data['cardId'] = $par['cardId']; //支付卡卡号 ，信用卡               $par['cardId']
        $data['mobileNo'] = $par['phone'];                             //          $par['phone']，数据库
        $data['acctName'] = urlencode($par['realname']); //持卡人姓名                               $par['realname']，数据库
        $data['acctIdcard'] = $par['ic']; //证件号码                           $par['ic']，数据库

        $data['bankNum'] = '01050000'; //联行号，貌似传固定的参数也是没啥问题的，有待检验
        
        
        $data['acctCardno'] = $par['acctCardno']; //银行卡号，结算              $par['acctCardno']
        $data['cvn2'] = $par['cvn2']; //安全码                                           $par['cvn2']，数据库
        $data['expDt'] = $par['expDt']; //信用卡有效期                                    $par['expDt']，数据库
        
        $data['busType'] = 'WKPAY'; //交易类型
        $data['tradeRate'] = '0.40'; //交易手续费费率
        $data['drawFee'] = '0.01'; //单笔提现手续费
        $data['notifyUrl'] = urlencode("http://crm.szinternet.com/Api/Hwu/notifyUrl"); //异步通知地址
        $data['returnUrl'] = urlencode("http://crm.szinternet.com/Api/Index/returnUrl"); //同步跳转地址
        $data['version'] = '01';
        $sign = $this->createSign($data, $gymchtKey); //数字签名
        $data['signature'] = $sign;
//        $data['bankName'] = urlencode("招商银行"); //结算卡银行名称,可为空,此处这样子写的话长度可能超长了                                      $par['bank_name']


        $url = 'http://api.palmf.cn/api/cash/apply';
        $rs = $this->httpClient($data, $url);
        $rs = json_decode($rs, true);
        $array = array();

        return array('data' => $rs);
        exit;

        if ($rs['resultCode'] == '00000') {
            $sign = $rs['sign'];
            unset($rs['sign']);
            ksort($rs);
            if ($this->isGySign($rs, $gymchtKey, $sign)) {
                return array('code' => 1, 'data' => array("pay_order" => $rs['transaction_id'], "order" => $data['tradeSn']));
            } else {
                return array('code' => 0, 'data' => '签名错误');
            }
        } else {
            return array('code' => 0, 'data' => $rs['message']);
        }
    }

    /*
     * 交易查询接口
     */

    public function queryOrder($data) {
        $gymchtKey = 'b27976286445992a26614e84143e277f'; //掌灵给商户应用分配的MD5key（可以去商户后台自取）
        //待签名字符串签名
        $data['signature'] = $this->createSign($data, $gymchtKey);
        //查询
        $url = 'http://api.palmf.cn/api/cash/query ';
        $rs = $this->httpClient($data, $url);
        $rs = json_decode($rs, true);

        return array('data' => $rs);
    }

//    //验证码地址
//    public function cheakPay($I)
//    {
//
//        $data = array();
//
//        $params = $_POST;
//        $gymchtKey ="804920e93b9f4a3e84d0bbe6667cb004";//
//        $data['gymchtId'] = "gypay0180156";//商户号
//        $data['transaction_id'] = "Qk2018011800001150928709";//预交易订单号 $I['pay_order']
//        $data['yzm'] = "437598";//验证码                                        $I['code']
//        $data['nonce'] = md5(time().mt_rand(0,1000));//随机字符串
//        $sign = $this->createSign($data,$gymchtKey);//数字签名
//        $data['sign'] = $sign;
//
//        $url="http://113.106.95.37:7777/gyprovider/quickpay/checkPay.do";
//
//        $rs = $this->httpClient($data,$url);
//        $rs = json_decode($rs, true);
//
//        if($rs['resultCode'] == '00000')
//        {
//            $sign = $rs['sign'];
//            unset($rs['sign']);
//            ksort($rs);
//
//            if($this->isGySign($rs, $gymchtKey,$sign))
//            {
//                if($rs['tradeState'] == 'SUCCESS')
//                {
//                    //消费成功记账
//                    return array('code'=>1,'data'=>'消费成功');
//                }else{
//                    return false;
//                }
//            }else{
//                return array('code'=>0,'data'=>'签名错误');
//            }
//        }else{
//            return array('code'=>0,'data'=>$rs['message']);
//        }
//
//    }
    //回调地地址
//    public function  retPay(){
//
//    }
    //加工签名
    public function createSign($data, $gymchtKey) {
        $signPars = "";

        ksort($data);

        foreach ($data as $k => $v) {
            if ("" != $v && "signature" != $k) {
                $signPars .= $k . "=" . $v . "&";
            }
        }

        $signPars .= "key=" . $gymchtKey;

//        return $signPars;
//        exit;
        $sign = md5($signPars);

        return $sign;
    }

    //curl请求
    public function httpClient($data, $url) {
//        $postdata = http_build_query($data);
        $postdata = json_encode($data);
//        $postdata=$data;
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
            $res = curl_exec($ch);
            curl_close($ch);
            return $res;
        } catch (Exception $e) {
            $errorMsg = $e->getMessage();
            return $errorMsg;
        }
    }

}
