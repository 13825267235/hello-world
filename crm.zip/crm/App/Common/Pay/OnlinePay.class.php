<?php

namespace Common\Pay;

class OnlinePay {
    //请求地址
    public  function pay($par){

        /***********************帐号密码*******************************/
        $data=array();
        /***************非同名进出在线支付********************/
        $gymchtKey ="804920e93b9f4a3e84d0bbe6667cb004";//
        $data['gymchtId'] ="gypay0180156";//商户号gypay0180156
      
//        $data['gymchtId'] ="201408071000001539";//商户号gypay0180156
        
        //参数
        $data['tradeSn'] = 'JX'.date('YmdHis').rand(1000,9999);//商户订单号
        $data['orderAmount'] = 1;//订单金额                                       $par['money']
        $data['cardHolderName']= "林志锋";//持卡人姓名                               $par['realname']
        $data['cardNo']= "6225760032327087";//持卡人卡号                             $par['nub']
        $data['bankName']="招商银行";//银行名称                                      $par['bank_name']
        $data['cerType']="01";//证件类型，01-身份证,
        $data['cerNumber']="441481199304033631";//证件号码                           $par['ic']
        $data['mobileNum']="13825267235";//手机号                                    $par['phone']
        $data['bankSegment'] = "95555";//银行代号                                      $par['bankcode']
        $data['cardType'] = '01';//00-贷记 01-借记 02-准贷记

        $data['notifyUrl'] = "http://120.79.141.62/Api/Hwu/retPay";//回调通知地址
        $data['callbackUrl'] = "http://www.guoyinpay.com/";//回调跳转地址
        $data['goodsName'] = "guoyin";//商品名称
        $data['channelType'] = 1;//1-pc 2-手机
        $data['nonce'] = md5(time().mt_rand(0,1000));//随机字符串

        $sign = $this->createSign($data,$gymchtKey);//数字签名
        $data['sign'] = $sign;
        /*****线路******/
        $routeModel=M('Route');
        $route=$routeModel->where('type=1 and is_used=1 and is_delete=0')->find();
        /***********/
        $url=$route['url'];//"http://113.106.95.37:7777/gyprovider/quickpay/prePay.do";

        return $url;
        exit;
        
        $rs = $this->httpClient($data,$url);
        $rs = json_decode($rs, true);
        $array = array();

        if($rs['resultCode'] == '00000'){
            $sign = $rs['sign'];
            unset($rs['sign']);
            ksort($rs);
            if($this->isGySign($rs, $gymchtKey,$sign)){
                return array('code'=>1,'data'=>array("pay_order"=>$rs['transaction_id'],"order"=>$data['tradeSn']));
            }else{
                return array('code'=>0,'data'=>'签名错误');
            }
        }else{
            return array('code'=>0,'data'=>$rs['message']);
        }

    }
    //验证码地址
    public function cheakPay($I)
    {

        $data = array();

        $params = $_POST;
        $gymchtKey ="804920e93b9f4a3e84d0bbe6667cb004";//
        $data['gymchtId'] = "gypay0180156";//商户号
        $data['transaction_id'] = "Qk2018011800001150928709";//预交易订单号 $I['pay_order']
        $data['yzm'] = "437598";//验证码                                        $I['code']
        $data['nonce'] = md5(time().mt_rand(0,1000));//随机字符串
        $sign = $this->createSign($data,$gymchtKey);//数字签名
        $data['sign'] = $sign;

        $url="http://113.106.95.37:7777/gyprovider/quickpay/checkPay.do";

        $rs = $this->httpClient($data,$url);
        $rs = json_decode($rs, true);

        if($rs['resultCode'] == '00000')
        {
            $sign = $rs['sign'];
            unset($rs['sign']);
            ksort($rs);

            if($this->isGySign($rs, $gymchtKey,$sign))
            {
                if($rs['tradeState'] == 'SUCCESS')
                {
                    //消费成功记账
                    return array('code'=>1,'data'=>'消费成功');
                }else{
                    return false;
                }
            }else{
                return array('code'=>0,'data'=>'签名错误');
            }
        }else{
            return array('code'=>0,'data'=>$rs['message']);
        }

    }
    //回调地地址
    public function  retPay(){

    }

  //加工签名
    public function createSign($data,$gymchtKey)
    {
        $signPars = "";

        ksort($data);

        foreach($data as $k => $v) {
            if("" != $v && "sign" != $k) {
                $signPars .= $k . "=" . $v . "&";
            }
        }

        $signPars .= "key=" . $gymchtKey;

        $sign = strtoupper(md5($signPars));

        return $sign;
    }
    //curl请求
    public function httpClient($data, $url)
    {
        $postdata = http_build_query($data);

        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
            $res = curl_exec($ch);
            curl_close($ch);
            return $res;
        } catch (Exception $e) {
            $errorMsg = $e->getMessage();
            return $errorMsg;
        }
    }

    public function isGySign($data,$gymchtKey,$sign)
    {
        $gySign = $this->createSign($data,$gymchtKey);

        return $sign==$gySign;
    }
}