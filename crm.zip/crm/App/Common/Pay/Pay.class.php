<?php

namespace Common\Pay;

class Pay {
        /***************同名进出在线支付********************/
    public  function pay(){
        /***********************帐号密码*******************************/
        $data=array();
        $data['gymchtId'] ="gypay0180151";//商户号gypay0180151
        $gymchtKey ="c3dafc920055437fbd9b1c3a81bec5e7";//商户号c3dafc920055437fbd9b1c3a81bec5e7
        //参数
        $data['tradeSn'] = 'CS'.date('YmdHis').rand(1000,9999);//商户订单号
        $data['orderAmount'] = 1000;//订单金额
        $data['cardHolderName']= "覃小寅";//持卡人姓名
        $data['cardNo']= "6226590004642166";//持卡人卡号 6226590004642166
        $data['bankName']="光大银行";//银行名称
        $data['cerType']="01";//证件类型，01-身份证,
        $data['cerNumber']="420684198609024534";//证件号码420684198609024534
        $data['mobileNum']="13428919194";//手机号
        $data['bankSegment'] = "95595";//银行代号
        $data['cardType'] = '01';//00-贷记 01-借记 02-准贷记

        $data['notifyUrl'] = "http://www.qd.com";//回调通知地址
        $data['callbackUrl'] = "http://www.guoyinpay.com/";//回调跳转地址
        $data['goodsName'] = "guoyin";//商品名称
        $data['channelType'] = "";//1-pc 2-手机
        $data['nonce'] = md5(time().mt_rand(0,1000));//随机字符串

        //结算银行
        $data['receiptBankname']="6226590004642166";//结算银行名称
        $data['receiptCardNo']="覃小寅";//结算银行卡号
        $data['receiptSettleFee']=10.00;//清算金额 = 交易金额*(1-结算费率/100)-单笔额外费率
        $data['receiptSettleExtraFee']="";//单笔额外费率，非必传，不传则不收取

        $sign = $this->createSign($data,$gymchtKey);//数字签名
        $data['sign'] = $sign;

        $url="http://113.106.95.37:7777/gyprovider/netpay/applyQuickpay.do";
        $rs = $this->httpClient($data,$url);
        $rs = json_decode($rs, true);
        print_r($rs);die;
        $array = array();
        if($rs['resultCode'] == '00000'){
            $sign = $rs['sign'];
            unset($rs['sign']);
            ksort($rs);
            if($this->isGySign($rs, $gymchtKey,$sign)){
                echo "<script>window.location.href='".$rs['payUrl']."';</script>";
            }else{
                echo '返回签名错误';
            }
        }else{
            echo $rs['message'];
        }

    }

  //加工签名
    public function createSign($data,$gymchtKey)
    {
        $signPars = "";

        ksort($data);

        foreach($data as $k => $v) {
            if("" != $v && "sign" != $k) {
                $signPars .= $k . "=" . $v . "&";
            }
        }

        $signPars .= "key=" . $gymchtKey;

        $sign = strtoupper(md5($signPars));

        return $sign;
    }
    //curl请求
    public function httpClient($data, $url)
    {
        $postdata = http_build_query($data);

        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
            $res = curl_exec($ch);
            curl_close($ch);
            return $res;
        } catch (Exception $e) {
            $errorMsg = $e->getMessage();
            return false;
        }
    }

    public function isGySign($data,$gymchtKey,$sign)
    {
        $gySign = $this->createSign($data,$gymchtKey);

        return $sign==$gySign;
    }
}