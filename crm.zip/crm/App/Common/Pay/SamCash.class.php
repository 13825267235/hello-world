<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * 提现
 * 掌灵科技家通道
 */

namespace Common\Pay;

class SamCash {

    private $merNo;
    private $private_key;

    public function __construct() {
        $this->merNo = '8509611219302';
        $this->private_key = '-----BEGIN RSA PRIVATE KEY-----
MIICWwIBAAKBgQC1bivbJShiOr0ZoXX7ReOARJ23GJSrOsvY1RmnxL8s45EaVWzK
OAE6i4ypvMjdre5ZpTLmAVmlzzv0BDncXClrLBlFZV8wreIF94JEJqIlusEl+LhQ
2utvZpGckwi3+Sb8XXOL6ZQAw70Z51Obhi9CKyNbag0vqCnSBvX9S9BBbQIDAQAB
AoGAAKJK6vAdTQKRiJZk2CTtX5RdzLb8RgDll3NfLJPmaxy8dBAaWjaJ4o98RVeQ
iB3EeHG4VM9qZcbsmbSuExQLXP/9sXLjI+kvk10V+pLTxI/oUYXxvmAyM8kR6k0/
kfGF82C4jQOw+UGKMEY9IrCGgO59x7qhrtKYcATLhaLJ4i0CQQDvuRkxEadIdAzY
QoF3aC18y1TagPu6LojYLw4XA1b2CRnTVohiLoAp00OsRmvsZHP0z3lvUfEIsHlD
hntHjtl3AkEAwb/SH4WoVTwrzmCPek2oHayr7vdBEq1FRg5MWGQvuFXkBkfKPr7+
WbImPfJvs0m8VNVQMQxYBgfAd+53m7W1OwJAX6UWbAGDIOFMjqxaQ24JWBU4UcXM
qcgPSVHc6Umn1Jpk93E7ERFEiWuFQKMIRFT//tkYtlWXOcRPXaW2YiKYmQJAQ+Fh
y9t3E43GR0L7Yb0tZmAlyM5lxRZhy96cjudi9LFa93xVdlBSKrjIvzFeQzFVQ1+M
/fI2ML6shxhMXYh3GwJAEsQnaktTDtebi6TT0wA9kEeS+PC6wTLsHC93LjgqCHQc
bs/QwlbCE5Svg1bjvEhBLaY9EwsKq6S0YnfelSxYXg==
-----END RSA PRIVATE KEY-----
';
    }

    //提现
    public function cash($param) {
        //获取子商户号,每个用户只获取一次即可
        if($_SESSION['merCode_'.$param['uid']]){
            $merCode=$_SESSION['merCode_'.$param['uid']];
        }else{
            $merCode = $this->register($param);
        }
        $pay_order = $param['pay_order'].'00';
        $orderDate = time();

        $arr = array(
//            "requestNo" => 'wyh' . date('YmdHis') . rand(99, 999), //请求流水号
            "requestNo" => $param['requestNo'], //请求流水号
            "version" => "V1.0", //版本号
            "productId" => 1003, //产品类型
            "transId" => 22, //交易类型
            "merNo" => $this->merNo, //商户号
            "mchId" => $merCode, //进件商户号，由进件接口返回的子商户号，merCode
            "orderDate" => $orderDate, //订单支付日期
//            "orderNo" => "JX" . date("YmdHis") . rand(99, 999), //商户订单号
            "orderNo" => $param['orderNo'], //商户订单号
            "notifyUrl" => "http://crm.szinternet.com/Api/Pay/samNotifyUrl",
            "returnUrl" => "http://crm.szinternet.com/Api/Pay/samReturnUrl",
            "transAmt" => $pay_order, //订单金额
            "commodityName" => '虚拟卡', //商品名称
            "commodityDesc" => "充值虚拟卡", //商品描述
            "customerInfo" => $param['cardId'] . '|' . $param['realname'] . '|' . $param['ic'] . '|' . $param['phone'],
        );

        ksort($arr);
        $parameter = $this->spliceURL($arr); //获取url串
        $privateKey = openssl_pkey_get_private($this->private_key);

        $encrypted = "";
        openssl_sign($parameter, $encrypted, $privateKey);
        $signature = base64_encode($encrypted); //返回加密串
        $signature = str_replace("+", "%2B", $signature);
        $post = $parameter . "&signature=" . $signature;
        $rData = $this->sendUrl($post, $url = 'http://106.14.249.7/api/payment-gate-web/do');
        return array('data'=>$rData);
    }

    /*
     * 获取子商户号 
     */

    public function register($param) {
        $arr = array(
            "requestNo" => 'wyh' . date('YmdHis') . rand(99, 999), //请求流水号
            "version" => "V1.0", //版本号
            "merNo" => $this->merNo, //商户号
//            "customerInfo"=>'6226190680382664|罗雄兰|44142419861007224x|13902449153',//用户信息
//            "customerInfo" => '6226097804385699|吴远辉|441424197710102237|13502830942', //用户信息，此处卡号为结算卡号，卡号|姓名|身份证号|手机号
            "customerInfo" => $param['acctCardno'] . '|' . $param['realname'] . '|' . $param['ic'] . '|' . $param['phone'],
            "provinceCode" => '30333', //商户所在省编码
            "cityCode" => '344444', //市编码
            "address" => '深圳市龙华新区龙华街道清祥路清湖科技园B栋1043室', //详细地址
            "t1consRate" => 0.005, //税率
            "pointsType" => 0, //商户类型
        );

        ksort($arr);
        $parameter = $this->spliceURL($arr); //获取url串
        $privateKey = openssl_pkey_get_private($this->private_key);

        $encrypted = "";
        openssl_sign($parameter, $encrypted, $privateKey);
        $signature = base64_encode($encrypted); //返回加密串
        $signature = str_replace("+", "%2B", $signature);
        $post = $parameter . "&signature=" . $signature;
        $rData = $this->sendUrl($post, $url = 'http://106.14.249.7/api/payment/register');
        $first = stripos($rData, '=');
        $second = stripos($rData, '&');
        $merCode = substr($rData, $first + 1, $second - $first - 1);
        $_SESSION['merCode_'.$param['uid']]=$merCode;
        return $merCode;
    }

    /*
     * 拼接签名字符串
     */

    public function spliceURL($data = array()) {
        $o = "";
        foreach ($data as $k => $v) {
            $o .= "$k=" . $v . "&";
        }
        $str = substr($o, 0, -1);
        return $str;
    }

    /*
     * 发送请求
     */

    public function sendUrl($post = '', $url = "") {

        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_HEADER, 0);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $post);
        $data = curl_exec($curl);
        curl_close($curl);
        return $data;
    }

    public function verify($signStr, $key, $data) {
        $signature = str_replace("%2B", "+", $signStr);
        $resource = openssl_pkey_get_public($key);
        $result = openssl_verify($data, base64_decode($signStr), $resource);
        openssl_free_key($resource);
        return $result;
    }

}
