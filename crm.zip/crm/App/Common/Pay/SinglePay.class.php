<?php

namespace Common\Pay;


class SinglePay {
    private $pi_key = '-----BEGIN PRIVATE KEY-----
MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAL9PFU4jCaDw5iY+
JFkJc7HiUVenv1expXk/lF3yFm6Em76YTyquPYRXHJ3Etx2nvAy3ZzAKEaS0LYvw
6hkAzjjf/5f1vt6Y46Hr5CdBaxEJDEOBPKstmb3sNZWQkx0LUHReDU2nzqZVz7+6
rbxUUVhH84CZc0Vgs3ultBy4D3CHAgMBAAECgYBa8om6X8XQETYYsCoveeLaijEJ
buH0GqwD/EnYb6JiYAB6l4XrUHJGW/NqvX4gRwGLOhWALQk+N7n/cUSZJlzislDC
2zVuzZeFFzklvmxMLWIcZx7vdkCXuUVGegAQVahKqj5PTpwmopHhp4HOCtflB/tv
BtD9Cg95abElvWOsQQJBAOhLD0zVbhfiYHUNgBJvol1mXJo0fOiY9YzXIOfJUzoQ
hzudFh8UAUT21Zq2AiwHZS0tjvnsg+84B9fmSK9EXdkCQQDS1UJ02S/MDcGGGmql
c08rlHfE/ME1IL71Eb8b1ZGAlttEWVQvuuXCIH8qKS3X6dkTNcPanvJjzi69tgmN
umVfAkEAjpCynTdIUERRasWUWrxE7AnMv5+DIcXuvjeyLE91Uued98pbL0u507ei
NUeLYbZQNEAHxf+QoZrDxY/CAD93UQJARpqKPc05t3Dn3PvduPhri+GVVk96eEs2
B6XgxPZ5WoGqfjIYAj/pj2AIldrickrqmgdIRl8yNwAmIPvkKSVBqwJATDrIN+IX
keyzZc3UAcnWuDDWguoeKhhcmIhrZm0xe1ItbB6hJ0tj4pGfsRkedGuO04m16GvS
ujplzKAJeKclJA==
-----END PRIVATE KEY-----';
    private $gy_key = '-----BEGIN PUBLIC KEY-----
MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCr26at3zgcQ+iZy85g9Yze2K+d
Q8rs1V40+z9tXRE72AVEHn6hZd8e6hyqQzD3xQtlC8Cf6SHXOT5n/8jHYwVr9yF3
ut5M0q+MIqGhppzttvjTxXAR37xv4F0pNCiat/Z5+qiSSUwIv+TtGN82BKwaMtgi
M9zpBRsybMxlOJMDPwIDAQAB
-----END PUBLIC KEY-----';

    /***************单笔代付*********************/
    public  function pay(){
        /***********************帐号密码*******************************/

        $gymchtKey ="804920e93b9f4a3e84d0bbe6667cb004";//商户号804920e93b9f4a3e84d0bbe6667cb004

        $data = array();
        $msg = array();
        $data['gymchtId'] ="gypay0180156";//商户号gypay0180156
        $data['dfSn'] = 'CS'.date('YmdHis').rand(1000,9999);//商户代付订单号
        $data['receiptAmount'] = 10000;//代付金额
        $data['curType'] = 1;//金额类型 1-人民币
        $data['payType'] = 1;//付款方式
        $data['receiptName'] = '覃小寅';//收款人姓名
        $data['receiptPan'] = "6226590004642166";//收款人卡号
        $data['receiptBankNm'] = "光大银行";//收款银行
        $data['settleNo'] = "95595";//联行号
        $data['acctType'] = "0";//账号类型
        $data['mobile'] = "13428919194";//收款人手机号码
        $data['nonce'] = md5(time().mt_rand(0,1000));//随机字符串

        $sign = $this->rsaSign($data);//私钥加密签名

        $data['sign'] = $sign;
        $msg['cipher_data'] = $this->rsaEncrypt($data);//公钥加密报文

        $url="http://qr.guoyinpay.com:7777/gyprovider/daifus/singlePay.do";
        $rs = $this->httpClient($msg, $url);
        $rs = json_decode($rs, true);


        if($rs['resultCode'] == '00000'){
            $cipherData = $this->rsaDecrypt($rs['cipher_data']);//私钥解密报文

            $cipherData = json_decode($cipherData, true);

            if($this->rsaVerify($cipherData, $cipherData['sign'])){
                echo $cipherData['dfState'];
            }else{
                echo '获取签名不正确';
            }
        }else{
            echo $rs['message'];
        }

    }

    /*
 *      RSA签名
 *      @param                      array                   $data           签名加密前的数组
 *      @return                     string                  $encrypted      签名后字符串
 *
 *      教程附录：
 *      ftp上传私钥证书、国银公钥证书到项目根目录；
 *      请求报文 商户私钥加密签名，国银公钥加密报文；
 *      返回报文 商户私钥解密报文，国银公钥验证签名；
 *
 */
    public function rsaSign($data)
    {
        $data = $this->sort($data, '0');//0 不保留sign字段

        $rs = openssl_sign($data, $encrypted, $this->pi_key, OPENSSL_ALGO_SHA1);
        openssl_free_key($this->pi_key);

        $encrypted = base64_encode($encrypted);

        return $encrypted;
    }

    /*
*       RSA加密报文
*       @param			array                   $data		需要加密的数据
*       @return                     string                  $sign           返回报文加密后的字符串
*/
    public function rsaEncrypt($data)
    {
        $encrypted = '';
        $partialEncrypted = '';
        $ENCRYPT_BLOCK_SIZE = 117;

        $data = $this->sort($data, '1');//1 保留sign字段

        $data = str_split($data, $ENCRYPT_BLOCK_SIZE);
        foreach($data as $chunk)
        {
            $encryptionOk = openssl_public_encrypt($chunk, $partialEncrypted, $this->gy_key, OPENSSL_PKCS1_PADDING);
            $encrypted .= $partialEncrypted;
        }

        $encrypted = base64_encode($encrypted);

        return $encrypted;
    }

    /*
  *      post方法请求
  *      @param      array       $data       post数据
  *      @param      string      $url        server url
  *      @return     json        $rs         接口返回数据,此demo中为返回json数据
  */
    public function httpClient($data, $url)
    {
        $postdata = http_build_query($data);
        try {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
            $res = curl_exec($ch);
            curl_close($ch);
            return $res;
        } catch (Exception $e) {
            $errorMsg = $e->getMessage();
            return false;
        }
    }
    /*
*       RSA解密：私钥解密，
*       @param              string                  $data                   需要加密的数据
*       @return             string                  $origDecStr             密文解密之后的字符串
*/
    public function rsaDecrypt($originalEncStr)
    {
        $origDecStr = '';
        $partialDecrypt = '';

        $originalEncStr = base64_decode($originalEncStr);

        for($i=0;$i<strlen($originalEncStr)/128;$i++)
        {
            $data = substr($originalEncStr, $i*128, 128);
            openssl_private_decrypt($data, $partialDecrypt, $this->pi_key);
            $origDecStr.=$partialDecrypt;
        }

        return $origDecStr;

    }

    /*
     *      RSA验签：公钥验证签名
     *      @param              string                  $originalStr            签名的数据
     *      @param              string                  $sign                   签名
     *      @return             bool                    $rs                     返回结果，验签通过为ture 不通过为false
     */
    public function rsaVerify($originalStr, $sign)
    {
        $originalStr = $this->sort($originalStr, '0');//0 不保留sign字段

        $sign = base64_decode($sign);

        $rs = openssl_verify($originalStr, $sign, $this->gy_key);
        openssl_free_key($this->gy_key);

        return $rs;
    }
    /*
 *      数组排序,规则是:按参数名称a-z排序,遇到空值的参数不参加排序。
 *      @params         array               $data               参与排序的数组
 *      @params         string              $type               类型 0 去除sign 1 保留sign，默认为0
 *      @return         string              $sign               返回排序之后的数组
 */
    public function sort($data,$type='0')
    {
        $signPars = "";

        ksort($data);

        foreach($data as $k => $v) {
            if("" != $v && ("sign" != $k || $type == '1')) {
                $signPars .= $k . "=" . $v . "&";
            }
        }

        $signPars = substr($signPars, 0, -1);

        return $signPars;
    }

}