<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/10/15 0015
 * Time: 19:38
 */
//检测验证码
function check_code($code, $id = ""){
    $verify = new \Think\Verify();
    return $verify->check($code, $id);
}

/**
 * 删除数组指定元素
 * @param $arr
 * @param $value
 * @return mixed
 */
function delByValue($primaryArray,$removeArray,$isValue=true){
    if($isValue){
        //删除指定的重复值
        foreach($primaryArray as $primaryKey=>$primaryValue){
            foreach($removeArray as $removeKey=>$removeValue){
                if($primaryValue == $removeValue){
                    unset($primaryArray[$primaryKey]);
                }
            }
        }
    }else{
        //删除指定KEY
        foreach($removeArray as $removeKey=>$removeValue){
            unset($primaryArray[$removeValue]);
        }

    }
    return $primaryArray;
}