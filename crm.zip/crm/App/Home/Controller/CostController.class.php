<?php

namespace Home\Controller;

require_once ("./App/Common/lianlian/llpay.config.php");
//require_once ("./App/Common/lianlian/lib/llpay_notify.class.php");//这样子写不行，得将该文件转换成类文件
//use Common\lianlian/lib/llpay_notify;
//use Common\lianlian\lib\llpay_notify;

use Common\Controller\CommonController;

class CostController extends CommonController {

    public function index() {
        $this->display();
    }

    //列表数据
    public function listData() {

        $CostModel = M('PayrcCost');

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') : I('limit');
        //搜索条件
        $s_time = strtotime(I('searchStatrDate'));
        $e_time = strtotime(I('searchEndDate') . " 23:59:59");
        $where = (I('post.username') == '') ? '' : ' AND payrc.username LIKE "%' . I('post.username') . '%"'; //用户名
        $where .= (I('post.nub') == '') ? '' : ' AND payrc.pay_order LIKE "%' . I('post.nub') . '%"'; //单号
        $where .= (I('post.status') == '') ? '' : ' AND a.status=' . I('post.status'); //类型
        $where .= (I('post.searchEndDate') != '' && I('post.searchStatrDate') != '') ? ' AND a.create_time >' . $s_time . ' AND a.create_time <' . $e_time : ' '; //时间


        $data = $CostModel
                ->field('a.*,
                   payrc.username,
                   payrc.pay_money,
                   payrc.pay_fee,
                   payrc.pay_mub,
                   payrc.pay_order as plan_order')
                ->alias('a')
                ->join('LEFT JOIN __PAYRC__ as payrc ON a.payrc_id=payrc.id')
                ->where("1=1" . $where)
                ->limit($offset, $limit)
                ->order('a.id desc')
                ->select();

        $num = $CostModel
                ->field('a.*,
                   payrc.username,
                   payrc.pay_money,
                   payrc.pay_fee,
                   payrc.pay_mub,
                   payrc.pay_order as plan_order')
                ->alias('a')
                ->join('LEFT JOIN __PAYRC__ as payrc ON a.payrc_id=payrc.id')
                ->where("1=1" . $where)
                ->count();

        foreach ($data as $k => $v) {
            if ($v['pay_time'] != 0) {
                $data[$k]['pay_time'] = date('Y-m-d H:i:s', $v['pay_time']);
            }
            $data[$k]['create_time'] = date('Y-m-d H:i:s', $v['create_time']);
        }
//        dump($data );
        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;
    }

    //手动消费页面
    public function op() {
        $I = I();
        //还款计划查询
        $payrcModel = M('Payrc');
        $payrc = $payrcModel->where('id=' . $I['payrc_id'])->find();
        //信用卡查询
        $rcModel = M('Rc');
        $rc = $rcModel->where('id=' . $payrc['rc_id'])->find();
        //实名制查询
        $userBankModel = M('UserBank');
        $userBank = $userBankModel->where('type=1 and username=' . $rc['username'])->find();
        //参数
        $data['id'] = $I['id'];
        $data['username'] = $I['username'];
        $data['pay_order'] = $I['pay_order']; //订单号
        $data['money'] = $I['money']; //金额
        $data['user'] = $rc['user']; //持卡人姓名
        $data['nub'] = $rc['nub']; //持卡人卡号
        $data['bank_name'] = $rc['bank_name']; //银行名称
        $data['ic'] = $userBank['ic']; //身份证号
        $data['create_time'] = date('Y-m-d', $payrc['create_time']);
        $data['phone'] = $rc['phone']; //手机号

        $this->assign('data', $data);
        $this->display();
    }

    //手动消费逻辑
    public function opServe() {
        $I = I();
        $payrcCost = M('PayrcCost');
        if ($I['is_pass'] == 0) {//通过
            $res = $payrcCost->where('status=1 and id=' . $I['id'])->find(); //检验是否已完成
            if ($res) {
                $this->jumpInfo(array('info' => '该订单已完成!', 'msg' => '', 'type' => 'error', 'status' => 'n'));
            }
            $array = array('type' => 1);
        } elseif ($I['is_pass'] == 1) {//不通过
            $array = array('type' => 0);
        }

        $result = $payrcCost->where('id=' . $I['id'])->save(array('status' => 1));
        if ($result) {
            $this->jumpInfo(array('info' => '操作成功!', 'msg' => '',));
        } else {
            $this->jumpInfo(array('info' => '操作失败!', 'msg' => '',));
        }
    }

    /*
     * 连连支付异步通知页面（测试用）
     * @lin
     */

    public function notify() {
        //计算得出通知验证结果
//        $llpayNotify = new LLpayNotify($llpay_config);
//        $verify_result = $llpayNotify->verifyNotify();

        if ($verify_result) { //验证成功
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            //请在这里加上商户的业务逻辑程序代
            echo "<script>alert('交易成功')</script>";
            
            //——请根据您的业务逻辑来编写程序（以下代码仅作参考）——
            //获取连连支付的通知返回参数，可参考技术文档中服务器异步通知参数列表
            $is_notify = true;
            include_once ('lib/llpay_cls_json.php');
            $json = new JSON;
            $str = file_get_contents("php://input");
            $val = $json->decode($str);
            $oid_partner = trim($val->{
                    'oid_partner' });
            $dt_order = trim($val->{
                    'dt_order' });
            $no_order = trim($val->{
                    'no_order' });
            $oid_paybill = trim($val->{
                    'oid_paybill' });
            $money_order = trim($val->{
                    'money_order' });
            $result_pay = trim($val->{
                    'result_pay' });
            $settle_date = trim($val->{
                    'settle_date' });
            $info_order = trim($val->{
                    'info_order' });
            $pay_type = trim($val->{
                    'pay_type' });
            $bank_code = trim($val->{
                    'bank_code' });
            $sign_type = trim($val->{
                    'sign_type' });
            $sign = trim($val->{
                    'sign' });
            file_put_contents("log.txt", "异步通知 验证成功\n", FILE_APPEND);
            die("{'ret_code':'0000','ret_msg':'交易成功'}"); //请不要修改或删除
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        } else {
            echo "<script>alert('交易失败')</script>";
            
            file_put_contents("log.txt", "异步通知 验证失败\n", FILE_APPEND);
            //验证失败
            die("{'ret_code':'9999','ret_msg':'验签失败'}");
            //调试用，写文本函数记录程序运行情况是否正常
            //logResult("这里写入想要调试的代码变量值，或其他运行的结果记录");
        }
    }

}
