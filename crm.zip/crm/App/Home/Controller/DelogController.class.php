<?php
namespace Home\Controller;

use Common\Controller\CommonController;

class DelogController extends CommonController{

    public function index(){
        $this->display();
    }
    //列表数据
    public function listData(){

        $PayrcModel = M('DefrayrcLog');

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');
        //搜索条件
        $s_time=strtotime(I('searchStatrDate'));
        $e_time=strtotime(I('searchEndDate')." 23:59:59");
        $where = (I('post.username') == '') ? '' : ' AND a.username LIKE "%'.I('post.username').'%"';//用户名
//        $where.= (I('post.nub') == '') ? '' : ' AND rc.nub LIKE "%'.I('post.nub').'%"';//卡号
        $where.= (I('post.type') =='') ?    '' : ' AND type='.I('post.type');//类型
        $where.= (I('post.searchEndDate')!=''&& I('post.searchStatrDate')!='') ? ' AND a.create_time >'.$s_time.' AND a.create_time <'.$e_time : ' ';//时间


        $data = $PayrcModel
            ->field('a.*,
                   de_rc.nub,
                   bank.account')
            ->alias('a')
            ->join('LEFT JOIN __DEFRAYRC__ as de_rc ON a.rc_id=de_rc.id')
            ->join('LEFT JOIN __USER_BANK__ as bank ON a.bank_id=bank.id')
            ->where("1=1".$where)
            ->limit($offset, $limit)
            ->order('a.id desc')
            ->select();

        $num = $PayrcModel
            ->field('a.*,
                   de_rc.nub,
                   bank.account')
            ->alias('a')
            ->join('LEFT JOIN __DEFRAYRC__ as de_rc ON a.rc_id=de_rc.id')
            ->join('LEFT JOIN __USER_BANK__ as bank ON a.bank_id=bank.id')
            ->where("1=1".$where)
            ->order('a.id desc')->count();

        foreach($data as $k=>$v){
            $data[$k]['create_time']=date('Y-m-d H:i:s',$v['create_time']);
        }
        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;
    }

}