<?php
namespace Home\Controller;

use Common\Controller\CommonController;

class GradeController extends CommonController{

    public function index(){
        $this->display();
    }
    //列表数据
    public function listData(){

        $UserModel = M('Grade');

        $where = (I('post.search') == '') ? '' : ' AND a.username LIKE "%'.I('post.search').'%"';//用户名

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');

        $data = $UserModel->where("is_delete=0".$where)->limit($offset, $limit)->select();
        $num = $UserModel->where('is_delete=0')->count();

        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;
    }
    //编辑页面
    public function update(){
        $data=I('post.');
        $this->assign('data',$data);
        $this->display();
    }
    //编辑逻辑
    public function updateServe(){
      $data=I('post.');

      $model=M('Grade');

      $result=$model->where(array('grade'=>$data['id']))->save($data);

      $this->addLog("编辑会员等级:".$data['name']."的信息",0);// 记录操作日志

      $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
    }
}