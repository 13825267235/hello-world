<?php
namespace Home\Controller;

use Common\Controller\CommonController;

class IcController extends CommonController{

    public function index(){
        $this->display();
    }
    //列表数据
    public function listData(){

        $UserModel = M('UserBank');

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');
        //搜索条件
        $s_time=strtotime(I('searchStatrDate'));
        $e_time=strtotime(I('searchEndDate')." 23:59:59");
        $where = (I('post.username') == '') ? '' : ' AND username LIKE "%'.I('post.username').'%"';//用户名
        $where.= (I('post.type') =='') ?    '' : ' AND type='.I('post.type');//类型
        $where.= (I('post.searchEndDate')!=''&& I('post.searchStatrDate')!='') ? ' AND create_time >'.$s_time.' AND create_time <'.$e_time : ' ';//时间


        $data = $UserModel->where("type <>2".$where)->limit($offset, $limit)->order('id desc')->select();
        $num = $UserModel->where("type <>2".$where)->count();

        foreach($data as $k=>$v){
            $data[$k]['create_time']=date('Y-m-d H:i:s',$v['create_time']);
        }
        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;
    }
    //页面
    public function op(){
        $data=I();
        $this->assign('data',$data);
        $this->display();
    }
    //认证逻辑
    public function opServe(){
        $data=I('');

        $userBankModel=M('UserBank');

        $array=array();
        if($data['is_pass']==0){//通过
            $res=$userBankModel->where('type=1 and username='.$data['username'])->find();//检验是否已认证
            if($res){
                $this->jumpInfo(array('info' => '该用户已实名认证!', 'msg' => '', 'type' => 'error','status'=>'n'));
            }
            $array=array('type'=>1);
        }elseif($data['is_pass']==1){//不通过
            $array=array('type'=>2);
        }
        $result=$userBankModel->where('id='.$data['id'])->save($array);

        if($result){
            $this->addLog("通过:".$data['username']."的实名认证",1);// 记录操作日志

            $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
        }else{
            $this->addLog("未通过:".$data['username']."的实名认证",1);// 记录操作日志

            $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
        }
    }
}