<?php
namespace Home\Controller;

use Common\Controller\CommonController;

class IndexController extends CommonController{
    //后台页面
    public function index(){
        $this->display();
    }

//    public function aa(){
//        $gradeModel=M('Grade');
//        $array=array(
//            array('msg'=>'1.享受直推的用户代还1万元可得15元返佣;享受直推的用户收款1万元可得5元返佣.'),
//            array('msg'=>'2.直推用户付费升级可得升级费用50%返佣,间接推荐10%返佣,再间接推荐10%返佣;用户升级为VIP会员,可得34元/人;升级为高级VIP,可得94元/人;升级为市级代理,可得490元/人;升级为省级代理,可得1490元/人;升级为合伙人代理,可得3440元/人;升级为运营中心代理,可得4900元/人.'),
//          );
//        $array=json_encode($array);
//        $gradeModel->where('grade=2')->save(array('info'=>$array));
//    }
//    public function bb(){
//        $gradeModel=M('Grade');
//        $array=array(
//            array('msg'=>'1.享受VIP会员一切权利.'),
//            array('msg'=>'2.直推用户付费升级可得升级费用50%返佣,间接推荐10%返佣,再间接推荐10%返佣.'),
//            array('msg'=>'3.享受旗下VIP会员每代还1万元可得10元返佣,享受直推的用户每收款1万元可得2元返佣;直推用户付费升级可得升级费50%返佣,间接推荐10%返佣,再间接推荐10%返佣;旗下直推用户升级运营中心,可得4900/人.'),
//);
//        $array=json_encode($array);
//        $gradeModel->where('grade=3')->save(array('info'=>$array));
//    }
//    public function cc(){
//        $gradeModel=M('Grade');
//        $array=array(
//            array('msg'=>'1.享受高级VIP一切权利.'),
//            array('msg'=>'2.享受直推的用户每代还1万元可得29元返佣;享受直推的用户每收款1万元可得10元返佣.'),
//            array('msg'=>'3.享受旗下VIP会员每代还1万元可得14元返佣,享受直推的用户每收款1万元可得5元返佣.'),
//            array('msg'=>'4.享受旗下高级VIP每代还1万元可得4元返佣,享受直推的用户每收款1万元可得3元返佣;直推用户付费升级可得升级费50%返佣,间接推荐10%返佣,再间接推荐10%返佣;旗下直推用户升级运营中心,可得4900/人.'),
//    );
//        $array=json_encode($array);
//        $gradeModel->where('grade=4')->save(array('info'=>$array));
//    }
//    public function dd(){
//        $gradeModel=M('Grade');
//        $array=array(
//            array('msg'=>'1.享受市级代理一切权利.'),
//            array('msg'=>'2.享受直推的用户每代还1万元可得32元返佣;享受直推的用户每收款1万元可得12元返佣.'),
//            array('msg'=>'3.享受旗下VIP会员每代还1万元可得17元返佣,享受直推的用户每收款1万元可得7元返佣.'),
//            array('msg'=>'4.享受旗下高级VIP每代还1万元可得7元返佣,享受直推的用户每收款1万元可得5元返佣.'),
//            array('msg'=>'5.享受旗下市级代理每代还1万可得3元返佣,享受直推的用户每收款1万元可得2元返佣;直推用户付费升级可得升级费50%返佣,间接推荐10%返佣,再间接推荐10%返佣;旗下直推用户升级运营中心,可得4900/人.'),
//     );
//        $array=json_encode($array);
//        $gradeModel->where('grade=5')->save(array('info'=>$array));
//    }
//    public function ee(){
//        $gradeModel=M('Grade');
//        $array=array(
//            array('msg'=>'1.享受省级代理一切权利.'),
//            array('msg'=>'2.享受直推的用户每代还1万元可得35元返佣;享受直推的用户每收款1万元可得15元返佣.'),
//            array('msg'=>'3.享受旗下VIP会员每代还1万元可得14元返佣,享受直推的用户每收款1万元可得12元返佣.'),
//            array('msg'=>'4.享受旗下高级VIP每代还1万元可得4元返佣,享受直推的用户每收款1万元可得10元返佣.'),
//            array('msg'=>'5.享受旗下市级代理每代还1万可得4元返佣,享受直推的用户每收款1万元可得5元返佣.'),
//            array('msg'=>'6.享受旗下省级代理每代还1万可得4元返佣,享受直推的用户每收款1万元可得3元返佣;直推用户付费升级可得升级费50%返佣,间接推荐10%返佣,再间接推荐10%返佣;旗下直推用户升级运营中心,可得4900/人.'));
//        $array=json_encode($array);
//        $gradeModel->where('grade=6')->save(array('info'=>$array));
//    }
//    public function ff(){
//        $gradeModel=M('Grade');
//        $array=array(
//            array('msg'=>'1.享受合伙人级代理一切权利.'),
//            array('msg'=>'2.享受直推的用户每代还1万元可得37元返佣;享受直推的用户每收款1万元可得17元返佣'),
//            array('msg'=>'3.享受旗下VIP会员每代还1万元可得22元返佣;享受直推的用户每收款1万元可得12元返佣'),
//            array('msg'=>'4.享受旗下高级VIP每代还1万元可得12元返佣;享受直推的用户每收款1万元可得10元返佣.'),
//            array('msg'=>'5.享受旗下市级代理每代还1万可得8元返佣;享受直推的用户每收款1万元可得7元返佣.'),
//            array('msg'=>'6.享受旗下省级代理每代还1万可得5元返佣;享受直推的用户每收款1万元可得5元返佣.'),
//            array('msg'=>'7.享受旗下合伙人代理每代还1万可得2元返佣;享受直推的用户每收款1万元可得2元返佣;直推用户付费升级可得升级费50%返佣,间接推荐10%返佣,再间接推荐10%返佣;旗下直推用户升级运营中心,可得4900/人.'));
//        $array=json_encode($array);
//        $gradeModel->where('grade=7')->save(array('info'=>$array));
//    }
//        public function aa(){
//            //vMaBsBtyiW8bIHq5RZEjDCijEF38zq
//            $AccessKeySecret="vMaBsBtyiW8bIHq5RZEjDCijEF38zq";//OtxrzxIsfpFjA7SwPzILwy8Bw21TLhquhboDYROV
//            $VERB="GET";
//            $MD5="";
//            $Type="";
//            $Date=gmdate('D, d M Y H:i:s \G\M\T');//gmdate("M d Y H:i:s");
//            $CanonicalizedOSSHeaders="";
//            $CanonicalizedResource="leisigou-oos.oss-cn-shenzhen.aliyuncs.com";
//
//           $Signature = base64_encode(sha1($AccessKeySecret,
//                    $VERB."\n"
//                   .$MD5."\n"
//                   .$Type."\n"
//                   .$Date."\n"
//                   .$CanonicalizedOSSHeaders
//                   .$CanonicalizedResource));
//
//            echo $Signature;
//        }
//    public function aa(){
//        $this->display();
//    }
}