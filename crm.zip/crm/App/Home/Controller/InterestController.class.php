<?php
namespace Home\Controller;

use Common\Controller\CommonController;

class InterestController extends CommonController{

    public function index(){
        $this->display();
    }
    //列表数据
    public function listData(){

        $InterestModel = M('Interest');

        //搜索条件
        $s_time=strtotime(I('searchStatrDate'));
        $e_time=strtotime(I('searchEndDate')." 23:59:59");
        $where ='1=1';
        $where.= (I('post.username') == '') ? '' : ' AND a.username LIKE "%'.I('post.username').'%"';//用户名
        $where.= (I('post.gain_type') =='') ?    '' : ' AND a.gain_type='.I('post.gain_type');//提现类型
        $where.= (I('post.searchEndDate')!=''&& I('post.searchStatrDate')!='') ? ' AND a.create_time >'.$s_time.' AND a.create_time <'.$e_time : ' ';//时间

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');

        $data = $InterestModel
            ->field('a.*,
                   user.username as child_user')
            ->alias('a')
            ->join('LEFT JOIN __USER__ as user ON a.child_id=user.id')
            ->where($where)
            ->limit($offset, $limit)
            ->order('a.id desc')
            ->select();
        $num = $InterestModel
            ->field('a.*,
                   user.username as child_user')
            ->alias('a')
            ->join('LEFT JOIN __USER__ as user ON a.child_id=user.id')
            ->where($where)
            ->count();
        foreach($data as $k=>$v){
            $data[$k]['create_time']=date('Y-m-d H:i:s',$v['create_time']);
        }

        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;
    }

}