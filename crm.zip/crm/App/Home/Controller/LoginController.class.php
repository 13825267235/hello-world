<?php
namespace Home\Controller;

use Common\Controller\CommonController;

class LoginController extends CommonController{

    public function login(){
        if(IS_POST){//检测登录

            $vcode = I('post.vcode'); //验证码

            $username = I('post.username'); //账号

            $password = md5(trim(I('post.password'))); //密码

            //检测验证码
            if ($vcode == '') {
                $this->jumpInfo(array('info' => '请输入验证码', 'status' => 'n'));
            } elseif (!check_code($vcode)) {
                $this->jumpInfo(array('info' => '验证码不正确', 'status' => 'n'));
            }

            $SysUserData = D('SysUser') ;

            $data = $SysUserData->login($username, $password); //检测账号密码

            if ($data['status']) {

                session(C('ADMIN_SESSION'), $data ['data']);

//                $this->addLog('login_id=' . $data ['data']['id'] . '&ip=' . get_client_ip());// 记录操作日志

                $this->insert_log($data ['data']['id'], $data ['data']['username'], '', 1);// 记录登录日志

                $this->jumpInfo(array('url' => '/'.C('MODEL_NAME').'/Index/index', 'info' => '登录成功！~'));

            } else {

                $this->insert_log('', $username, $password, 0);// 记录登录日志

                $this->jumpInfo(array('info' => $data['message'], 'status' => 'n'));

            }
        }else{
            if (!$this->CheckUser()) {
                $this->display();
            } else {
                $this->redirect(''.C('MODEL_NAME').'/Index/index');
            }
        }

    }

    //后台退出登录
    public function logout()
    {
        session(C('ADMIN_SESSION'),NULL);//删除session
        $this->jumpInfo(array('info' => '^_^ 退出成功欢迎您下次使用', 'url' => '/'.C('MODEL_NAME').'/Login/login', 'timer' => 1000, 'msg' => ''));
    }

    //验证码
    public function getVerify()
    {
        $config = array(
            'fontSize' => 50,    // 验证码字体大小
            'length' => 4,     // 验证码位数
            'useNoise' => false, // 关闭验证码杂点 fontttf
            'fontttf' => '5.ttf', // 指定验证码字体 默认为随机获取
            'codeSet' => '0123456789', // 验证码字符集合
            'useCurve' => false, // 是否使用混淆曲线 默认为true
        );
        $Verify = new \Think\Verify($config);
        $Verify->entry();
    }
    //登录日志
    public function insert_log($userid,$username,$password,$status,$is_sys=1){
        $ip   = get_client_ip(); // 本次登录IP，时间，登录位置
        $Ip   = new \Common\Org\IpLocation ('UTFWry.dat');
        $region = $Ip->getlocation($ip); // 获取某个IP地址所在的位置
        $LoginLogData = M('LoginLog');
        $LogData = array();
        $LogData['user_id']= $userid;
        $LogData['user_name']= $username;
        $LogData['is_sys']= $is_sys;
        $LogData['logintime']= time();
        $LogData['loginip'] = $ip;
        $LogData['status']= $status;
        $LogData['type']= 1;
        $LogData['pass_word']= $password;
        $LogData['region']= $region['country'].',运营商：'.$region['area'];
        $LogData['equipment']=1;
        $LogData['create_time']=time();

        $LoginLogData->add($LogData);
    }

}
