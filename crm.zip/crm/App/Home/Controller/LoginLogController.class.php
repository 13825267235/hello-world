<?php
namespace Home\Controller;

use Common\Controller\CommonController;

class LoginLogController extends CommonController
{
    public function loginLog()
    {
        $this->display('loginLog');
    }

     //后台用户
    public function loginLogData(){

        $LoginLogModel = M('LoginLog');

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');

        $startTime = I('searchStatrDate');

        $endTime = I('searchEndDate');

        $where ="type=1";

        $where .= (I('searcHorderUsername') == null) ? '' : " AND user_name LIKE '%".I('searcHorderUsername')."%' ";

        $where .= ($startTime !='' && $endTime !='') ?  " AND logintime >= ".strtotime($startTime)." AND logintime <= ".strtotime($endTime.'23:59:00') : "";

        $where .= (I('uid') == null) ? '' : " AND user_id=".I('uid');

        $data = $LoginLogModel
            ->order('logintime desc')
            ->where($where)
            ->limit($offset, $limit)
            ->select();

        $num = $LoginLogModel->where($where)->count();

        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;

    }

     //前端用户
    public function index()
    {
        $this->display();
    }

    //后台
    public function data(){



        $LoginLogModel = D('LoginLog');

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');

        $startTime = I('searchStatrDate');

        $endTime = I('searchEndDate');

        $where ="type=2";

        $where .= ($startTime !='' && $endTime !='') ?  " AND logintime >= ".strtotime($startTime)." AND logintime <= ".strtotime($endTime.'23:59:00') : "";

        $where .= (I('searcHorderUsername') == null) ? '' : " AND user_name LIKE '%".I('searcHorderUsername')."%'  OR  loginip LIKE '%".I('searcHorderUsername')."%' ";

        $where .= (I('uid') == null) ? '' : " AND user_id=".I('uid');

        $data = $LoginLogModel
            ->order('logintime desc')
            ->where($where)
            ->limit($offset, $limit)
            ->select();

        $num = $LoginLogModel->where($where)->count();
        foreach($data as $k=>$v){
            $data[$k]['logintime']=date('Y-m-d H:i:s',$v['logintime']);
        }

        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;

    }

    //操作日志页面
    public function action(){
        $this->display();
    }

    public function actionData(){

        $LoginLogModel = M('ActionLog');

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');

        $startTime = I('searchStatrDate');

        $endTime = I('searchEndDate');

        $where ="type=2";

        $where .= (I('searcHorderUsername') == null) ? '' : " AND user_name LIKE '%".I('searcHorderUsername')."%' ";

        $where .= ($startTime !='' && $endTime !='') ?  " AND time >= ".strtotime($startTime)." AND time <= ".strtotime($endTime.'23:59:00') : "";

        $where .= (I('searcState') == null) ? '' : " AND action=".I('searcState');

        $where .= (I('uid') == null) ? '' : " AND user_id=".I('uid');

        $data = $LoginLogModel
            ->order('time desc')
            ->where($where)
            ->limit($offset, $limit)
            ->select();

        $num = $LoginLogModel ->where($where)->count();

        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;
    }
}