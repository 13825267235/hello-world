<?php
namespace Home\Controller;

use Common\Controller\CommonController;

class PayrcController extends CommonController{

    public function index(){
        $this->display();
    }
    //列表数据
    public function listData(){

        $PayrcModel = M('Payrc');

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');
        //搜索条件
        $s_time=strtotime(I('searchStatrDate'));
        $e_time=strtotime(I('searchEndDate')." 23:59:59");
        $where = (I('post.username') == '') ? '' : ' AND a.username LIKE "%'.I('post.username').'%"';//用户名
        $where.= (I('post.nub') == '') ? '' : ' AND rc.nub LIKE "%'.I('post.nub').'%"';//卡号
        $where.= (I('post.type') =='') ?    '' : ' AND type='.I('post.type');//类型
        $where.= (I('post.searchEndDate')!=''&& I('post.searchStatrDate')!='') ? ' AND a.create_time >'.$s_time.' AND a.create_time <'.$e_time : ' ';//时间


        $data = $PayrcModel
            ->field('a.*,
                   rc.nub')
            ->alias('a')
            ->join('LEFT JOIN __RC__ as rc ON a.rc_id=rc.id')
            ->where("1=1".$where)
            ->limit($offset, $limit)
            ->order('a.id desc')
            ->select();

        $num = $PayrcModel
            ->field('a.*,
                   rc.nub')
            ->alias('a')
            ->join('LEFT JOIN __RC__ as rc ON a.rc_id=rc.id')
            ->where("1=1".$where)
            ->order('a.id desc')->count();

        foreach($data as $k=>$v){
            $data[$k]['create_time']=date('Y-m-d H:i:s',$v['create_time']);
            $data[$k]['s_time']=date('Y-m-d',$v['s_time']);
            $data[$k]['e_time']=date('Y-m-d',$v['e_time']);

        }
        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;
    }
    //流水记录
    public function account(){
        $id=I('id');
        //消费流水
        $costModel=M('PayrcCost');
        $cost=$costModel->where('payrc_id='.$id)->select();
        //还款流水
        $repayModel=M('PayrcRepay');
        $repay=$repayModel->where('payrc_id='.$id)->select();
        $this->assign('cost',$cost);
        $this->assign('repay',$repay);
        $this->display();
    }
}