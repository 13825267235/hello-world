<?php
namespace Home\Controller;

use Common\Controller\CommonController;

class PushController extends CommonController{
    //消息页面
    public function index(){
        //分层
        $gradeModel=M('Grade');
        $grade=$gradeModel->where("is_delete=0 and is_used=0")->select();

        $this->assign('infoData',$grade);
        $this->display();
    }
    //消息列表
    public function getData(){

        $newsModel = M('News');

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');

        $data = $newsModel
            ->where('is_delete=0')
            ->limit($offset, $limit)
            ->select();

        $num = $newsModel->where('is_delete=0')->count();
        foreach($data as $k=>$v){
            $data[$k]['create_time']=date('Y-m-d',$v['create_time']);
        }
        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;
    }
    //新增消息逻辑
    public  function sendoutss(){
         $session=session(C('ADMIN_SESSION'));

        if(I('type')==1){//全部会员
          $newsModel=M('News');
            if((I('titles'))==null){
                $this->jumpInfo(array('info' => '操作失败！', 'msg' => '标题不能为空!', 'type' => 'error', 'status' => 'n'));
            }
            if(I('contents')==""){
                $this->jumpInfo(array('info' => '操作失败！', 'msg' => '内容不能为空!', 'type' => 'error', 'status' => 'n'));
            }
            $data['sys_uid']=$session['id'];
            $data['way']=I('type');
            $data['type']=0;
            $data['titles']=I('titles');
            $data['contents']=I('contents');
            $data['create_time']=time();
            $result=$newsModel->add($data);
            $this->addLog("新增公告:".$data['titles']."",3);// 记录操作日志
            $this->jumpInfo(array('info' => '操作成功！', 'msg' => '发送成功！'));

        }
    }
    //删除消息
    public function delete(){
        $id=I('id');
        $newsModel=M('News');
        $newsModel->where('id='.$id)->save(array('is_delete'=>1));
        $this->addLog("删除公告:".I('titles')."",3);// 记录操作日志
        $this->jumpInfo(array('info' => '操作成功！', 'msg' => '删除成功！'));
    }
    //user人员列表
    public  function userList(){
        $username = I('q');
        $userModel = M('User');
        $where = "is_delete=0";
        $where .= ($username == '') ? "" : " AND username LIKE '%".$username."%' ";
        $data = $userModel->field("id,username")->where($where)->select();

        echo json_encode($data,true);
        exit;
    }

}