<?php
namespace Home\Controller;

use Common\Controller\CommonController;

class RepayController extends CommonController{

    public function index(){
        $this->display();
    }
    //列表数据
    public function listData(){

        $RepayModel = M('PayrcRepay');

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');
        //搜索条件
        $s_time=strtotime(I('searchStatrDate'));
        $e_time=strtotime(I('searchEndDate')." 23:59:59");
        $where = (I('post.username') == '') ? '' : ' AND payrc.username LIKE "%'.I('post.username').'%"';//用户名
        $where.= (I('post.nub') == '') ? '' : ' AND payrc.pay_order LIKE "%'.I('post.nub').'%"';//单号
        $where.= (I('post.status') =='') ?    '' : ' AND a.status='.I('post.status');//类型
        $where.= (I('post.searchEndDate')!=''&& I('post.searchStatrDate')!='') ? ' AND a.create_time >'.$s_time.' AND a.create_time <'.$e_time : ' ';//时间


        $data = $RepayModel
            ->field('a.*,
                   payrc.username,
                   payrc.pay_money,
                   payrc.pay_fee,
                   payrc.pay_mub,
                   payrc.pay_order as plan_order')
            ->alias('a')
            ->join('LEFT JOIN __PAYRC__ as payrc ON a.payrc_id=payrc.id')
            ->where("1=1".$where)
            ->limit($offset, $limit)
            ->order('a.id desc')
            ->select();

        $num = $RepayModel
            ->field('a.*,
                   payrc.username,
                   payrc.pay_money,
                   payrc.pay_fee,
                   payrc.pay_mub,
                   payrc.pay_order as plan_order')
            ->alias('a')
            ->join('LEFT JOIN __PAYRC__ as payrc ON a.payrc_id=payrc.id')
            ->where("1=1".$where)
            ->count();

        foreach($data as $k=>$v){
            if($v['pay_time']!=0){
                $data[$k]['pay_time']=date('Y-m-d H:i:s',$v['pay_time']);
            }
            $data[$k]['create_time']=date('Y-m-d H:i:s',$v['create_time']);
        }
//        dump($data );
        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;
    }
    //手动消费页面
    public function op(){
        $I=I();
        //还款计划查询
        $payrcModel=M('Payrc');
        $payrc=$payrcModel->where('id='.$I['payrc_id'])->find();
        //信用卡查询
        $rcModel=M('Rc');
        $rc=$rcModel->where('id='.$payrc['rc_id'])->find();
        //实名制查询
        $userBankModel=M('UserBank');
        $userBank=$userBankModel->where('type=1 and username='.$rc['username'])->find();
        //参数
        $data['id']=$I['id'];
        $data['username']=$I['username'];
        $data['pay_order']=$I['pay_order'];//订单号
        $data['money']=$I['money'];//金额
        $data['user']=$rc['user'];//持卡人姓名
        $data['nub']=$rc['nub'];//持卡人卡号
        $data['bank_name']=$rc['bank_name'];//银行名称
        $data['ic']=$userBank['ic'];//身份证号
        $data['create_time']=date('Y-m-d',$payrc['create_time']);
        $data['phone']=$rc['phone'];//手机号

        $this->assign('data',$data);
        $this->display();

    }
    //手动消费逻辑
    public function opServe(){
        $I=I();
        $payrcRepay=M('PayrcRepay');
        if($I['is_pass']==0){//通过
            $res=$payrcRepay->where('status=1 and id='.$I['id'])->find();//检验是否已完成
            if($res){
                $this->jumpInfo(array('info' => '该订单已完成!', 'msg' => '', 'type' => 'error','status'=>'n'));
            }
            $array=array('type'=>1);
        }elseif($I['is_pass']==1){//不通过
            $array=array('type'=>0);
        }

        $result=$payrcRepay->where('id='.$I['id'])->save(array('status'=>1));
        if($result){
            $this->jumpInfo(array('info' => '操作成功!', 'msg' => '',));
        }else{
            $this->jumpInfo(array('info' => '操作失败!', 'msg' => '',));
        }
    }
}