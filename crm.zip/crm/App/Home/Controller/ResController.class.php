<?php
namespace Home\Controller;
use Common\Controller\CommonController;

class ResController extends CommonController
{

    /**
     * @describe 菜单列表展示
     * @author eleven
     */
    public function index()
    {
        $this->display();
    }

    /**
     * @describe 菜单列表数据
     * @author eleven
     */
    public function listData()
    {
        $resModel = D('Res');

        $data = $resModel->recursionAll();

        $res = array();

        $num = $resModel->where('is_delete=0')->count();

        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;
    }

    /**
     * @describe 添加子菜单展示
     * @author eleven
     */
    public function add(){
        $this->display();
    }

    /**
     * @describe 添加子菜单展示
     * @author eleven
     */
    public function addSubmenu(){
        $resModel = M('Res');
        $id = I('id');
        $dataInfo = $resModel->where("id=".$id)->field("id,name")->find();
        $this->assign('dataInfro',$dataInfo);
        $this->display('addSubmenu');
    }

    /**
     * @describe 编辑菜单展示
     * @author eleven
     */
    public function edit(){
        $resModel = M('Res');
        $id = I('id');
        $dataInfo = $resModel
            ->field('a.*,b.name AS bname')
            ->alias('a')
            ->join('LEFT JOIN __RES__  b ON b.id = a.parentid ')
            ->where("a.id=".$id)
            ->find();
        $this->assign('dataInfro',$dataInfo);
        $this->display();
    }

    /**
     * @describe 设置图标展示
     * @author eleven
     */
    public function ico(){
        $resModel = M('Res');
        $id = I('id');
        if($id){
            $dataInfo = $resModel->where("id=".$id)->field("id,ico")->find();
        }else{
            $dataInfo = '';
        }

        $this->assign('dataInfro',$dataInfo);
        $this->display();
    }

    /**
     * @describe 添加菜单保存
     * @author eleven
     */
    public function addServe(){
        $data = I();
        $ResModel = M('Res');

        $ResModel->data($data)->add();
       
        $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
    }

    /**
     * @describe 添加子菜单保存
     * @author eleven
     */
    public function addSubmenuServe(){
        $data = I();
        $ResModel = M('Res');
        $ResModel->data($data)->add();
        $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
    }

    /**
     * @describe 保存编辑菜单
     * @author eleven
     */
    public function deitServe(){

        $data = I();

        $id = I('id');

        $deleteData = array('id');

        $data = delByValue($data,$deleteData,false);

        $ResModel = M('Res');

        $result = $ResModel->where('id='.$id)->save($data); //根据条件更新记录

       

        if( $result > 0 || $result ==0 ){
            $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
        }else{
            $this->jumpInfo(array('info' => '操作失败请联系相关开发人员！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口', 'type' => 'error','status'=>'n'));
        }
    }

    /**
     * @describe 删除操作
     * @author eleven
     */
    public function delete(){

        $id = I('id');

        $ResModel = M('Res');

        $info = $ResModel->where("parentid=".$id." AND is_delete=0")->find();

       

        if(count($info)> 0){
            $this->jumpInfo(array('info' => '该菜单还有子菜单请先删除子菜单！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口', 'type' => 'error','status'=>'n'));
        }
        $result = $ResModel->where('id='.$id)->save(array('is_delete'=>1)); //根据条件更新记录

        if( $result > 0 || $result ==0 ){
            $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
        }else{
            $this->jumpInfo(array('info' => '操作失败请联系相关开发人员！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口', 'type' => 'error','status'=>'n'));
        }
    }

}
