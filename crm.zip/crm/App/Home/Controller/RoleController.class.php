<?php
namespace Home\Controller;

use Common\Controller\CommonController;

class RoleController extends CommonController
{

    /**
     * @describe 角色列表展示
     * @author eleven
     */
    public function index()
    {
        $this->display();
    }

    /**
     * @describe 角色列表数据
     * @author eleven
     */
    public function listData()
    {
        $roleModel = M('Role');

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');

        $data = $roleModel
            ->field('id,name,depict')
            ->where('is_delete=0')
            ->limit($offset, $limit)
            ->select();

        $num = $roleModel->where('is_delete=0')->count();

        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;
    }

    /**
     * @describe 权限展示
     * @author eleven
     */
    public function jurisdiction(){
        $id= I('id');
        $rule_data=$this->nav();
        $RoleModel = M('Role');
        $res = $RoleModel->where("id=".$id)->field('res')->find();
        $group_data = unserialize($res['res']);
        $this->assign('id',$id);
        $this->assign('group_data',$group_data);

        $this->assign('rule_data',$rule_data);
        $this->display();
    }

    /**
     * @describe 权限保存
     * @author eleven
     */
    public function jurisdictionServe(){
        $data = I();
        $res = serialize($data['rule_ids']);
        $RoleModel = M('Role');

        $result = $RoleModel->where('id='.$data['id'])->save(Array('res'=>$res)); //根据条件更新记录

        $re = $RoleModel->where('id='.$data['id'])->find();
//        $this->refreshRoleJurisdictionCache();
        $this->addLog("设置角色:".$re['name']."权限",4);// 记录操作日志
        $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
    }

    /**
     * @describe 添加角色展示
     * @author eleven
     */
    public function add(){
        $this->display();
    }

    /**
     * @describe 编辑角色展示
     * @author eleven
     */
    public function edit(){
        $roleModel = M('Role');
        $id = I('id');
        $dataInfo = $roleModel->field('id,name,depict')->where("id=".$id)->find();
        $this->assign('dataInfro',$dataInfo);
        $this->display();
    }

    /**
     * @describe 添加角色保存
     * @author eleven
     */
    public function addServe(){
        $data = I();
        $roleModel = M('Role');
//        $data['operator_id']=C('CONFIG_OPERATOR_CODE');
//        $data['operator_name']=C('CONFIG_OPERATOR_NAME');
        $data['update_time']=time();
        $data['create_time']=$data['update_time'];
        $data['res']="";
        $roleModel->data($data)->add();
        $this->addLog("新增后台角色:".$data['name'],4);// 记录操作日志
        $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
    }

    /**
     * @describe 保存编辑角色
     * @author eleven
     */
    public function deitServe(){

        $data = I();

        $id = I('id');

        $deleteData = array('id');

        $data = delByValue($data,$deleteData,false);

        $roleModel = M('Role');
        $res = $roleModel->where('id='.$id)->find();
        $result = $roleModel->where('id='.$id)->save($data); //根据条件更新记录


        if( $result > 0 || $result ==0 ){
            $this->addLog("编辑角色:".$res['name']."的信息",4);// 记录操作日志
            $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
        }else{
            $this->jumpInfo(array('info' => '操作失败请联系相关开发人员！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口', 'type' => 'error','status'=>'n'));
        }
    }

    /**
     * @describe 删除操作
     * @author eleven
     */
    public function delete(){

        $id = I('id');

        $roleModel = M('Role');

        $result = $roleModel->where('id='.$id)->save(array('is_delete'=>1)); //根据条件更新记录
        $res = $roleModel->where('id='.$id)->find();
        if( $result > 0 || $result ==0 ){
            $this->addLog("删除后台角色:".$res['name'],4);// 记录操作日志
            $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
        }else{
            $this->jumpInfo(array('info' => '操作失败请联系相关开发人员！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口', 'type' => 'error','status'=>'n'));
        }
    }
    /**
     * 返回多层栏目
     * @param $data 操作的数组
     * @param int $pid 一级PID的值
     * @param string $depth 指定输出深度
     * @param int $level 等级
     * @return array
     */
    public function channelLevel($pid=0,$depth=0,$level = 1)
    {
        $model=M('Res');
        $data = $model->where("is_delete=0 AND id <> 29 AND id <> 57 AND id <> 147 AND id <> 145 AND parentid=".$pid)->order('sort ASC')->select();
        $tree = Array();
        foreach($data as $k => $v)
        {
            if($depth!=0){
                if($level <= $depth){
                    $v['level'] = $level;
                    $v['data'] = $this->channelLevel($v['id'],$depth,$level+1);
                    $tree[] = $v;
                }
            }else{
                $v['level'] = $level;
                $v['data'] = $this->channelLevel($v['id'],$depth,$level+1);
                $tree[] = $v;
            }
        }
        return $tree;
    }

    //开启菜单
    public function aa(){
        $res=M('Res');
        $res->where('id=24')->save(array('is_hide'=>0));
    }
    //关闭
    public function bb(){
        $res=M('Res');
        $res->where('id=24')->save(array('is_hide'=>1));
    }

}
