<?php
namespace Home\Controller;
use Common\Controller\CommonController;
class RouteController extends CommonController
{
    /**
     * @describe 用户信息列表展示
     * @autchor eleven
     */
    public function index()
    {
        $this->display();
    }

    /**
     * @describe 用户数据列表
     * @autchor eleven
     * @return String JSON
     */
    public function getListData()
    {

        $RouteModel = M('Route');

        $where = (I('post.search') == '') ? '' : ' AND a.username LIKE "%'.I('post.search').'%"';//用户名

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? 20 :  I('limit');

        $data = $RouteModel->where($where)->limit($offset, $limit)->select();
        $num = $RouteModel->where($where)->count();

        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;


    }

    /**
     * @describe用户添加展示
     * @autchor eleven
     * @return HTML
     */
    public function add(){
        $roleModel = M('Role');
        $roleData = $roleModel
            ->field('id,name,depict')
            ->where('is_delete=0')
            ->select();
        $this->assign('roleData',$roleData);
        $this->display();
    }

    /**
     * @describe 用户修改展示
     * @author eleven
     * @return HTML
     */
    public function update(){
        $data=I();
        $this->assign('data',$data);
        $this->display();

    }

    /**
     * @describe 用户数据（添加/修改）
     * @autchor eleven
     */
    public function serve()
    {
        $data = I();
        $Route = M('Route');
        $Route->data($data)->add();
        $this->addLog("新增支付线路",3);// 记录操作日志
        $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));


    }

    //编辑
    public function userve(){
        $data = I();
        $Route = M('Route');
        $result=$Route->where('id='.$data['id'])->save($data);

            $this->addLog("编辑支付线路",3);// 记录操作日志
            $this->jumpInfo(array('info' => '操作成功！', 'msg' => ''));

    }

    //删除
    public function delete(){

         $id = I('id');

        $User = M('Route');

        $data = array('is_delete' => 1);

        $User->where('id=' . $id)->save($data); //根据条件更新记录
        $this->addLog("编辑支付线路",3);// 记录操作日志
        $this->jumpInfo(array('info' => '操作成功！', 'msg' => ''));

    }
    //启用
    public function enable(){
        $data=I();
        $Route = M('Route');
        if($data['is_used']==1){
            $result=$Route->where('type='.$data['type'].' and is_used=1')->find();
            if($result){
                $this->jumpInfo(array('info' => '该类型接口只允许开启一个！', 'msg' => '',"status"=>"n"));
            }
        }

        if($data['is_used']==0){
        $info="关闭";
        }else{
            $info="开启";
        }
        $Route->where('id='.$data['id'])->save($data); //根据条件更新记录
        $this->addLog($info."支付线路",3);// 记录操作日志
        $this->jumpInfo(array('info' => '操作成功！', 'msg' => '操作成功'));

    }
}