<?php
// +----------------------------------------------------------------------
// | OA
// +----------------------------------------------------------------------
// | Copyright (c) 2016-2017
// +----------------------------------------------------------------------
// | Author: 肖景
// +----------------------------------------------------------------------
namespace Home\Controller;

use Common\Controller\CommonController;

class SettingController extends CommonController
{

    /**
     * @describe 系统设置展示
     * @autchor
     */
    public function index()
    {
        $configModel=M('Config');
        $config=$configModel->select();
        foreach($config as $k=>$v){
            $array[$v['name']]=$v['value'];
        }
        $this->assign('data',$array);
        $this->display();
    }

    //参数修改保存方法
    public function serve()
    {
        $data = I();

        $ConfigModel = M('Config');

        $ConfigModel->where("name=".'"'.$data['name'].'"')->save(Array('value' => $data['value'])); // 根据条件更新记录

        $this->addLog("修改系统配置:".$data['name']."的值:".$data['value']."",3);// 记录操作日志
        $this->jumpInfo(array('info' => '修改操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));

    }


}

