<?php
namespace Home\Controller;
use Common\Controller\CommonController;
class SysUserController extends CommonController
{
    /**
     * @describe 用户信息列表展示
     * @autchor eleven
     */
    public function index()
    {
        $this->display();
    }

    /**
     * @describe 用户数据列表
     * @autchor eleven
     * @return String JSON
     */
    public function getListData()
    {

        $SysUserModel = M('SysUser');

        $where = (I('post.search') == '') ? '' : ' AND a.username LIKE "%'.I('post.search').'%"';//用户名

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');

        $data = $SysUserModel
            ->field("a.id,a.is_admin,a.is_technology,a.role_id,a.username,a.password,a.last_login_ip,a.is_delete,FROM_UNIXTIME(a.update_time,'%Y-%m-%d %H:%i:%S') AS update_time,b.name AS bname")
            ->alias('a')
            ->join('LEFT JOIN __ROLE__ b ON b.id = a.role_id ')
            ->where("a.is_technology=1 AND a.is_delete=0".$where)
            ->limit($offset, $limit)
            ->select();
        $num = $SysUserModel->where('is_delete=0')->count();

        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;


    }

    /**
     * @describe用户添加展示
     * @autchor eleven
     * @return HTML
     */
    public function add(){
        $roleModel = M('Role');
        $roleData = $roleModel
            ->field('id,name,depict')
            ->where('is_delete=0')
            ->select();
        $this->assign('roleData',$roleData);
        $this->display();
    }

    /**
     * @describe 用户修改展示
     * @author eleven
     * @return HTML
     */
    public function update(){

        //查询用户信息
        $id = I('id');

        $SysUser = M('SysUser');

        $roleModel = M('Role');

        $data = $SysUser
            ->field('a.*,b.res')
            ->alias('a')
            ->join('LEFT JOIN __ROLE__ b ON b.id = a.role_id ')
            ->where("a.id=".$id)
            ->find();

        $roleData = $roleModel
            ->field('id,name,depict')
            ->where('is_delete=0 AND id<>1 AND id<>2')
            ->select();

        $this->assign('id',$id);

        $this->assign('roleData',$roleData);

        $this->assign('data',$data);

        $this->display();

    }

    /**
     * @describe 用户数据（添加/修改）
     * @autchor eleven
     */
    public function serve()
    {
        $data = I();

        $action = I('action');

        if($action == 'update'){

            $id = I('id');

            $SysUser = M('SysUser');

//            $deleteData = array('id','password');
//
//            $data = delByValue($data,$deleteData,false);

            if($data['password'] != '' && $data['oldpwd'] !=''){
                $infro = $SysUser->where("password='".md5($data['oldpwd'])."'")->find();

                if(count($infro)>0){
                    $data['password'] = md5($data['password']);
                }else{
                    $this->jumpInfo(array('info' => '原始密码不正确！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口', 'type' => 'error','status'=>'n'));
                }
            }

            $result = $SysUser->where('id='.$id)->save($data); //根据条件更新记录

            $userData=$SysUser->where("id=".$id)->find();
            if( $result>0 || $result ===0 ){
                $this->addLog("修改后台用户:".$userData['username']."的信息",4);// 记录操作日志
                $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
            }else{
                $this->jumpInfo(array('info' => '操作失败请联系相关开发人员！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口', 'type' => 'error','status'=>'n'));
            }


        }elseif($action == 'add'){

            $data['username'] = $data['username']; //用户名

            $data['password'] = md5($data['password']); //密码

            $data['is_admin'] = 1;//是否是管理员

            $data['is_technology'] = 1;//是否技术

            $data['last_login_ip'] = get_client_ip();//注册ip

            $data['update_time'] = time();//最后一次编辑时间

            $data['create_time'] = time();//创建时间

            $data['source'] = 1;//来源

            $data['operator_id']=C('CONFIG_OPERATOR_CODE');

            $data['operator_name']=C('CONFIG_OPERATOR_NAME');
            $SysUser = M('SysUser');

            $SysUser->data($data)->add();
            $this->addLog("新增后台用户:".$data['username']."",4);// 记录操作日志
            $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));
        }

    }

    /**
     * @describe 检测用户名存在与否
     * @author eleven
     */
    public function inspectUsername(){

        $value = I('param');

        $SysUser = D('SysUser');

        $res = $SysUser->inspectUsername($value);

        if($res){
            $this->jumpInfo(array('info' => '用户名已被注册！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口', 'type' => 'error','status'=>'n'));
        }
        $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));

    }

    //删除
    public function delete(){

         $id = I('id');

        $User = M('SysUser');

        $data = array('is_delete' => 1);

        $User->where('id=' . $id)->save($data); //根据条件更新记录
        $this->addLog("删除后台用户:".I('username')."",4);// 记录操作日志
        $this->jumpInfo(array('info' => '操作成功！', 'msg' => '3秒钟后自动关闭，如果不想等待，请点击确定关闭窗口'));

    }
}