<?php
namespace Home\Controller;

use Common\Controller\CommonController;

class UserController extends CommonController{

    public function index(){
        //等级搜索下拉
        $gradeModel=M('Grade');
        $grade=$gradeModel->field('grade,grade_name')->select();
        $this->assign('grade',$grade);
        $this->display();
    }
    //列表数据
    public function listData(){

        $UserModel = M('User');

        $res = array();

        $offset = (I('offset') == null) ? 1 : I('offset');

        $limit = (I('offset') == null) ? C('PAGE_ING') :  I('limit');
        //搜索条件
        $s_time=strtotime(I('searchStatrDate'));
        $e_time=strtotime(I('searchEndDate')." 23:59:59");
        $where = (I('post.username') == '') ? '' : ' AND a.username LIKE "%'.I('post.username').'%"';//用户名
        $where.= (I('post.grade') =='') ?    '' : ' AND a.grade='.I('post.grade');//会员类型
        $where.= (I('post.searchEndDate')!=''&& I('post.searchStatrDate')!='') ? ' AND a.create_time >'.$s_time.' AND a.create_time <'.$e_time : ' ';//时间

        $data = $UserModel
            ->field('a.*,
                   grade.grade_name')
            ->alias('a')
            ->join('LEFT JOIN __GRADE__ as grade ON a.grade=grade.grade')
            ->where("a.is_delete=0".$where)
            ->limit($offset, $limit)
            ->order('id desc')
            ->select();
        $num = $UserModel
            ->field('a.*,
                   grade.grade_name')
            ->alias('a')
            ->join('LEFT JOIN __GRADE__ as grade ON a.grade=grade.grade')
            ->where("a.is_delete=0".$where)
            ->order('id desc')
            ->count();

        foreach($data as $k=>$v){
            $data[$k]['create_time']=date('Y-m-d H:i:s',$v['create_time']);
        }
        $res['rows'] = $data;

        $res['total'] = $num;

        echo json_encode($res, false);

        exit;
    }
    //新增页面
    public function add(){
        $this->display();
    }
    //编辑页面
    public function update(){
        $data=I();
        $this->assign('data',$data);
        $this->display();
    }
    //编辑逻辑
    public function updateServe(){
        $data=I();
        if(!empty($data['password'])){
            if(!preg_match('/^[a-zA-Z0-9]{6,15}$/',$data['password'])){
                $this->jumpInfo(array('info' => '密码只能位6-15位数字或者字母！', 'msg' => '', 'type' => 'error','status'=>'n'));
            }
            $userModel=M('User');
            $result=$userModel->where('username='.$data['username'])->save(array('password'=>MD5($data['password']),'update_time'=>time()));

            if($result){
                $this->addLog("修改:".I('username')."的密码",0);// 记录操作日志
                $this->jumpInfo(array('info' => '操作成功！'));
            }else{
                $this->jumpInfo(array('info' => '修改失败！'));
            }
        }else{
            $this->jumpInfo(array('info' => '操作成功！'));
        }


    }
    //用户详情页面
    public function see(){
        //user表
        $username=I('username');
        $userModel=M('user');
        $data = $userModel->field('a.*,
                   grade.grade_name')->alias('a')->join('LEFT JOIN __GRADE__ as grade ON a.grade=grade.grade')->where('a.username='.$username)->find();
        //bank表
        $userBankModel=M('UserBank');
        $bank=$userBankModel
            ->field('realname,ic,bank_name,account,countname,phone')
            ->where('username='.$username.' and type=1')
            ->find();
        /*********************************下级********************************************/
        //大掌柜
        $oneChild=$userModel->field('username,grade,id')->where(array('parent_id'=>$username))->select();
        foreach($oneChild as $k=>$v){
            $towChilds=$userModel->field('username,grade,id')->where(array('parent_id'=>$v['username']))->select();
            if($towChilds){
                $towChild[]=$towChilds;
            }
        }
        //2掌柜
        $towChild=$this->changedimension($towChild);
        //3掌柜
        foreach($towChild as $k=>$v){
            $threeChilds=$userModel->field('username,grade,id')->where(array('parent_id'=>$v['username']))->select();
            if($threeChilds){
                $threeChild[]=$threeChilds;
            }
        }
        $threeChild=$this->changedimension($threeChild);

        $interestModel=M('Interest');
        $gradeModel=M('Grade');
        foreach($oneChild as $k=>$v){
            $grade=$gradeModel->field('grade_name')->where('grade='.$v['grade'])->find();
            $interest=$interestModel->field('SUM(money) as money')->where('type=1 and child_id='.$v['id'])->select();
            $oneChild[$k]['fenrun']=$interest[0]['money'] ? $interest[0]['money']:0.00;
            $oneChild[$k]['grade_name']=$grade['grade_name'];
        }
        foreach($towChild as $k=>$v){
            $grade=$gradeModel->field('grade_name')->where('grade='.$v['grade'])->find();
            $interest=$interestModel->field('SUM(money) as money')->where('type=1 and child_id='.$v['id'])->select();
            $towChild[$k]['fenrun']=$interest[0]['money'] ? $interest[0]['money']:0.00;
            $towChild[$k]['grade_name']=$grade['grade_name'];
        }
        foreach($threeChild as $k=>$v){
            $grade=$gradeModel->field('grade_name')->where('grade='.$v['grade'])->find();
            $interest=$interestModel->field('SUM(money) as money')->where('type=1 and child_id='.$v['id'])->select();
            $threeChild[$k]['fenrun']=$interest[0]['money'] ? $interest[0]['money']:0.00;
            $threeChild[$k]['grade_name']=$grade['grade_name'];
        }

        $data=array_merge($data,$bank);

        $this->assign('one',$oneChild);
        $this->assign('two',$towChild);
        $this->assign('three',$threeChild);
        $this->assign('data',$data);
        $this->display();
    }

     //银行卡信息
    public function bank(){
        $id=intval(I('post.id'));
        $bankModel=M('UserBank');
        $bank=$bankModel->where('id='.$id)->find();
        $this->assign('data',$bank);
        $this->display();
    }
    //支付信用卡信息
    public function defrayrc(){
        $id=intval(I('post.id'));
        $rcModel=M('Defrayrc');
        $rc=$rcModel->where('id='.$id)->find();
        $this->assign('data',$rc);
        $this->display();
    }
    //还款信用卡信息
    public function rc(){
        $id=intval(I('post.id'));
        $rcModel=M('Rc');
        $rc=$rcModel->where('id='.$id)->find();
        $this->assign('data',$rc);
        $this->display();
    }
    //登录状态开启关闭
    public function enable(){
        $data=I();
        $userModel=M('User');
        $result=$userModel->save($data);
        if($data['enable']==0){
            $info="开启";
        }
        if($data['enable']==1){
            $info="关闭";
        }
        if($result){
            $this->addLog("$info".$data['user']."的登录",0);// 记录操作日志
            $this->jumpInfo(array('info' => '操作成功！'));
        }else{
            $this->jumpInfo(array('info' => '操作失败！'));
        }

    }
}