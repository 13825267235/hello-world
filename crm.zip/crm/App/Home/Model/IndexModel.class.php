<?php
namespace Home\Model;

use Think\Model;

class IndexModel extends Model{
    /**
     * @param array $parameter 动态传参数
     */
    public function data($parameter = array())
    {
        //字段块
        $parameter['field'] = isset($parameter['field']) ? ' ' . $parameter['field'] . ' ' : '*';
        //表块
        $parameter['table'] = isset($parameter['table']) ? ' ' . $parameter['table'] . ' ' : ' '.$this->getTableName().' ';
        //条件块
        $parameter['where'] = isset($parameter['where']) ? ' ' . $parameter['where'] . ' ' : '';
        //链表块
        $parameter['InnerLeftRightFull'] = isset($parameter['InnerLeftRightFull']) ? ' ' . $parameter['InnerLeftRightFull'] . ' ' : '';
        //分页块
        $parameter['limit'] = isset($parameter['limit']) ? ' ' . $parameter['limit'] . ' ' : '';
        // 分组/排序块
        $parameter['groupORorder'] = isset($parameter['groupORorder']) ? ' ' . $parameter['groupORorder'] . ' ' : '';
        //拼接sql语句
        $sql = "SELECT " . $parameter['field'] . " FROM " . $parameter['table'] . " AS " . $parameter['table'] . $parameter['InnerLeftRightFull'] . " WHERE 1=1 " . $parameter['where'] . $parameter['groupORorder'] . $parameter['limit'];

        return $this->query($sql);
    }

    public function listData($parameter = array())
    {

        //表块
        $parameter['table'] = isset($parameter['table']) ? ' ' . $parameter['table'] . ' ' :  ' '.$this->getTableName(). ' ';

        //获取分页数据
        $listData = $this->data($parameter);

        //删除指定元素
        $parameter = delByValue($parameter, array('limit'), false);

        //获取数据总和
        $parameter['field'] .= isset($parameter['field']) ? ',COUNT(' . $parameter['table'] . '.id) AS nums ' : 'COUNT(' . $parameter['table'] . '.id) AS nums ';

        $numsData = $this->data($parameter);

        $res = array('total' => $numsData[0]['nums'], 'rows' => $listData);

        return $res;

    }

    /**
     * 获取分页数据
     * @param  subject  $model  model对象
     * @param  array    $map    where条件
     * @param  string   $order  排序规则
     * @param  integer  $limit  每页数量
     * @param  integer  $field  $field
     * @return array            分页数据
     */
    public function getPage($model,$where='1=1',$order='',$limit=10,$page=1,$field=''){
        $count = $model->where($where)->count();
        $page = new \Org\Util\AjaxPage($count,$limit,$page);// 实例化分页类 传入总记录数和每页显示的记录数
        // 获取分页数据
        if (empty($field)) {
            $list=$model->where($where)->order($order)->limit($page->firstRow.','.$page->listRows)->select();
        }else{
            $list=$model->field($field) ->where($where)->order($order)->limit($page->firstRow.','.$page->listRows)->select();
        }
        $data=array('data'=>$list,'page'=>$page->show());
        return $data;
    }

}