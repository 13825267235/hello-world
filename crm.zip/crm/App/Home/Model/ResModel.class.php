<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/3/25 0025
 * Time: 上午 7:25
 */
namespace Home\Model;

class ResModel extends IndexModel
{

    /**
     * @describe 全部菜单数据排序
     * @param int $parentid
     * @param array $list
     * @param string $format
     * @return array
     */
    public function recursionAll($parentid=0,&$list=Array(),$format='|-- '){
        $data = $this->where("is_delete=0 AND id <> 29 AND parentid=".$parentid)->order('sort ASC')->select();
        foreach ($data as $k => $v) {
            $v ['name'] = ($parentid == 0) ?  $v ['name'] : $format. $v ['name'];
            array_push($list,$v);
            $childData = $this->where("is_delete=0 AND id <> 29 AND parentid=" . $v['id'])->order('sort ASC')->select();
            foreach ($childData as $kA => $vA) {
                $vA ['name'] = $format. $vA ['name'];
                array_push($list,$vA);
                $this->recursionAll($vA['id'], $list, '|-- ' . $format);
            }
        }
        return $list;
    }

    /**
     * 返回多层栏目
     * @param $data 操作的数组
     * @param int $pid 一级PID的值
     * @param string $depth 指定输出深度
     * @param int $level 等级
     * @return array
     */
    public function channelLevel($pid=0,$depth=0,$level = 1)
    {
        $data = $this->where("is_delete=0 AND id <> 29 AND id <> 57 AND id <> 147 AND id <> 145 AND parentid=".$pid)->order('sort ASC')->select();
        $tree = Array();
        foreach($data as $k => $v)
        {
            if($depth!=0){
                if($level <= $depth){
                    $v['level'] = $level;
                    $v['data'] = $this->channelLevel($v['id'],$depth,$level+1);
                    $tree[] = $v;
                }
            }else{
                $v['level'] = $level;
                $v['data'] = $this->channelLevel($v['id'],$depth,$level+1);
                $tree[] = $v;
            }
        }
        return $tree;
    }

    /**
     * 返回多层栏目
     * @param $data 操作的数组
     * @param int $pid 一级PID的值
     * @param string $depth 指定输出深度
     * @param int $level 等级
     * @return array
     */
    public function channelLevelt($pid=0,$depth=0,$level = 1)
    {
        $data = $this->where("is_delete=0 AND parentid=".$pid)->order('sort ASC')->select();
        $tree = Array();
        foreach($data as $k => $v)
        {
            if($depth!=0){
                if($level <= $depth){
                    $v['level'] = $level;
                    $v['data'] = $this->channelLevelt($v['id'],$depth,$level+1);
                    $tree[] = $v;
                }
            }else{
                $v['level'] = $level;
                $v['data'] = $this->channelLevelt($v['id'],$depth,$level+1);
                $tree[] = $v;
            }
        }
        return $tree;
    }

}