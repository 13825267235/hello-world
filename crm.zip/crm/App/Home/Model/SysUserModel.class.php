<?php
namespace Home\Model;


class SysUserModel extends IndexModel{
    /**
     * @describe 检查用户名是否存在
     * @author eleven
     * @param String $username 用户名
     */
    public function inspectUsername($username){
        $count = $this->where('is_delete=0 AND username="'.$username.'"')->count();
        return ($count>0) ? true : false;
    }

    /**
     * @deccirbe 检测登录是否成功
     * @author eleven
     * @param String  $username 账号
     * @param String $password 密码
     */
    public function login($username,$password){
        $res = array('data'=>array(),'status'=>true,'message'=>'');
        if($this->inspectUsername($username)){
            $data = $this->where("is_delete=0 AND username='".$username."' AND  password='".$password."'" )->find();

            if(count($data)>0){

                $roleModel = M('Role');
                $auth= $roleModel->where("id=".$data['role_id'])->field("res")->find();
                $data['res'] = unserialize($auth['res']); // 对应的角色权限
                /*****************************更新登录时间IP状态*********************************/
                $this->where('id='.$data['id'])->save(array(
                    'last_login_ip'=>get_client_ip(),
                    'update_time'=>time()
                ));
                /*****************************记录登录状态***************************************/
//                $onLineModel = M('OnLine');
//                $addid = $onLineModel->add(array_merge(array(
//                    'uid'=>$data['id'],
//                    'is_backstage'=>1,
//                    'username'=>$data['username'],
//                    'session_key'=>session_id(),
//                    'login_time'=>time(),
//                    'access_time'=>time(),
//                    'create_time'=>time(),
//                    'login_ip'=>get_client_ip(),
//                    'operator_id'=>C('CONFIG_OPERATOR_CODE'),
//                    'operator_name'=>C('CONFIG_OPERATOR_NAME')
//                ), getBrowser()));
//                //把人踢下线
//                $onLineModel->where("id<".$addid." AND uid='".$data['id']."'")->save(Array(
//                    "is_on_line" =>0,
//                    "state" =>1,
//                ));
//                $data['onLineid'] = $addid;
                /*****************************记录登录状态***************************************/
                $res['data'] = $data;
            }else{
                $res['status']  = false;
                $res['message'] = '您输入的密码不正确！';
            }
        }else{
            $res['status']  = false;
            $res['message'] = '用户不存在';
        }
        return $res;
    }

}