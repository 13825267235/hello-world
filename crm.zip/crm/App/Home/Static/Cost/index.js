$(function(){

    var listTable       = $('#tb_departments'); //表格对象
    var selectForm      = $("#table_form"); //筛选form对象

    var ListDataUrl  = '/'+model_name+'/Cost/listData'; //列表数据请求地址
    var opUrl        = '/'+model_name+'/Cost/op'; //消费地址

    var seeUrl       = '/'+model_name+'/User/see';  //用户详情
    var defaryUrl      = '/'+model_name+'/User/rc'; //信用卡详情
    var accountUrl      = '/'+model_name+'/Payrc/account'; //流水记录

    /**
     * @describe 请求服务器数据时，你可以通过重写参数的方式添加一些额外的参数，例如 toolbar 中的参数 如果 queryParamsType = 'limit' ,返回参数必须包含 limit, offset, search, sort, order 否则, 需要包含:
     * pageSize, pageNumber, searchText, sortName, sortOrder. 返回false将会终止请求
     * @param params
     * @returns {*}
     */
    function queryParams(params) {
        var form = selectForm.serializeArray();
        $.each(form, function () {
            if (params[this.name] !== undefined) {
                if (!params[this.name].push) {
                    params[this.name] = [params[this.name]];
                }
                params[this.name].push(this.value || '');
            } else {
                params[this.name] = this.value || '';
            }
        });
        return params;
    }

    /**
     * @describe  操作按钮渲染
     * @param value
     * @param row
     * @param index
     */
    function operateFormatter(value, row, index){
        var operationHtml = [];
        /************************************************操作按钮渲染********************************************************/
        if(row.status!=1){
            if(App.in_array(identificationJson,'Cost_op')){
                operationHtml.push('<button class="btn btn-sm green uptate"><i class="fa fa-"></i> <span class="visible-lg-inline">手动消费</span></button>');
            }
        }

        return operationHtml.join('');
    }

    /**
     * @describe 时间选择筛选
     * @author eleven
     */
    $('.fui-date').datetimepicker({
        format: "YYYY-MM-DD",
        locale: 'zh-cn',
        maxDate: false,
        minDate: false,
        showClear: true,
        showTodayButton: true,
        sideBySide: true
    });

    /**
     * @describe 修改操作
     * @param e
     * @param value
     * @param row
     * @param index
     */
    function op(e, value, row, index){
        App.openDialog({requesTurl:opUrl,passData:row,title:'<i class="fa fa-edit">手动消费</i>'});
    }

    /**
     * @describe 操作栏里的按钮事件
     * @type {{[click .like]: Window.operateEvents.'click .like', [click .uptate]: Window.operateEvents.'click .uptate', [click .remove]: Window.operateEvents.'click .remove'}}
     */
    window.operateEvents = {
        'click .uptate': op
    };

    /**
     * @describe 表格数据加载成功完成以后
     * @param data 当前页加载的数据
     */
    function onLoadSuccess(data){
        //listTable.bootstrapTable('refresh');//刷新
    }

    /**
     * @describe 搜索绑定
     */
    $("#SearchButt").on('click',function(){
        listTable.bootstrapTable('refresh');//刷新
    });
    //信用卡详情
    listTable.on('click','.defaryInfo',function(){
        var id=$(this).data("id");
        App.openDialog({requesTurl:defaryUrl,passData:{id:id}});
    });
    //用户详情绑定
    listTable.on('click','.userInfo',function(){
        var id=$(this).data("id");
        App.openDialog({requesTurl:seeUrl,passData:{username:id}});
    });
    //用户详情绑定
    listTable.on('click','.accountInfo',function(){
        var id=$(this).data("id");
        App.openDialog({requesTurl:accountUrl,passData:{id:id}});
    });
    //列表展示
    listTable.bootstrapTable({
        url: ListDataUrl,           //请求后台的URL（*）
        //            dataField: "rows",                //服务端返回数据键值，就是说返回的json数据里的数据必须放在rows里(默认是rows)，分页时使用总记录数的键值为total
        method: 'post',                       //请求方式（*）
        undefinedText:'',                   //当数据为 undefined 时显示的字符
        //toolbar: '#toolbar',                  //工具按钮用哪个容器
        striped: true,                        //是否显示行间隔色
        cache: false,                         //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination: true,                     //是否显示分页（*）
        //sortable: false,                     //是否启用排序
        //sortOrder: "asc",                     //排序方式
        queryParams: queryParams,              //传递参数（*）
        sidePagination: "server",           //分页方式：client客户端分页，server服务端分页（*）
        contentType: "application/x-www-form-urlencoded", //请求数据内容格式 默认是 application/json 自己根据格式自行服务端处理
        pageNumber:1,                         //初始化加载第一页，默认第一页
        pageSize: 10,                         //每页的记录行数（*）
        minimumCountColumns: 2,             //最少允许的列数
        strictSearch: true,
        clickToSelect: true,                 //是否启用点击选中行
        uniqueId: "id",                      //每一行的唯一标识，一般为主键列
        columns: [
            {
                field: 'username',
                title: '用户名',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
                formatter: function (value, row, index) {
                    return '<a class="open-dialog userInfo"  title="查看详情" data-id="'+ row.username +'">' +
                        '<span class="text-danger">' + row.username + '</span>' +
                        '</a>'

                }
            },
            {
                field: 'plan_order',
                title: '单号',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
                formatter: function (value, row, index) {
                    return '<a class="open-dark accountInfo"  title="查看详情" data-id="'+ row.payrc_id +'">' +
                        '<span class="text">' + row.plan_order + '</span>' +
                        '</a>'

                }
            },
            {
                field: 'pay_money',
                title: '贷款金额',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
            },
            {
                field: 'pay_mub',
                title: '还款笔数',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
            },
            {
                field: 'money',
                title: '还款金额',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
            },
            {
                field: 'times',
                title: '期数',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
            },
            {
                field: 'pay_order',
                title: '流水单号',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
            },

            {
                field: 'status',
                title: '状态',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
                formatter: function (value, row, index) {
                    if(value==0){
                        return  '<span class="caption-subject font-yellow-haze bold uppercase">还款中</span>';
                    }else if(value==1){
                        return '<span class="caption-subject font-green-sharp bold uppercase">已完成</span>';
                    }else if(value==2){
                        return '<span class="caption-subject font-red-sunglo bold uppercase">失败</span>';
                    }
                }
            },
            {
                field: 'pay_time',
                title: '还款时间',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
                formatter: function (value, row, index) {
                    if(value==0){
                        return  '';
                    }else{
                        return  value;
                    }
                }
            },
            {
                field: 'create_time',
                title: '申请时间',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
            },
            {
                field: 'operation',
                title: '操作',
                align : 'center', //水平居中
                valign: 'middle', //垂直居中
                events: operateEvents,
                formatter :operateFormatter
            }
        ]

    });

    /******************************时间筛选代码块***************************************/
    /**
     * @describe 今天点击事件
     */
    $('#today').click(function(){
        var _statrDateTime = moment().format('YYYY-MM-DD');
        var _endDateTime = moment().format('YYYY-MM-DD');
        screenTime(_statrDateTime,_endDateTime);
    });

    /**
     * @describe 昨日点击事件
     */
    $('#yesterday').click(function(){
        var _statrDateTime = moment().subtract(1, 'days').format('YYYY-MM-DD');
        var _endDateTime = moment().subtract(1, 'days').format('YYYY-MM-DD');
        screenTime(_statrDateTime,_endDateTime);
    });

    /**
     * @describe 本周点击事件
     */
    $('#thisWeek').click(function(){
        var _statrDateTime = moment().startOf('week').format('YYYY-MM-DD');
        var _endDateTime = moment().endOf('week').format('YYYY-MM-DD');
        screenTime(_statrDateTime,_endDateTime);
    });

    /**
     * @describe 上周点击事件
     */
    $('#lastWeek').click(function(){
        var _statrDateTime = moment().startOf('week').subtract(1, 'week').format('YYYY-MM-DD');
        var _endDateTime = moment().endOf('week').subtract(1, 'week').format('YYYY-MM-DD');
        screenTime(_statrDateTime,_endDateTime);
    });

    /**
     * @describe 本月点击事件
     */
    $('#thisMonth').click(function(){
        var _statrDateTime = moment().startOf('month').format('YYYY-MM-DD');
        var _endDateTime = moment().endOf('month').format('YYYY-MM-DD');
        screenTime(_statrDateTime,_endDateTime);
    });

    /**
     * @describe 上月点击事件
     */
    $('#lastMonth').click(function(){
        var _statrDateTime = moment().startOf('month').subtract(1, 'months').format('YYYY-MM-DD');
        var _endDateTime = moment().endOf('month').subtract(1, 'months').format('YYYY-MM-DD');
        screenTime(_statrDateTime,_endDateTime);
    });

    /**
     * @describe 全部点击事件
     */
    $('#whole').click(function(){
        $("#uid").val("");
        selectForm[0].reset();
        listTable.bootstrapTable('selectPage',1);//跳到指定行
    });
    /**
     * @describe 时间筛选
     * @param startDateTime
     * @param endDateTime
     */
    function screenTime(startDateTime,endDateTime){
        $('#startTime').val(startDateTime);//本周
        $('#endTime').val(endDateTime);
        listTable.bootstrapTable('selectPage',1);//刷新
    }
    /******************************时间筛选代码块***************************************/

});
