/**
 * Created by Administrator on 2018/1/3.
 */
$(function(){

    //表单检测
    App.popupFrom(
        {
            from: $("#add_form"),
            validCallback:function(result){
                if(result.status == 'y'){
                    layer.closeAll();
                    $('.selectDefualt').trigger('click'); //刷新
                }
                //关闭窗口
                swal({title: result.info, text: result.msg, type: result.type,timer: result.timer}, function () {
                });
            }
        }
    );




});