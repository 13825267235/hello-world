/**
 * Created by Administrator on 2017/10/15 0015.
 */
$(function(){

  //退出登陆
    $('#logout').on('click',function(){
        App.loguotAction();
    });
});