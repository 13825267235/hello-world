
$(function(){

   // 表单检测
    App.popupFrom(
        {
            from:$("#login-form"),
            validCallback:function(data){
                if(data.status == 'n'){
                    $('#vcode_image').trigger('click');
                    layer.msg(data.info);
                }else if(data.status == 'y'){
                    window.location.href = data.url;
                }
                return false;
            }
        }
    );


});/**
 * Created by Administrator on 2017/10/13 0013.
 */
