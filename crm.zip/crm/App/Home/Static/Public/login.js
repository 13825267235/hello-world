$(function(){

    var  _from = $("#login-form");

    //表单检测
    App.popupFrom(
        {
            from:_from,
            validCallback:function(data){
                if(data.status == 'n'){
                    $('#vcode_image').trigger('click');
                    layer.msg(data.info);
                }else if(data.status == 'y'){
                    window.location.href = data.url;
                }
                return false;
            }
        }
    );

    //刷新验证码
    $('#vcode_image').on('click',function(){
        $(this).attr('src',verify);
    });

    $.backstretch(backstretchArr, {
            fade: 1000,
            duration: 800
        }
    );


});/**
 * Created by Administrator on 2017/10/13 0013.
 */
