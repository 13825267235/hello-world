/**
 * Created by Administrator on 2018/1/2.
 */
$(function () {

    var listTable = $('#tb_Push_departments'); //表格对象

    var operationHtml = [];

    $("#sendoutss").on("click",function(){
        var data = {};
        data.type = $("#pushmode").val();
        if(data.type == 2){
            var zdhyArr = $("#user_data").select2('val');
            if(zdhyArr== null){
                layer.msg('请选择会员');
                return false;
            }
            data.zdhysj = zdhyArr;
        }
        data.zdfc = $("#gradesss").val();
        data.fs = $(".types:checked").val();
        data.titles=$("#titles").val();
        data.contents = $("#contents").val();
        data.overdue_time = $("#overdue_time").val();
        $.post('/'+model_name+'/Push/sendoutss',data,function(res){
            layer.msg(res.msg);
            listTable.bootstrapTable('refresh');//刷新
        },'json');
    });

    $("#pushmode").change(function(){
        var type = $(this).val();
        if(type == 1){
            $(".modetype").hide();
        }else if(type == 2){
            $(".modetypezdhy").show();
            $(".modetypezdfc").hide();
            setTimeout(function () {
                select2zdhy();
            }, 500);
        }else if(type == 3){
            $(".modetypezdfc").show();
            $(".modetypezdhy").hide();
        }
    });

    function select2zdhy(){
        $("#user_data").select2({
            placeholder:'请选择，支持模糊匹配',//默认文字提示
            language: "zh-CN",//汉化
            tags: false,//允许手动添加
            ajax: {
                url: "/"+model_name+"/Push/userList",
                dataType: 'json',
                delay: 250,
                data: function (params) {
                    return {
                        q: params.term,
                    };
                },
                processResults: function (data) {
                    var items= data;
                    var itemList = [];
                    for(var i =0; i < items.length; i++){
                        itemList.push({id: items[i].id+'.'+items[i].username, text: items[i].username});
                    }
                    return {
                        results: itemList
                    };
                },
                cache: true
            },
            // escapeMarkup: function (markup) { return markup; },
            // minimumInputLength: 1,
            // templateResult: formatRepo,
            // templateSelection: formatRepoSelection
        });
        /*获取id： $(".downList2").select2("data")[0].id;
         获取text： $(".downList2").select2("data")[0].text;
         也可使用一下方式取值：
         $(".downList2").val();
         $(".downList2").select2('val');*/
    }

    $("[data-plugin-type='icheck']").iCheck({
        checkboxClass: 'icheckbox_square-green',
        radioClass: 'iradio_square-blue',
        increaseArea: '20%' // optional
    });

    window.operateEvents = {
        'click .remove': deletes,
    };

    if(App.in_array(identificationJson,'Push_delete')){
        operationHtml.push('<button class="btn btn-sm green remove"><i class="fa fa-trash-o"></i> <span class="visible-lg-inline">删除</span></button>');
    }

    /**
     * @describe  操作按钮渲染
     * @param value
     * @param row
     * @param index
     */
    function operateFormatter(value, row, index){
        return operationHtml.join('');
    }

    /**
     * @describe 删除操作
     * @param e
     * @param value
     * @param row
     * @param index
     */
    function deletes(e, value, row, index){
        swal({
            title: "是否真的该消息",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "删除",
            closeOnConfirm: false
        }, function(){
            $.post('/'+model_name+'/Push/delete',row,function(result){
                listTable.bootstrapTable('refresh');//刷新
                swal({title: result.info, text: result.msg, type: result.type,timer: result.timer}, function () {});
            },'json');
        });
    }

    $('.fui-date-mm').datetimepicker({
        format: "mm",
        locale: 'zh-cn',
        maxDate: false,
        minDate: false,
        showClear: true,
        showTodayButton: true,
        sideBySide: true
    });

    /**
     * @describe 列表展示
     * @author xiaojing
     */
    listTable.bootstrapTable({
        url: '/'+model_name+'/Push/getData',           //请求后台的URL（*）
        //            dataField: "rows",                //服务端返回数据键值，就是说返回的json数据里的数据必须放在rows里(默认是rows)，分页时使用总记录数的键值为total
        method: 'post',                       //请求方式（*）
        contentType: "application/x-www-form-urlencoded", //请求数据内容格式 默认是 application/json 自己根据格式自行服务端处理
        undefinedText: '',                   //当数据为 undefined 时显示的字符
        toolbar: '#toolbar',                  //工具按钮用哪个容器
        striped: true,                        //是否显示行间隔色
        cache: false,                         //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination: true,                     //是否显示分页（*）
        sortable: false,                     //是否启用排序
        // sortOrder: "create_time asc", //排序方式
        // queryParams: queryParams,              //传递参数（*）
        /************************分页相关**********************************/
        sidePagination: "server",           //分页方式：client客户端分页，server服务端分页（*）
        onlyInfoPagination : false,         //设置为 true 只显示总数据数，而不显示分页按钮。需要 pagination='True'
        showPaginationSwitch : false,       //是否显示 数据条数选择框
        pageNumber: 1,                        //初始化加载第一页，默认第一页
        pageSize: 10,                         //每页的记录行数（*）
        /************************工具按钮相关**********************************/
        showColumns: true,                   //是否显示所有的列
        minimumCountColumns: 2,             //最少允许的列数
        showRefresh: true,                   // 开启刷新功能
        columns: [
            //{
            //    field: 'cusnername',
            //    title: '发送对象',
            //    inputclass: 'form-control',
            //    align: 'center', //水平居中s
            //    valign: 'middle',//垂直居中
            //},
            {
                field: 'titles',
                title: '标题',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
            },
            {
                field: 'contents',
                title: '内容',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
                cellStyle : function (value, row, index) {
                    return {
                        css: {
                            "max-width": "200px",
                            "word-wrap": "break-word",
                            "word-break": "normal",
                            "overflow": "hidden",
                            "white-space": "nowrap",
                            "text-overflow": "ellipsis"
                        }
                    };
                },
                formatter: function (value, row, index) {
                     return '<span title="'+value+'">'+App.cutString(value,50)+'</span>';
                }
            },
            {
                field: 'type',
                title: '消息类型',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
                formatter: function (value, row, index) {
                    if (value == 0) {
                        return '站内消息';
                    }else if(value == 1){
                        return '弹窗消息';
                    }
                }
            },
            {
                field: 'username',
                title: '接收对象',
                align: 'center', //水平居中
                valign: 'middle', //垂直居中
                cellStyle : function (value, row, index) {
                    return {
                        css: {
                            "word-break":"break-all"
                        }
                    };
                },
                formatter: function (value, row, index) {
                    if (row.way == 1) {
                        return '全部会员';
                    }else{
                        return value
                    }

                }
            },
            {
                field: 'create_time',
                title: '发送时间',
                align: 'center', //水平居中
                valign: 'middle', //垂直居中
            },
            {
                field: 'operation',
                title: '操作',
                align : 'center', //水平居中
                valign: 'middle', //垂直居中
                events: operateEvents,
                formatter :operateFormatter
            }
        ]
    });

})