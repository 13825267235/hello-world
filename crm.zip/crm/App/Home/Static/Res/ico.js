/**
 * Created by Administrator on 2017/6/3 0003.
 */
$(function () {

    /**
     * @describe 点击选择图标
     * @author eleven
     */
    $('.user-icon-btn').on('click',function(){
        //设置选择后 出现打钩
        $('#iconCheck').remove();
        $(this).append('<span class="badge badge-success fa fa-check" id="iconCheck"></span>');
        //设置选择后的样式
        $('.user-icon-btn').removeAttr("style");
        $(this).css({
            "border": "1px solid #d9ead8",
            "background-color":"#92bffa",
            "font-size":"30px"
        });
        $('#ico_key').val($(this).find('i').attr('class'));
    });

    /**
     * @describe  点击保存
     * @author eleven
     */
    $('#icoServe').on('click',function(){
        $('#add_ico').removeClass();
        $('#add_ico').addClass($('#ico_key').val());
        $('#ico_add_submenu').val($('#ico_key').val());
        $('#icoClose').trigger('click'); //模拟关闭当前窗口
    });

    /**
     * @describe  点击关闭窗口
     * @author eleven
     */
    $('#icoClose').on('click',function(){
        //模拟关闭当前窗口
        $(this)
            .parents('.layui-layer-content')
            .next('.layui-layer-setwin')
            .children('.layui-layer-close').trigger("click");
    });

    /**
     * @describe 默认加载
     * @author eleven
     */
    if(resICO !=''){
        var resICOArr = resICO.split(' ');
        var parentss = $('.icoSelect .'+resICOArr[1]).parent();
        parentss.append('<span class="badge badge-success fa fa-check" id="iconCheck"></span>');
        parentss.css({
            "border": "1px solid #d9ead8",
            "background-color":"#92bffa",
            "font-size":"30px"
        });
    }

})