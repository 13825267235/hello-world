/**
 * Created by Administrator on 2017/6/3 0003.
 */
$(function () {

    var listTable       = $('#tb_res_departments'); //表格对象
    var selectForm      = $("#table_res_form"); //筛选form对象


    /**
     * @describe 请求服务器数据时，你可以通过重写参数的方式添加一些额外的参数，例如 toolbar 中的参数 如果 queryParamsType = 'limit' ,返回参数必须包含 limit, offset, search, sort, order 否则, 需要包含:
     * pageSize, pageNumber, searchText, sortName, sortOrder. 返回false将会终止请求
     * @param params
     * @returns {*}
     */
    function queryParams(params) {
        var form = selectForm.serializeArray();
        $.each(form, function () {
            if (params[this.name] !== undefined) {
                if (!params[this.name].push) {
                    params[this.name] = [params[this.name]];
                }
                params[this.name].push(this.value || '');
            } else {
                params[this.name] = this.value || '';
            }
        });
        return params;
    }

    /**
     * @describe 操作栏里的按钮事件
     * @type {{[click .like]: Window.operateEvents.'click .like', [click .uptate]: Window.operateEvents.'click .uptate', [click .remove]: Window.operateEvents.'click .remove'}}
     */
    window.operateEvents = {
        'click .res_add_submenu': res_add_submenu,
        'click .res_edit': res_edit,
        'click .res_delete': res_delete,
    };

    /**
     * @describe  操作按钮渲染
     * @param value
     * @param row
     * @param index
     */
    function operateFormatter(value, row, index){
        return [
            '<button class="btn btn-sm green datas res_add_submenu"><i class="fa fa-plus"></i><span class="visible-lg-inline">添加子菜单</span></button>',
            '<button class="btn btn-sm green datas res_edit"><i class="fa fa-edit"></i><span class="visible-lg-inline">编辑</span></button>',
            '<button class="btn btn-sm green datasr res_delete"><i class="fa fa-trash-"></i><span class="visible-lg-inline">删除</span></button>',
        ].join('');
    }

    //添加按钮事件绑定
    $("#RES_ADD").on('click',function(){
        App.openDialog({requesTurl:'/'+model_name+'/Res/add'});
    });
    /**
     * @describe 添加子菜单
     * @param e
     * @param value
     * @param row
     * @param index
     */
    function res_add_submenu(e, value, row, index){
        App.openDialog({requesTurl:'/'+model_name+'/Res/addSubmenu',passData:row,title:'<i class="fa fa-edit"></i> '});
    }
    /**
     * @describe 修改操作
     * @param e
     * @param value
     * @param row
     * @param index
     */
    function res_edit(e, value, row, index){
        App.openDialog({requesTurl:'/'+model_name+'/Res/edit',passData:row,title:'<i class="fa fa-edit"></i> '+row.name});
    }

    /**
     * @describe 删除操作
     * @param e
     * @param value
     * @param row
     * @param index
     */
    function res_delete(e, value, row, index){
        swal({
            title: "是否真的执行删除操作",
            text: "",
            type: "warning",
            showCancelButton: true,
            confirmButtonColor: "#DD6B55",
            confirmButtonText: "删除",
            closeOnConfirm: false
        }, function () {
            $.post('/'+model_name+'/Res/delete',row,function(result){
                if(result.status == 'n'){
                    swal({title: result.info, text: result.msg, type: result.type,timer: result.timer}, function () {});
                }else{
                    listTable.bootstrapTable('refresh');//刷新
                    swal({title: result.info, text: result.msg, type: result.type,timer: result.timer}, function () {});
                }
            },'json');
        });
    }

    //列表展示
    listTable.bootstrapTable({
        url: '/'+model_name+'/Res/listData',           //请求后台的URL（*）
        //            dataField: "rows",                //服务端返回数据键值，就是说返回的json数据里的数据必须放在rows里(默认是rows)，分页时使用总记录数的键值为total
        method: 'post',                       //请求方式（*）
        undefinedText:'',                   //当数据为 undefined 时显示的字符
        //toolbar: '#toolbar',                  //工具按钮用哪个容器
        striped: true,                        //是否显示行间隔色
        cache: false,                         //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination: true,                     //是否显示分页（*）
        //sortable: false,                     //是否启用排序
        //sortOrder: "asc",                     //排序方式
        queryParams: queryParams,              //传递参数（*）
        sidePagination: "server",           //分页方式：client客户端分页，server服务端分页（*）
        contentType: "application/x-www-form-urlencoded", //请求数据内容格式 默认是 application/json 自己根据格式自行服务端处理
        pageNumber:1,                         //初始化加载第一页，默认第一页
        pageSize: 100,                         //每页的记录行数（*）
        minimumCountColumns: 2,             //最少允许的列数
        strictSearch: true,
        clickToSelect: true,                 //是否启用点击选中行
        uniqueId: "id",                      //每一行的唯一标识，一般为主键列
        columns: [
            {
                field: 'sort',
                title: '排序',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
            },
            {
                field: 'name',
                title: '菜单名称',
                inputclass: 'form-control',
                align: 'left', //水平居中
                valign: 'middle',//垂直居中
            },
            {
                field: 'ico',
                title: '资源图标',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
                formatter:function(value,row,index){
                    return '<i class="'+value+'"></i>';
                }
            },
            {
                field: 'identifying',
                title: '权限标识',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
            },
            {
                field: 'depict',
                title: '菜单说明',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
            },
            {
                field: 'url',
                title: '地址/路径',
                inputclass: 'form-control',
                align: 'center', //水平居中
                valign: 'middle',//垂直居中
            },
            {
                field: 'operation',
                title: '操作',
                align : 'center', //水平居中
                valign: 'middle', //垂直居中
                events: operateEvents,
                formatter :operateFormatter
            }
        ]

    });
    resTable = null;
    resTable = listTable
})