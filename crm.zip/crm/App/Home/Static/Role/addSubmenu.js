/**
 * Created by Administrator on 2017/6/3 0003.
 */
$(function () {

    var _from = $('#res_add_submenu_form'); // 表单

    var _serve_batt= $("#addServe"); // 保存按钮

    var _close_batt = $("#addClose"); // 关闭窗口按钮

    /**
     * @describe  表单检测
     * @author eleven
     */
    App.popupFrom(
        {
            from:_from,
            validCallback:function(result){
                if(result.status == 'y'){
                    _close_batt.trigger("click"); //关闭操作
                    resTable.bootstrapTable('refresh'); //刷新
                }
                //关闭窗口
                swal({title: result.info, text: result.msg, type: result.type,timer: result.timer}, function () {
                });
            }
        }
    );

    /**
     * @describe  点击保存
     * @author eleven
     */
    _serve_batt.on('click',function(){
        _from.submit();//表单提交
    });

    /**
     * @describe  点击关闭窗口
     * @author eleven
     */
    _close_batt.on('click',function(){
        //模拟关闭当前窗口
        $(this)
            .parents('.layui-layer-content')
            .next('.layui-layer-setwin')
            .children('.layui-layer-close').trigger("click");
    });

    /**
     * @describe 点击设置图标
     * @author eleven
     */
    $('#resIco').on('click',function(){
        var id  = $(this).attr('data-id');
        //加载层
        var load = layer.load(0, {shade: false}); //0代表加载的风格，支持0-2
        $.post('/'+model_name+'/Res/ico',{id:id},function(html){
            //弹窗
            var current = layer.open({
                type: 1,                     //ayer提供了5种层类型。可传入的值有：0（信息框，默认）1（页面层）2（iframe层）3（加载层）4（tips层）。 若你采用layer.open({type: 1})方式调用，则type为必填项（信息框除外）
                title:'<i class="fa fa-edit"></i> ', //title支持三种类型的值，若你传入的是普通的字符串，如title :'我是标题'，那么只会改变标题文本；若你还需要自定义标题区域样式，那么你可以title: ['文本', 'font-size:18px;']，数组第二项可以写任意css样式；如果你不想显示标题栏，你可以title: false
                shade:[0.1,'#fff'],         //是否显示模糊层
                skin: 'layui-layer-rim layui-layer-molv',  //加上边框
                area: ['100%', '100%'], //在默认状态下，layer是宽高都自适应的，但当你只想定义宽度时，你可以area: '500px'，高度仍然是自适应的。当你宽高都要定义时，你可以area: ['500px', '300px']
                fixed: false,              //即鼠标滚动时，层是否固定在可视区域。如果不想，设置fixed: false即可
                maxmin: false,              //该参数值对type:1和type:2有效。默认不显示最大小化按钮。需要显示配置maxmin: true即可
                content:html,
                /**
                 * 层弹出后的成功回调方法
                 * 当你需要在层创建完毕时即执行一些语句，可以通过该回调。success会携带两个参数，分别是当前层DOM当前层索引
                 **/
                success: function(layero, index){
                    layer.close(load);//关闭加载特效
                }
            });
        });

    });

    $("[data-plugin-type='icheck']").iCheck({
        checkboxClass: 'icheckbox_square-blue',
        radioClass: 'iradio_square-blue',
        increaseArea: '20%' // optional
    });

})