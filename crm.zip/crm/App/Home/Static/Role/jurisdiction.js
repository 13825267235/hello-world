/**
 * Created by Administrator on 2017/6/3 0003.
 */
$(function () {

    /**
     * @describe  点击保存
     * @author eleven
     */
    $('#jurisdiction').on('click',function(){
        var _this = $(this);
        var form = $('#jurisdiction_form').serializeArray();
        var params = {};
        $.each(form, function () {
            if (params[this.name] !== undefined) {
                if (!params[this.name].push) {
                    params[this.name] = [params[this.name]];
                }
                params[this.name].push(this.value || '');
            } else {
                params[this.name] = this.value || '';
            }
        });
        $.post('/'+model_name+'/Role/jurisdictionServe',params,function(result){
            //关闭窗口
            swal({title: result.info, text: result.msg, type: result.type,timer: result.timer}, function () {
                layer.closeAll();
            });
        },'json')
    });
})