$(function(){

    _from = $("#active_update_form");




    //articleUploadImgData
    var settings = {
        uploadUrl:uploadUrl,//上传的地址
        uploadAsync: true, //设置上传同步异步 true=异步，false=同步
        language : 'zh', //设置语言
        showUpload: false, //是否显示上传按钮,跟随文本框的那个
        showRemove : false, //显示移除按钮,跟随文本框的那个
        showCaption: false,//是否显示标题,跟随文本框的那个
        maxFileCount: 1,
        allowedFileExtensions: ["jpg", "png", "gif"]
    }
    /**
     * 图片数据
     */
    if(activeUploadImgData!=''){
        settings.defaultPreviewContent = '<img src="'+activeUploadImgData+'" alt="Your Avatar" style="width:100%;height: 100px;">'
    }

    $(".myfile").fileinput(settings);

    //异步上传返回结果处理
    $(".myfile").on("fileuploaded", function (event, data, previewId, index) {
        console.log(data.response.url)
        $('#img').val(data.response.url);
        /* var ref=$(this).attr("data-ref");
         $("input[name='"+ref+"']").val(data.response.url);*/
    });
   // 表单检测
    App.popupFrom(
        {
            from:_from,
            validCallback:function(result){
                if(result.status == 'y'){
                    $("#updateClose").trigger("click"); //关闭操作
                    $('.selectDefualt').trigger('click'); //刷新
                }
                //关闭窗口
                swal({title: result.info, text: result.msg, type: result.type,timer: result.timer}, function () {

                });
            }
        }
    );

    /**
     * @describe 保存点击
     */
    $('#updateServe').on('click',function(){
        _from.submit();//表单提交
    });
    //
    ///**
    // * @describe 关闭点击
    // */
    $('#updateClose').on('click',function(){
        //模拟关闭当前窗口
        $(this)
            .parents('.layui-layer-content')
            .next('.layui-layer-setwin')
            .children('.layui-layer-close').trigger("click");
    });

    //实例化编辑器
    //建议使用工厂方法getEditor创建和引用编辑器实例，如果在某个闭包下引用该编辑器，直接调用UE.getEditor('editor')就能拿到相关的实例
    //首页公告
    UE.delEditor('notice');
    var notice = UE.getEditor('notice',
        {

            initialFrameHeight:350,
            enterTag:'br'
        });



})