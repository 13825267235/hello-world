$(function(){

    _from = $("#sys_user_update_form");

    //表单检测
    App.popupFrom(
        {
            from:_from,
            validCallback:function(result){
                if(result.status == 'y'){
                    layer.closeAll();
                    $('.selectDefualt').trigger('click'); //刷新
                }
                //关闭窗口
                swal({title: result.info, text: result.msg, type: result.type,timer: result.timer}, function () {});
            }
        }
    );

    /**
     * @describe 保存点击
     */
    $('#updateServe').on('click',function(){
        _from.submit();//表单提交
    });

    /**
     * @describe 关闭点击
     */
    $('#updateClose').on('click',function(){
        //模拟关闭当前窗口
        $(this)
        .parents('.layui-layer-content')
        .next('.layui-layer-setwin')
        .children('.layui-layer-close').trigger("click");
    });

    $("[data-plugin-type='tooltip']").tooltip({html:true});
});