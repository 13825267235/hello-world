$(function(){

    /*******************************网站配置****************************************/
    $('#webname').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        title: "网站名称",              //编辑框的标题
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveRequests
    });
    $('#webswitch').editable({
        type: "select",                //编辑框的类型。支持text|textarea|select|date|checklist等
        emptytext: "无配置",          //空值的默认文本
        inputclass: 'form-control',
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        source: { 1: "开启", 2: "关闭"},
        success:saveRequests
    });
    $('#webgg').editable({
        type: "textarea",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        success:saveRequests
    });
    $('#webphone').editable({
        type: "textarea",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        success:saveRequests
    });
    $('#webcloseserviceresult').editable({
        type: "textarea",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        success:saveRequests
    });
    $('#dlkg').editable({
        type: "select",                //编辑框的类型。支持text|textarea|select|date|checklist等
        emptytext: "无配置",          //空值的默认文本
        inputclass: 'form-control',
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        source: { 1: "开启", 2: "关闭"},
        success:saveRequests
    });
    /*******************************提现配置****************************************/
    $('#webcashafromtime').editable({
        type: "combodate",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        format: 'HH:mm',
        viewformat: 'HH:mm',
        template: 'HH:mm',
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        success:saveTimeRequests
    });
    $('#webcashtotime').editable({
        type: "combodate",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        format: 'HH:mm',
        viewformat: 'HH:mm',
        template: 'HH:mm',
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        success:saveTimeRequests
    });
    $('#webcashmin').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            if(isNaN($.trim(value))){
                return "请正确填写，只能是数字或小数";
            }
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveMoneyRequests
    });
    $('#webcashmax').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            if(isNaN($.trim(value))){
                return "请正确填写，只能是数字或小数";
            }
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveMoneyRequests
    });
    $('#webcashmore').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            var r =  /^\+?[1-9][0-9]*$/ //判断是否为正整数
            if(!r.test(value)){
                return '请正确填写，只能为整数，不能小于1';
            }
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveRequests
    });
    $('#webcashscale').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            var r =  /^\+?[1-9][0-9]*$/ //判断是否为正整数
            if(!r.test(value)){
                return '请正确填写，只能为整数，不能小于1';
            }
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveRequests
    });
    /*******************************充值配置****************************************/
    $('#webrachargemin').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            if(isNaN($.trim(value))){
                return "请正确填写，只能是数字或小数";
            }
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveMoneyRequests
    });
    $('#webrachargemax').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            if(isNaN($.trim(value))){
                return "请正确填写，只能是数字或小数";
            }
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveMoneyRequests
    });
    $('#webrachargemaxnum').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            if(isNaN($.trim(value))){
                return "请正确填写，只能是数字或小数";
            }
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveRequests
    });
    /*******************************试玩配置****************************************/
    $('#webdemoswitch').editable({
        type: "select",                //编辑框的类型。支持text|textarea|select|date|checklist等
        emptytext: "无配置",          //空值的默认文本
        inputclass: 'form-control',
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        source: { 1: "开启", 2: "关闭"},
        success:saveRequests
    });
    $('#webdemosenrollswitch').editable({
        type: "select",                //编辑框的类型。支持text|textarea|select|date|checklist等
        emptytext: "无配置",          //空值的默认文本
        inputclass: 'form-control',
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        source: { 1: "开启", 2: "关闭"},
        success:saveRequests
    });
    $('#webdemosno').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            var r =  /^\+?[1-9][0-9]*$/ //判断是否为正整数
            if(!r.test(value)){
                return '请正确填写，只能为整数，不能小于1';
            }
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveRequests
    });
    $('#webdemosmoney').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            if(isNaN($.trim(value))){
                return "请正确填写，只能是数字或小数";
            }
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveMoneyRequests
    });
    /*******************************彩票配置****************************************/
    $('#webfandianmax').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            if(isNaN($.trim(value))){
                return "请正确填写，只能是数字或小数";
            }
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveRequests
    });
    $('#webchedanmax').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            var r =  /^\+?[1-9][0-9]*$/ //判断是否为正整数
            if(!r.test(value)){
                return '请正确填写，只能为整数，不能小于1';
            }
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveRequests
    });
    /******************************* 手机配置****************************************/
    $('#webappiosdownload').editable({
        type: "textarea",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        success:saveRequests
    });
    $('#webappiosqrcode').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveRequests
    });
    $('#webappandroiddownload').editable({
        type: "textarea",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        success:saveRequests
    });
    $('#webappandroidqrcode').editable({
        type: "text",                //编辑框的类型。支持text|textarea|select|date|checklist等
        inputclass: 'form-control',
        disabled: false,             //是否禁用编辑
        emptytext: "无配置",          //空值的默认文本
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        validate: function (value) { //字段验证
            if (!$.trim(value)) {
                return '不能为空';
            }
        },
        success:saveRequests
    });
    /**注册配置**/
    $('#weixin').editable({
        type: "select",                //编辑框的类型。支持text|textarea|select|date|checklist等
        emptytext: "无配置",          //空值的默认文本
        inputclass: 'form-control',
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        source: { 1: "开启", 2: "关闭"},
        success:saveRequests
    });
    $('#phone').editable({
        type: "select",                //编辑框的类型。支持text|textarea|select|date|checklist等
        emptytext: "无配置",          //空值的默认文本
        inputclass: 'form-control',
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        source: { 1: "开启", 2: "关闭"},
        success:saveRequests
    });
    $('#em').editable({
        type: "select",                //编辑框的类型。支持text|textarea|select|date|checklist等
        emptytext: "无配置",          //空值的默认文本
        inputclass: 'form-control',
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        source: { 1: "开启", 2: "关闭"},
        success:saveRequests
    });
    $('#qq').editable({
        type: "select",                //编辑框的类型。支持text|textarea|select|date|checklist等
        emptytext: "无配置",          //空值的默认文本
        inputclass: 'form-control',
        mode: "popup",              //编辑框的模式：支持popup和inline两种模式，默认是popup
        source: { 1: "开启", 2: "关闭"},
        success:saveRequests
    });

    /**
     * @describe 保存操作
     * @param response
     * @param newValue
     */
    function saveRequests(response, newValue){
        var data = {};
        var _name = $(this).attr('name');
        var data = {name:_name,value:newValue};
        $.post('/'+model_name+'/Setting/serve',data,function(res){
            layer.msg(res.info);
        },'json');
    }

    /**
     * @describe 时间格式保存操作
     * @param response
     * @param newValue
     */
    function saveTimeRequests(response, newValue){
        console.log(this);
        var data = {};
        var _name = $(this).attr('name');
        var data = {name:_name,value:newValue.format('hh:mm')};
        $.post('/Admin/Settings/serve',data,function(res){
            layer.msg(res.info);
        },'json');
    }

    /**
     * @describe 金额格式保存操作
     * @param response
     * @param newValue
     */
    function saveMoneyRequests(response, newValue){
        var data = {};
        var _name = $(this).attr('name');
        var data = {name:_name,value:  parseFloat(newValue).toFixed(3)};
        $.post('/Admin/Settings/serve',data,function(res){
            layer.msg(res.info);
        },'json');
    }

    //$(".webFileAddress").fileinput({
    //    uploadUrl:'/Admin/Settings/webUploadLogo',//上传的地址
    //    uploadAsync: true, //设置上传同步异步 true=异步，false=同步
    //    language : 'zh', //设置语言
    //    maxFileCount: 1,
    //    initialPreview: (conig_web_add_log_img != '') ? conig_web_add_log_img : [],
    //    allowedFileExtensions: ["jpg", "png", "gif"]
    //});

    //$(".wapFileAddress").fileinput({
    //    uploadUrl:'/Admin/Settings/wapUploadLogo',//上传的地址
    //    uploadAsync: true, //设置上传同步异步 true=异步，false=同步
    //    language : 'zh', //设置语言
    //    maxFileCount: 1,
    //    initialPreview: (conig_wap_add_log_img != '') ? conig_wap_add_log_img : [],
    //    allowedFileExtensions: ["jpg", "png", "gif"]
    //});




});