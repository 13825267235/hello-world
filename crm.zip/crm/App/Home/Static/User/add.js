/**
 * Created by Administrator on 2017/12/28.
 */
$(function(){

    _from = $("#user_form");

    _serve_batt= $("#addServe");

    _close_batt = $("#addClose");

    //表单检测
    App.popupFrom(
        {
            from:_from,
            validCallback:function(result){
                if(result.status == 'y'){
                    layer.closeAll();
                    $('.selectDefualt').trigger('click'); //刷新
                }
                //关闭窗口
                swal({title: result.info, text: result.msg, type: result.type,timer: result.timer}, function () {

                });
            }
        }
    );

    /**
     * @describe 保存点击
     */
    _serve_batt.on('click',function(){
        _from.submit();//表单提交
    });

    /**
     * @describe 关闭点击
     */
    _close_batt.on('click',function(){
        //模拟关闭当前窗口
        $(this)
            .parents('.layui-layer-content')
            .next('.layui-layer-setwin')
            .children('.layui-layer-close').trigger("click");
    });

    $("[data-plugin-type='tooltip']").tooltip({html:true});

});