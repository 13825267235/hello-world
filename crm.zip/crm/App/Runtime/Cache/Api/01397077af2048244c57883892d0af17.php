<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="initial-scale=1,maximum-scale=1,minimum-scale=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo C('PUBLIC_CSS');?>register.css">
    <script src="<?php echo C('PUBLIC_JS');?>zepto.min.js"></script>
    <script src="<?php echo C('PUBLIC_JS');?>flexible.js"></script>
    <title>注册</title>
    <style>

    </style>
</head>

<body>
<!-- LOGO图标 -->
<div class="image"><img src="/upload/Api/img/ykb.png" alt=""></div>
<!-- 主题内容 -->
<div class="main">
    <div class="instance">
        <span class="main_tle">帐号</span>
        <input type="text" class="main_ctn main_ctns" id="user_name" placeholder="请输入手机号">
    </div>
    <div class="instance">
        <span class="main_tle">密码</span>
        <input type="password" class="main_ctn main_ctns" id="password" placeholder="请填写登录密码">
    </div>
    <!--<div class="instance">-->
        <!--<span class="main_tle">图形码</span>-->
        <!--<input type="text" class="main_ctn" id="img_code" placeholder="请输入图形码">-->
        <!--<div class="code_img instance_d"><img src="" alt=""></div>-->
    <!--</div>-->
    <div class="instance">
        <span class="main_tle">验证码</span>
        <input type="text" class="main_ctn" id="phone_code" placeholder="请输入短信验证码">
        <div class="get_code instance_d">
            <span class="get_code_text">获取验证码</span>
            <span class="get_code_num none">60</span></div>
    </div>
    <div class="instance">
        <span class="main_tle">推荐人</span>
        <span class="main_ctn main_ctnz" id="rer"><?php echo ($rer); ?></span>
    </div>
</div>
<!-- 注册 -->
<div class="goReg">立即注册</div>
<!-- 下载 -->
<div class="download">下载地址</div>
<script src="<?php echo C('PUBLIC_JS');?>register.js"></script>
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>layer-v3.0.3/layer/layer.js"></script>-->
<link href="<?php echo C('PUBLIC_PLUGIN');?>SweetAlert/sweetalert.css" rel="stylesheet" type="text/css"/>
<script src="<?php echo C('PUBLIC_PLUGIN');?>SweetAlert/sweetalert.min.js"></script>
</body>

</html>