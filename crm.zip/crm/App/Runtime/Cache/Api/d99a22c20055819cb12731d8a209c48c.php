<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="initial-scale=1,maximum-scale=1,minimum-scale=1">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo C('PUBLIC_CSS');?>download.css">
    <script src="<?php echo C('PUBLIC_JS');?>zepto.min.js"></script>
    <script src="<?php echo C('PUBLIC_JS');?>flexible.js"></script>
    <title>下载App</title>
</head>

<body>
    <div class="logo"><img src="/upload/Api/img/ykb.png" alt=""></div>
    <div class="title">养卡宝</div>
    <div class="text mtext">1.0.0(Beat 15) - 17.21M</div>
    <div class="text">更新于：2018-01-03</div>
    <a href="/upload/Api/app/aa.txt" download="" class="download_a download_android">安卓下载</a>
    <a href="/upload/Api/app/bb.txt" download="" class="download_a">苹果下载</a>
    <div class="wx_club none">
        <div class="wx_msg">请点击右上角<br/>选择“在浏览器中打开”</div>
    </div>
    <script>
        (function is_weixn() {
            var ua = navigator.userAgent.toLowerCase();
            if (ua.match(/MicroMessenger/i) == "micromessenger") {
                $(".wx_club").removeClass("none");
            }
        })();
    </script>
</body>

</html>