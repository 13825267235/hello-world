<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en" class="ie8 no-js">
<html lang="en" class="ie9 no-js">
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>OA后台</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="<?php echo C('PUBLIC_PLUGIN');?>googleapis/googleapis.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo C('PUBLIC_PLUGIN');?>font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo C('PUBLIC_PLUGIN');?>simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo C('PUBLIC_PLUGIN');?>uniform/css/uniform.default.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
    <!--<link href="<?php echo C('PUBLIC_PLUGIN');?>custom.css" rel="stylesheet" type="text/css" />-->
    <link href="<?php echo C('PUBLIC_PLUGIN');?>animsition/animsition.css" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->

    <!-- BEGIN THEME GLOBAL STYLES -->
    
        <link href="<?php echo C('PUBLIC_PLUGIN');?>components-rounded.min.css" rel="stylesheet" id="style_components" type="text/css" />
        <link href="<?php echo C('PUBLIC_PLUGIN');?>plugins-md.min.css" rel="stylesheet" type="text/css" />
    
    <!-- END THEME GLOBAL STYLES -->

    <!-- BEGIN THEME LAYOUT STYLES -->
    
        <link href="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/css/themes/light2.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
    
    <!-- END THEME LAYOUT STYLES -->

    <!-- BEGIN PAGE LEVEL STYLES -->
    

    
    <!-- END PAGE LEVEL STYLES -->


    

    <!--<link rel="shortcut icon" href="favicon.ico" />-->
</head>



</head>

<body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">



    <!-- BEGIN HEADER -->
    <div class="page-header navbar navbar-fixed-top">
        <!-- BEGIN HEADER INNER -->
        <div class="page-header-inner ">
            <!-- BEGIN LOGO -->
            <div class="page-logo">
                    <img src="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/img/logo.png" alt="logo" class="logo-default" />
                <div class="menu-toggler sidebar-toggler"> </div>
            </div>
            <!--<div class="page-logo">-->
                <!--<div class="bg-font-dark">app在线人数：<span class="font-yellow-saffron" id="Apps">0</span></div>-->
                <!--<div class="bg-font-dark">wap在线人数：<span class="font-yellow-saffron" id="waps">0</span> </div>-->
            <!--</div>-->
            <!--<div class="page-logo">-->
                <!--<div class="bg-font-dark">PC在线人数：<span class="font-yellow-saffron" id="pcs">0</span></div>-->
                <!--<div class="bg-font-dark">会员总人数：<span class="font-yellow-saffron" id="userCounts">0</span> </div>-->
            <!--</div>-->
            <!--<div class="page-logo">-->
                <!--<div class="bg-font-dark">代理总人数：<span class="font-yellow-saffron" id="dlUserCount">0</span> </div>-->
                <!--<div class="bg-font-dark">今日注册：<span class="font-yellow-saffron" id="jrUserCounts">0</span></div>-->
            <!--</div>-->
            <!--<div class="page-logo">-->
                <!--<div class="bg-font-dark">可用额度：<span class="font-yellow-saffron" id="surplusQuota">0</span> </div>-->
                <!--<div class="bg-font-dark">已用额度：<span class="font-yellow-saffron" id="hasBeenQuota">0</span></div>-->
            <!--</div>-->

            <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse"> </a>

            <div class="top-menu">
                <ul class="nav navbar-nav pull-right">

                    <!-- 开始  充值 提醒 列表 展示 -->
                    <li class="dropdown dropdown-extended dropdown-inbox" id="userRechargeInfro" title="充值申请">
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                            <i class=" icon-credit-card"></i>
                            <span class="badge badge-default userRechargeCount" style="display:none;">0</span>
                        </a>
                        <ul class="dropdown-menu" style="display:none;">
                            <li class="external">
                                <h3>You have
                                    <span class="bold">7 New</span> Messages</h3>
                                <a href="app_inbox.html">view all</a>
                            </li>
                            <li>
                                <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 275px;">
                                    <ul class="dropdown-menu-list scroller" style="height: 275px; overflow: hidden; width: auto;" data-handle-color="#637283" data-initialized="1">
                                        <li>
                                            <a href="#">
                                                    <span class="photo">
                                                        <img src="" class="img-circle" alt=""> </span>
                                                <span class="subject">
                                                        <span class="from"> Lisa Wong </span>
                                                        <span class="time">Just Now </span>
                                                    </span>
                                                <span class="message"> Vivamus sed auctor nibh congue nibh. auctor nibh auctor nibh... </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                    <span class="photo">
                                                        <img src="" class="img-circle" alt=""> </span>
                                                <span class="subject">
                                                        <span class="from"> Richard Doe </span>
                                                        <span class="time">16 mins </span>
                                                    </span>
                                                <span class="message"> Vivamus sed congue nibh auctor nibh congue nibh. auctor nibh auctor nibh... </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                    <span class="photo">
                                                        <img src="" class="img-circle" alt=""> </span>
                                                <span class="subject">
                                                        <span class="from"> Bob Nilson </span>
                                                        <span class="time">2 hrs </span>
                                                    </span>
                                                <span class="message"> Vivamus sed nibh auctor nibh congue nibh. auctor nibh auctor nibh... </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                    <span class="photo">
                                                        <img src="" class="img-circle" alt=""> </span>
                                                <span class="subject">
                                                        <span class="from"> Lisa Wong </span>
                                                        <span class="time">40 mins </span>
                                                    </span>
                                                <span class="message"> Vivamus sed auctor 40% nibh congue nibh... </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                    <span class="photo">
                                                        <img src="" class="img-circle" alt=""> </span>
                                                <span class="subject">
                                                        <span class="from"> Richard Doe </span>
                                                        <span class="time">46 mins </span>
                                                    </span>
                                                <span class="message"> Vivamus sed congue nibh auctor nibh congue nibh. auctor nibh auctor nibh... </span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="slimScrollBar" style="background: rgb(99, 114, 131); width: 7px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 160.904px;"></div>
                                    <div class="slimScrollRail" style="width: 7px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(234, 234, 234); opacity: 0.2; z-index: 90; right: 1px;"></div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <!-- 结束  充值 提醒  列表 展示 -->

                    <!-- 开始  提现 提醒 列表 展示 -->
                    <li class="dropdown dropdown-extended dropdown-inbox" id="userCashInfro" title="提现申请">
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                            <i class="icon-bell"></i>
                            <span class="badge badge-default userCashCount" style="display:none;">0</span>
                        </a>
                        <ul class="dropdown-menu" style="display:none;">
                            <li class="external">
                                <h3>你有
                                    <span class="bold">7</span>个充值订单需要处理</h3>
                                <a href="app_inbox.html">查看所有</a>
                            </li>
                            <li>
                                <ul class="dropdown-menu-list scroller" style="height: 275px;" data-handle-color="#637283">
                                    <li>
                                        <a href="#">
                                                <span class="photo">
                                                    <img src="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/img/avatar2.jpg" class="img-circle" alt=""> </span>
                                            <span class="subject">
                                                    <span class="from">sadas</span>
                                                    <span class="time">申请时间 ：2017-08-26 </span>
                                                </span>
                                            <span class="message">
                                                Vivamus sed auctor nibh congue nibh.
                                                auctor nibh auctor nibhVivamus sed auctor nibh congue nibh.
                                                auctor nibh auctor nibh
                                            </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                                <span class="photo">
                                                    <img src="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/img/avatar3.jpg" class="img-circle" alt=""> </span>
                                            <span class="subject">
                                                    <span class="from"> Richard Doe </span>
                                                    <span class="time">16 mins </span>
                                                </span>
                                            <span class="message"> Vivamus sed congue nibh auctor nibh congue nibh. auctor nibh auctor nibh... </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                                <span class="photo">
                                                    <img src="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/img/avatar1.jpg" class="img-circle" alt=""> </span>
                                            <span class="subject">
                                                    <span class="from"> Bob Nilson </span>
                                                    <span class="time">2 hrs </span>
                                                </span>
                                            <span class="message"> Vivamus sed nibh auctor nibh congue nibh. auctor nibh auctor nibh... </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                                <span class="photo">
                                                    <img src="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/img/avatar2.jpg" class="img-circle" alt=""> </span>
                                            <span class="subject">
                                                    <span class="from"> Lisa Wong </span>
                                                    <span class="time">40 mins </span>
                                                </span>
                                            <span class="message"> Vivamus sed auctor 40% nibh congue nibh... </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                                <span class="photo">
                                                    <img src="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/img/avatar3.jpg" class="img-circle" alt=""> </span>
                                            <span class="subject">
                                                    <span class="from"> Richard Doe </span>
                                                    <span class="time">46 mins </span>
                                                </span>
                                            <span class="message"> Vivamus sed congue nibh auctor nibh congue nibh. auctor nibh auctor nibh... </span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <!-- 结束  提现 提醒 列表 展示 -->

                    <!-- 开始  提醒 音开关 -->
                    <li class="dropdown dropdown-extended dropdown-notification" id="remindSwitch" data-state="off">
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                            <i class="icon-volume-2" id="remindICO"></i>
                        </a>
                    </li>
                    <!-- 结束  提醒 音开关 -->

                    <!-- BEGIN USER LOGIN DROPDOWN -->
                    <!-- DOC: Apply "dropdown-dark" class after below "dropdown-extended" to change the dropdown styte -->
                    <li class="dropdown dropdown-user">
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                            <i class="icon-user"></i>
                            <!--<img alt="" class="img-circle" src="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/img/avatar3_small.jpg" />-->
                            <span class="username username-hide-on-mobile"> <?php echo ($userInfos['username']); ?> </span>
                            <i class="fa fa-angle-down"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-default">
                            <!--<li>
                                <a href="page_user_profile_1.html">
                                    <i class="icon-user"></i> 我的个人资料
                                </a>
                            </li>
                            <li>
                                <a href="app_calendar.html">
                                    <i class="icon-calendar"></i> 我的日历
                                </a>
                            </li>
                            <li>
                                <a href="app_inbox.html">
                                    <i class="icon-envelope-open"></i> 收件箱
                                    <span class="badge badge-danger"> 3 </span>
                                </a>
                            </li>
                            <li>
                                <a href="app_todo.html">
                                    <i class="icon-rocket"></i>我的任务
                                    <span class="badge badge-success"> 7 </span>
                                </a>
                            </li>
                            <li class="divider"> </li>
                            <li>
                                <a href="page_user_lock_1.html">
                                    <i class="icon-lock"></i> 锁屏
                                </a>
                            </li>-->
                            <li>
                                <a href="#" id="logout">
                                    <i class="icon-key"></i> 安全退出
                                </a>
                            </li>
                        </ul>
                    </li>
                    <!-- END USER LOGIN DROPDOWN -->
                    <!-- BEGIN QUICK SIDEBAR TOGGLER -->
                    <!-- DOC: Apply "dropdown-dark" class after below "dropdown-extended" to change the dropdown styte -->
                    <!--<li class="dropdown dropdown-quick-sidebar-toggler">
                        <a href="javascript:;" class="dropdown-toggle">
                            <i class="icon-logout"></i>
                        </a>
                    </li>-->
                    <!-- END QUICK SIDEBAR TOGGLER -->
                </ul>
            </div>

        </div>

    </div>
    <!-- END HEADER -->

    <!-- BEGIN HEADER & CONTENT DIVIDER -->
    <div class="clearfix"> </div>
    <!-- END HEADER & CONTENT DIVIDER -->





    <!-- BEGIN CONTAINER -->

    <div class="page-container">
        <!-- BEGIN SIDEBAR -->
        <div class="page-sidebar-wrapper">

            <div class="page-sidebar navbar-collapse collapse">
                <ul class="page-sidebar-menu  page-header-fixed " data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px">
                    <li class="sidebar-toggler-wrapper hide">
                        <!-- BEGIN SIDEBAR TOGGLER BUTTON -->
                        <div class="sidebar-toggler"> </div>
                        <!-- END SIDEBAR TOGGLER BUTTON -->
                    </li>
                    <li class="sidebar-search-wrapper">

                    </li>

                    <?php if(!empty($nav)): if(is_array($nav)): $i = 0; $__LIST__ = $nav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$k): $mod = ($i % 2 );++$i; if(in_array($k['identifying'],$userInfo)): ?><li class="nav-item  ">
                                <a href="javascript:;" class="nav-link nav-toggle">
                                    <i class="<?php echo ($k["ico"]); ?>"></i>
                                    <span class="title"><?php echo ($k["name"]); ?></span>
                                    <span class="arrow"></span>
                                </a>
                                <ul class="sub-menu">
                                   <?php if(is_array($k['children'])): $i = 0; $__LIST__ = $k['children'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i; if(in_array($v['identifying'],$userInfo)): ?><li class="nav-item  ">
                                               <a href="/<?php echo C('MODEL_NAME');?>/<?php echo ($v["url"]); ?>" <?php if($v["id"] == 2): ?>class="selectDefualt cebianlan"<?php else: ?>class="cebianlan"<?php endif; ?> id="<?php echo ($v["identifying"]); ?>">
                                                   <i class="<?php echo ($v["ico"]); ?>"></i> <span class="title"><?php echo ($v["name"]); ?></span>
                                               </a>
                                           </li><?php endif; endforeach; endif; else: echo "" ;endif; ?>
                                </ul>
                            </li><?php endif; endforeach; endif; else: echo "" ;endif; endif; ?>

                    <!--<li class="nav-item  ">-->
                        <!--<a href="javascript:;" class="nav-link nav-toggle">-->
                            <!--<i class="icon-diamond"></i>-->
                            <!--<span class="title">运营商管理</span>-->
                            <!--<span class="arrow"></span>-->
                        <!--</a>-->
                        <!--<ul class="sub-menu">-->
                            <!--<li class="nav-item  ">-->
                                <!--<a href="/<?php echo C('MODEL_NAME');?>/Operator/index"  class="cebianlan">-->
                                    <!--<i class="icon-diamond"></i> <span class="title">运营商列表</span>-->
                                <!--</a>-->
                            <!--</li>-->
                            <!--<li class="nav-item  ">-->
                                <!--<a href="/<?php echo C('MODEL_NAME');?>/Operator/index" class="cebianlan">-->
                                    <!--<i class="icon-diamond"></i> <span class="title">运营商分层管理</span>-->
                                <!--</a>-->
                            <!--</li>-->
                        <!--</ul>-->
                    <!--</li>-->
                </ul>
            </div>
            <!-- END SIDEBAR -->
        </div>
        <!-- END SIDEBAR -->
        <!-- BEGIN CONTENT -->
        <div class="page-content-wrapper">
            <!-- BEGIN CONTENT BODY -->

            <div class="page-content">
                <div class="page-bar">
                    <ul class="page-breadcrumb">
                        <li>
                            <span id="navigations"></span>
                            <i class="fa fa-circle"></i>
                        </li>
                        <li>
                            <span id="navigation" href=""></span>
                        </li>
                    </ul>
                    <!--<div class="page-toolbar">
                        <div class="btn-group pull-right">
                            <button type="button" class="btn green btn-sm btn-outline dropdown-toggle" data-toggle="dropdown"> Actions
                                <i class="fa fa-angle-down"></i>
                            </button>
                            <ul class="dropdown-menu pull-right" role="menu">
                                <li>
                                    <a href="#">
                                        <i class="icon-bell"></i> Action</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-shield"></i> Another action</a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-user"></i> Something else here</a>
                                </li>
                                <li class="divider"> </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-bag"></i> Separated link</a>
                                </li>
                            </ul>
                        </div>
                    </div>-->
                </div>
                <div id="content" style="padding-top: 10px"></div>
            </div>

            <!-- END CONTENT BODY -->
        </div>
        <!-- END CONTENT -->
        <!-- BEGIN QUICK SIDEBAR -->
        <a href="javascript:;" class="page-quick-sidebar-toggler">
            <i class="icon-login"></i>
        </a>
        <div class="page-quick-sidebar-wrapper" data-close-on-body-click="false">
            <div class="page-quick-sidebar">
                <ul class="nav nav-tabs">
                    <li class="active">
                        <a href="javascript:;" data-target="#quick_sidebar_tab_1" data-toggle="tab"> Users
                            <span class="badge badge-danger">2</span>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:;" data-target="#quick_sidebar_tab_2" data-toggle="tab"> Alerts
                            <span class="badge badge-success">7</span>
                        </a>
                    </li>
                    <li class="dropdown">
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown"> More
                            <i class="fa fa-angle-down"></i>
                        </a>
                        <ul class="dropdown-menu pull-right">
                            <li>
                                <a href="javascript:;" data-target="#quick_sidebar_tab_3" data-toggle="tab">
                                    <i class="icon-bell"></i> Alerts </a>
                            </li>
                            <li>
                                <a href="javascript:;" data-target="#quick_sidebar_tab_3" data-toggle="tab">
                                    <i class="icon-info"></i> Notifications </a>
                            </li>
                            <li>
                                <a href="javascript:;" data-target="#quick_sidebar_tab_3" data-toggle="tab">
                                    <i class="icon-speech"></i> Activities </a>
                            </li>
                            <li class="divider"></li>
                            <li>
                                <a href="javascript:;" data-target="#quick_sidebar_tab_3" data-toggle="tab">
                                    <i class="icon-settings"></i> Settings </a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <div class="tab-content">

                </div>
            </div>
        </div>
        <!-- END QUICK SIDEBAR -->

    </div>




    <!-- BEGIN FOOTER -->
    <div class="page-footer">
        <div class="page-footer-inner"> 2017 &copy; OA后台
        </div>
        <div class="scroll-to-top">
            <i class="icon-arrow-up"></i>
        </div>
    </div>
    <!-- END FOOTER -->

    <!--弹窗容器-->
    <div class="modal-pool"></div>
    <!--弹窗容器-->



<!--<script>-->
    <!--var PAGE_ING = "<?php echo C('PAGE_ING');?>"; // 获取每页显示多少数据-->
    <!--var USERINFO = '<?php echo (json_encode($USERINFO)); ?>'; // 获取登录者的信息-->
    <!--USERINFO = eval('(' + USERINFO + ')');-->
    <!--var payWyDataCache = '<?php echo (json_encode($payWyDataCache)); ?>'; // 获取银行接口数据-->
    <!--payWyDataCache = eval('(' + payWyDataCache + ')');-->
    <!--var REQUESTIP = '<?php echo ($REQUESTIP); ?>'; // 获取ip-->
<!--</script>-->

<!--[if lt IE 9]>
<script src="<?php echo C('PUBLIC_PLUGIN');?>respond.min.js"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>excanvas.min.js"></script>
<![endif]-->

<!-- BEGIN CORE PLUGINS -->
<script src="<?php echo C('PUBLIC_PLUGIN');?>jquery.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>js.cookie.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>jquery.blockui.min.js" type="text/javascript"></script>
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>uniform/jquery.uniform.min.js" type="text/javascript"></script>-->
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
<!-- END CORE PLUGINS -->

<!--开始 开关 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
<!--结束 开关-->


<!--开始 信息弹窗-->
<link href="<?php echo C('PUBLIC_PLUGIN');?>SweetAlert/sweetalert.css" rel="stylesheet" type="text/css"/>
<script src="<?php echo C('PUBLIC_PLUGIN');?>SweetAlert/sweetalert.min.js"></script>
<!--结束 信息弹窗-->

<!-- 开始 表单验证-->
<link href="<?php echo C('PUBLIC_PLUGIN');?>Validformv5.3.2/css/style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>Validformv5.3.2/js/Validformv5.3.2.js"></script>
<!--结束 表单验证-->

<!-- 开始 弹窗-->
<link href="<?php echo C('PUBLIC_PLUGIN');?>layer-v3.0.3/layer/skin/default/layer.css" rel="stylesheet" type="text/css" />
<link href="<?php echo C('PUBLIC_PLUGIN');?>layer-v3.0.3/layer/skin/user/user.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>layer-v3.0.3/layer/layer.js"></script>
<!--结束 弹窗-->

<!-- 开始 时间 框插件 -->
<script src="<?php echo C('PUBLIC_PLUGIN');?>moment.min.js" type="text/javascript"></script>
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-datetimepicker-master/css/bootstrap-datetimepicker.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-datetimepicker-master/locale/zh-cn.js" type="text/javascript" ></script>
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-datetimepicker-master/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>-->
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-datetimepicker-master/js/bootstrap-datetimepicker.js" type="text/javascript"></script>

<!-- 结束 时间 框插件 -->

<!-- 开始 筛选 时间 插件-->
<!--<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-daterangepicker/daterangepicker.min.css" rel="stylesheet" type="text/css" />-->
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-daterangepicker/daterangepicker.js" type="text/javascript"></script>-->
<!-- 结束 筛选 时间 插件-->


<!-- 开始 bootsrap 表格 插件-->
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-table/bootstrap-table.css" rel="stylesheet" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-table/bootstrap-table.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-table/locale/bootstrap-table-zh-CN.js"></script>
<!-- 结束 bootsrap 表格 插件-->


<!-- 开始 表格 编辑器 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-editable/bootstrap-editable/css/bootstrap-editable.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-editable/bootstrap-editable/js/bootstrap-editable.js" type="text/javascript"></script>
<!--<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap3-editable-1.5.1/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet" type="text/css" />-->
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap3-editable-1.5.1/bootstrap3-editable/js/bootstrap-editable.js" type="text/javascript"></script>-->

<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-editable/bootstrap-editable/js/bootstrap-table-editable.js" type="text/javascript"></script>
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-editable/inputs-ext/address/address.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-editable/inputs-ext/address/address.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-editable/inputs-ext/wysihtml5/wysihtml5.js" type="text/javascript"></script>
<!-- 结束 表格 编辑器 -->

<!-- 开始 提示 插件 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-touchspin/bootstrap.touchspin.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-touchspin/bootstrap.touchspin.js" type="text/javascript"></script>
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap/js/bootstrap.js" type="text/javascript"></script>-->
<!-- 结束 提示 插件 -->

<!-- 开始 提示 插件 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>icheck/skins/all.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>icheck/icheck.min.js" type="text/javascript"></script>
<!-- 结束 提示 插件 -->

<!-- 开始 百度编辑器 插件 -->
<script src="<?php echo C('PUBLIC_PLUGIN');?>ueditor1_4_3_3-utf8/ueditor.config.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>ueditor1_4_3_3-utf8/ueditor.all.js" type="text/javascript"> </script>
<!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
<!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
<script src="<?php echo C('PUBLIC_PLUGIN');?>ueditor1_4_3_3-utf8/lang/zh-cn/zh-cn.js" type="text/javascript"></script>
<!-- 结束 百度编辑器 插件 -->

<!-- 开始 上传 插件 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-fileinput-master/css/fileinput.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-fileinput-master/js/locales/zh.js" type="text/javascript"></script>
<!-- 结束 上传 插件 -->

<!-- 开始 树 插件 -->
<!--<link href="<?php echo C('PUBLIC_PLUGIN');?>zTree_v3-master/css/zTreeStyle/zTreeStyle.css" rel="stylesheet" type="text/css" />-->
<link href="<?php echo C('PUBLIC_PLUGIN');?>zTree_v3-master/css/metroStyle/metroStyle.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>zTree_v3-master/js/jquery.ztree.core.js" type="text/javascript"></script>
<!--带编辑功能-->
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>zTree_v3-master/js/jquery.ztree.exedit.js" type="text/javascript"></script>-->
<!-- 结束 树 插件 -->

<!-- 开始 动画数字 插件 -->
<script src="<?php echo C('PUBLIC_PLUGIN');?>counterup/jquery.waypoints.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>counterup/jquery.counterup.min.js" type="text/javascript"></script>
<!-- 开始 动画数字 插件 -->

<!-- 开始 下拉筛选 插件 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>select2/css/select2.css" rel="stylesheet" type="text/css" />
<link href="<?php echo C('PUBLIC_PLUGIN');?>select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>select2/js/select2.full.js" type="text/javascript"></script>
<!-- 开始 下拉筛选 插件 -->

<!-- 开始 自动补全 插件 -->
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-suggest/js/bootstrap-suggest.min.js" type="text/javascript"></script>
<!-- 开始 自动补全 插件 -->

<!-- 开始 下拉插件 插件 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo C('PUBLIC_PLUGIN');?>select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>select2/js/select2.full.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>select2/js/i18n/zh-CN.js" type="text/javascript"></script>
<!-- 开始 下拉插件 插件 -->

<!-- 开始 下拉插件 插件 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-select/js/bootstrap-select.min.js" type="text/javascript"></script>
<!-- 开始 下拉插件 插件 -->


<!-- BEGIN THEME GLOBAL SCRIPTS -->
<script src="<?php echo C('PUBLIC_JS');?>app.js" type="text/javascript"></script>
<!-- END THEME GLOBAL SCRIPTS -->


<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/js/layout.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/js/demo.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
<!-- END THEME LAYOUT SCRIPTS -->

<!--省级联动-->
<script src="<?php echo C('PUBLIC_JS');?>area.js" type="text/javascript"></script>
<script>
    var model_name="<?php echo C('MODEL_NAME');?>";
</script>



    <script>
        var identificationJson = eval('<?php echo ($userRes["identificationJson"]); ?>');
        var admin=eval('<?php echo ($userInfos["is_admin"]); ?>');
    </script>
    <script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Index/index.js"></script>

</body>
</html>