<?php if (!defined('THINK_PATH')) exit();?><form id="role_add_form" method="post" action="/<?php echo C('MODEL_NAME');?>/Role/addServe">
    <div class="modal-dialog modal-full">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close fui-close" aria-hidden="true">&times;</button>
                <h4 class="modal-title font-green-sharp">新增</h4>
            </div>

            <div class="modal-body">
                <table class="table table-hover table-striped table-bordered">
                    <tbody>
                    <tr>
                        <td width="30%" class="text-right">角色名称：</td>
                        <td>
                            <input type="text" name="name" class="form-control"
                                   placeholder="请输入角色名称！"
                                   nullmsg="请输入角色名称！"
                                   datatype="*1-18"
                                   errormsg="角色名称至少1个字符,最多18个字符"
                            />
                        </td>
                    </tr>
                    <tr>
                        <td width="20%" class="text-right">角色名称说明：</td>
                        <td>
                           <textarea name="depict" id="depict" class="form-control"
                                     placeholder="描述该角色！"
                                     cols="45"
                                     rows="4"
                                     datatype="*0-120"
                                     errormsg="最多120个字符！"
                           ></textarea>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default fui-close">关闭</button>
                <button type="submit" class="btn btn-primary green">保存</button>
            </div>
        </div>
    </div>
</form>
<script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Role/add.js"></script>
<!-- 结束 内容 块 -->