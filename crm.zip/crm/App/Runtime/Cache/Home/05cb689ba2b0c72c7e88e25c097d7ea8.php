<?php if (!defined('THINK_PATH')) exit();?><form id="res_edit_submenu_form" method="post" action="/<?php echo C('MODEL_NAME');?>/Res/deitServe">
    <input type="hidden" name="id" value="<?php echo ($dataInfro['id']); ?>">
    <div class="modal-dialog modal-full">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close fui-close" aria-hidden="true">&times;</button>
                <h4 class="modal-title font-green-sharp">修改</h4>
            </div>

            <div class="modal-body">
                <table class="table table-hover table-striped table-bordered">
                    <tbody>
                    <tr>
                        <td class="col-md-3 text-right">菜单名称：</td>
                        <td>
                            <input type="text" name="name" class="form-control"
                                   value="<?php echo ($dataInfro['name']); ?>"
                                   placeholder="请输入菜单名称！"
                                   nullmsg="请输入菜单名称！"
                                   datatype="*1-18"
                                   errormsg="资源名称至少1个字符,最多18个字符"
                            />
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">是否隐藏：</td>
                        <td>
                            <label>
                                <input type="radio" name="is_hide" class="icheck" value="1" data-plugin-type="icheck">
                                是
                            </label>
                            <label>
                                <input type="radio" name="is_hide" class="icheck" value="0" data-plugin-type="icheck" checked>
                                否
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">资源标识：</td>
                        <td>
                            <input type="text" name="identifying" id="identifying"
                                   value="<?php echo ($dataInfro['identifying']); ?>"
                                   placeholder="请输入菜单标识！"
                                   nullmsg="请输入菜单标识！"
                                   class="form-control"
                                   datatype="*1-40"
                                   errormsg="菜单标识至少1个字符,最多40个字符！"
                            />
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">菜单地址：</td>
                        <td>
                            <input type="text" name="url" class="form-control"
                                   value="<?php echo ($dataInfro['url']); ?>"
                                   placeholder="请输入菜单地址！"
                                   nullmsg="请输入菜单地址！"
                                   datatype="*1-280"
                                   errormsg="菜单地址少至1个字符,最多280个字符"
                            />
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">排序：</td>
                        <td>
                            <input type="text" name="sort" class="form-control"
                                   value="<?php echo ($dataInfro['sort']); ?>"
                                   value="0"
                                   datatype="n1-11"
                                   errormsg="排序必须是数字"
                            />
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">图标：</td>
                        <td>
                            <input type="hidden" name="ico" id="ico_add_submenu" value="<?php echo ($dataInfro['ico']); ?>">
                            <a href="javascript:;" class="btn btn-circle btn-lg default" id="resIco" data-id="<?php echo ($dataInfro['id']); ?>">
                                设置图标  <i class="<?php echo ($dataInfro['ico']); ?>" id="add_ico"></i>
                            </a>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">菜单说明：</td>
                        <td>
                            <textarea name="depict" id="depict" class="form-control"
                                      placeholder="描述该菜单！"
                                      cols="45"
                                      rows="4"
                                      datatype="*0-120"
                                      errormsg="最多120个字符！"
                            ><?php echo ($dataInfro['depict']); ?></textarea>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default fui-close">关闭</button>
                <button type="submit" class="btn btn-primary green">保存</button>
            </div>
        </div>
    </div>
</form>
<script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Res/edit.js"></script>