<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 内容 块 -->
<form id="update_form" method="post" action="/<?php echo C('MODEL_NAME');?>/Grade/updateServe">
    <input type="hidden" name="id" value="<?php echo ($data['grade']); ?>">
    <input type="hidden" name="action" value="update">
    <input type="hidden" name="name" value="<?php echo ($data['grade_name']); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close fui-close" aria-hidden="true"></button>
                <h4 class="font-green-sharp">编辑</h4>
            </div>

            <div class="modal-body">
                <table class="table table-hover table-striped table-bordered Xui-table">
                    <tbody>
                    <tr>
                        <td class="text-right col-md-4">会员等级：</td>
                        <td>
                            <p class="form-control-static">
                                <span style='color: #CC0000'><?php echo ($data['grade_name']); ?></span>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">升级金额(元)：</td>
                        <td>
                            <input type="number" name="up_money" class="form-control" value="<?php echo ($data['up_money']); ?>"
                                   placeholder="请输入金额"
                                   nullmsg="请输入金额"
                                   datatype="*1-11"
                                   errormsg="最长只能是11个字符">
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">还款比率(%)：</td>
                        <td>
                            <input type="number" name="repay_rate" class="form-control" value="<?php echo ($data['repay_rate']); ?>"
                                   step="0.01"
                                   placeholder="请输入还款比率"
                                   nullmsg="请输入还款比率"
                                   datatype="*1-11"
                                   errormsg="最长只能是11个字符">
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">收款比率(%)：</td>
                        <td>
                            <input type="number" name="collection_rate" class="form-control" value="<?php echo ($data['collection_rate']); ?>"
                                   step="0.01"
                                   placeholder="请输入收款比率"
                                   nullmsg="请输入收款比率"
                                   datatype="*1-11"
                                   errormsg="最长只能是11个字符">
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default fui-close">关闭</button>
                <button type="submit" class="btn btn-primary green">保存</button>
            </div>
        </div>
    </div>
</form>
<script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Grade/update.js"></script>
<!-- 结束 内容 块 -->