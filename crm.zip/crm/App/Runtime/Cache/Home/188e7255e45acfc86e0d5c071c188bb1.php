<?php if (!defined('THINK_PATH')) exit();?><form id="add_form" method="post" action="/<?php echo C('MODEL_NAME');?>/Repay/opServe">
    <div class="modal-dialog modal-full">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close fui-close" aria-hidden="true">&times;</button>
                <h4 class="modal-title font-green-sharp"></h4>
            </div>
            <input type="hidden" value="<?php echo ($data["id"]); ?>" name="id">
            <input type="hidden" value="<?php echo ($data["username"]); ?>" name="username">
            <div class="modal-body">
                <table class="table table-hover table-striped table-bordered">
                    <tbody>
                    <tr >
                        <td  class="text-right col-md-2">用户名：</td>
                        <td  class="col-md-3"><?php echo ($data["username"]); ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">真实姓名：</td>
                        <td><?php echo ($data["user"]); ?></td>
                    </tr>
                    <tr>
                        <td  class="text-right ">身份证：</td>
                        <td ><?php echo ($data["ic"]); ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">信用卡：</td>
                        <td><?php echo ($data["bank_name"]); ?></td>
                    </tr>
                    <tr>
                        <td  class="text-right ">卡号：</td>
                        <td  ><?php echo ($data["nub"]); ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">预留电话：</td>
                        <td><?php echo ($data["phone"]); ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">申请时间：</td>
                        <td><?php echo ($data["create_time"]); ?></td>
                    </tr>
                    <tr>
                        <td class="text-right">确认通过：</td>
                        <td>
                            <select class="form-control" name="is_pass">
                                <option value="0" selected="selected">是</option>
                                <!--<option value="1">否</option>-->
                            </select>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default fui-close">关闭</button>
                <button type="submit" class="btn btn-primary green">保存</button>
            </div>
        </div>
    </div>
</form>
<script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Ic/op.js"></script>
<!-- 结束 内容 块 -->