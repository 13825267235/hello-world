<?php if (!defined('THINK_PATH')) exit();?><form action="" method="post" id="jurisdiction_form">
    <input type="hidden" name="id" value="<?php echo ($id); ?>">
    <div class="modal-dialog modal-full">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close fui-close" aria-hidden="true">&times;</button>
                <h4 class="modal-title font-green-sharp">权限设置</h4>
            </div>
            <div class="modal-body">
                <table class="table table-hover table-striped table-bordered Xui-table">
                    <?php if(is_array($rule_data)): foreach($rule_data as $key=>$v): if(empty($v['children'])): ?><tr class="b-group">
                                <th width="10%">
                                    <label><?php echo ($v['name']); ?>
                                        <input
                                                type="checkbox"
                                                name="rule_ids[]"
                                                value="<?php echo ($v['identifying']); ?>"
                                        <?php if(in_array($v['identifying'],$group_data)): ?>checked="checked"<?php endif; ?>
                                        onclick="checkAll(this)"
                                        />
                                    </label>
                                </th>
                                <td></td>
                            </tr>
                            <?php else: ?>
                            <tr class="b-group">
                                <th width="10%">
                                    <label><?php echo ($v['name']); ?>
                                        <input
                                                type="checkbox"
                                                name="rule_ids[]"
                                                value="<?php echo ($v['identifying']); ?>"
                                        <?php if(in_array($v['identifying'],$group_data)): ?>checked="checked"<?php endif; ?>
                                        onclick="checkAll(this)" />
                                    </label>
                                </th>

                                <td class="b-child">
                                    <?php if(is_array($v['children'])): foreach($v['children'] as $key=>$n): ?><table class="table table-striped table-bordered">
                                            <tr class="b-group">
                                                <th width="10%">
                                                    <label><?php echo ($n['name']); ?>
                                                        <input
                                                                type="checkbox"
                                                                name="rule_ids[]"
                                                                value="<?php echo ($n['identifying']); ?>"
                                                        <?php if(in_array($n['identifying'],$group_data)): ?>checked="checked"<?php endif; ?>
                                                        onclick="checkAll(this)" />
                                                    </label>
                                                </th>
                                                <td>
                                                    <?php if(!empty($n['data'])): if(is_array($n['data'])): $i = 0; $__LIST__ = $n['data'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$c): $mod = ($i % 2 );++$i;?><label><?php echo ($c['name']); ?>
                                                                <input
                                                                        type="checkbox"
                                                                        name="rule_ids[]"
                                                                        value="<?php echo ($c['identifying']); ?>"
                                                                <?php if(in_array($c['identifying'],$group_data)): ?>checked="checked"<?php endif; ?>
                                                                />
                                                            </label><?php endforeach; endif; else: echo "" ;endif; endif; ?>
                                                </td>
                                            </tr>
                                        </table><?php endforeach; endif; ?>
                                </td>
                            </tr><?php endif; endforeach; endif; ?>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default fui-close">关闭</button>
                <button type="button" class="btn btn-primary green" id="jurisdiction">保存</button>
            </div>
        </div>
    </div>
</form>
<script>
    function checkAll(obj) {
        $(obj).parents('.b-group').eq(0).find("input[type='checkbox']").prop('checked', $(obj).prop('checked'));
    }
</script>
<script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Role/jurisdiction.js"></script>
<!-- 结束 内容 块 -->