<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 CSS 页面级 插件 -->

<!-- 结束 CSS 页面级 插件 -->


    <div class="row <?php echo C('ANIMATED');?>">
        <div class="col-sm-12">
            <div class="table-toolbar">
                <div class="form-inline" role="form">
                    <form id="table_form">

                    </form>
                </div>
            </div>
            <div class="info" >
                <div id="show"></div>
            </div>

            <!--<div class="form-group fui-data-wrap">-->
                <!--<div class="form-inline">-->
                    <!--<div class="input-group">-->
                        <!--<select class="form-control" id="s_province" name="s_province"></select>  -->
                    <!--</div>-->
                    <!--<div class="input-group">-->
                        <!--<select class="form-control" id="s_city" name="s_city"></select>  -->
                    <!--</div>-->
                    <!--<div class="input-group">-->
                        <!--<select class="form-control" id="s_county" name="s_county"></select>  -->
                    <!--</div>-->
                <!--</div>-->
            <!--</div>-->


            <table id="tb_departments"></table>

        </div>
    </div>





<!-- 开始 JAVASCRIPT 页面级 插件 -->

<!-- 结束 JAVASCRIPT 页面级 插件 -->

<!-- 开始 JAVASCRIPT 页面级 代码 -->

    <script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Grade/index.js"></script>
    <!--<script type="text/javascript">_init_area();</script>-->
    <script type="text/javascript">

//        var Gid  = document.getElementById ;
//
//        var showArea = function(){
//
//            Gid('show').innerHTML = "<h3>省" + Gid('s_province').value + " - 市" +
//
//                    Gid('s_city').value + " - 县/区" +
//
//                    Gid('s_county').value + "</h3>"
//
//        };
//
//        Gid('s_county').setAttribute('onchange','showArea()');

    </script>


<!-- 结束 JAVASCRIPT 页面级 代码 -->