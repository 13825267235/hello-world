<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 内容 块 -->
<form id="layered_add_form" method="post" action="<?php echo U('Admin/Layered/addServe');?>">
    <div class="modal-dialog modal-full">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close fui-close" aria-hidden="true">&times;</button>
                <h4 class="modal-title font-green-sharp">消费还款记录</h4>
            </div>
            <div class="modal-body ">
                <div class="tabbable-line"  >
                    <ul class="nav nav-tabs">
                        <li class="active">
                            <a href="#portlet_settings_tab1" data-toggle="tab" aria-expanded="true"> 消费流水 </a>
                        </li>

                        <li>
                            <a href="#portlet_settings_tab2" data-toggle="tab" aria-expanded="false">还款流水 </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="portlet_settings_tab1">
                            <table class="table table-bordered table-striped Xui-table">
                                <tbody>
                                <tr>
                                    <th class="text-center col-md-2">期数</th>
                                    <th class="text-center col-md-2">金额</th>
                                    <th class="text-center col-md-2">还款时间</th>
                                    <th class="text-center col-md-2">还款状态</th>
                                </tr>
                                <notempry name="cost">
                                    <?php if(is_array($cost)): $i = 0; $__LIST__ = $cost;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
                                        <td class="text-center"><?php echo ($v["times"]); ?></td>
                                        <td class="text-center"><?php echo ($v["money"]); ?></td>
                                        <td class="text-center">
                                            <?php if($v["pay_time"] == 0): else: ?>
                                                <?php echo (date('Y-m-d H:i:s',$v["pay_time"])); endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <?php if($v["status"] == 0): ?><span class="caption-subject font-yellow-haze bold uppercase">未完成</span><?php endif; ?>
                                            <?php if($v["status"] == 1): ?><span class="caption-subject font-green-sharp bold uppercase">已完成</span><?php endif; ?>
                                            <?php if($v["status"] == 2): ?><span class="caption-subject  font-red-sunglo bold uppercase">失败</span><?php endif; ?>
                                        </td>
                                    </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                                </notempry>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane" id="portlet_settings_tab2">
                            <table class="table table-bordered table-striped Xui-table">
                                <tbody>
                                <tr>
                                    <th class="text-center col-md-2">期数</th>
                                    <th class="text-center col-md-2">金额</th>
                                    <th class="text-center col-md-2">还款时间</th>
                                    <th class="text-center col-md-2">还款状态</th>
                                </tr>
                                <notempry name="repay">
                                    <?php if(is_array($repay)): $i = 0; $__LIST__ = $repay;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
                                            <td class="text-center"><?php echo ($v["times"]); ?></td>
                                            <td class="text-center"><?php echo ($v["money"]); ?></td>
                                            <td class="text-center">
                                                <?php if($v["pay_time"] == 0): else: ?>
                                                    <?php echo (date('Y-m-d H:i:s',$v["pay_time"])); endif; ?>
                                            </td>
                                            <td class="text-center">
                                                <?php if($v["status"] == 0): ?><span class="caption-subject font-yellow-haze bold uppercase">未完成</span><?php endif; ?>
                                                <?php if($v["status"] == 1): ?><span class="caption-subject font-green-sharp bold uppercase">已完成</span><?php endif; ?>
                                                <?php if($v["status"] == 2): ?><span class="caption-subject  font-red-sunglo bold uppercase">失败</span><?php endif; ?>
                                            </td>
                                        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                                </notempry>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default fui-close">关闭</button>
                <!--<button type="submit" class="btn btn-primary green">保存</button>-->
            </div>
        </div>
    </div>

</form>

<!--<script type="text/javascript" src="<?php echo C('APP');?>Admin/Static/Layered/add.js"></script>-->

<!-- 结束 内容 块 -->