<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 内容 块 -->
<form id="sys_user_update_form" method="post" action="/<?php echo C('MODEL_NAME');?>/SysUser/serve">
    <input type="hidden" name="id" value="<?php echo ($id); ?>">
    <input type="hidden" name="action" value="update">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close fui-close" aria-hidden="true">&times;</button>
                <h4 class="modal-title font-green-sharp">修改会员</h4>
            </div>

            <div class="modal-body">
                <table class="table table-hover table-striped table-bordered Xui-table">
                    <tbody>
                    <tr>
                        <td class="text-right col-md-4">用户名：</td>
                        <td>
                            <p class="form-control-static">
                                <span style='color: #CC0000'><?php echo ($data['username']); ?></span>
                            </p>
                        </td>
                    </tr>
                    <?php if($data["is_admin"] == 1): ?><tr>
                            <td class="text-right">角色：</td>
                            <td>
                                <select class="form-control" name="role_id">
                                    <?php if(is_array($roleData)): $i = 0; $__LIST__ = $roleData;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>" <?php if($data['role_id'] == $vo["id"] ): ?>selected="selected"<?php endif; ?>><?php echo ($vo["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                                </select>
                            </td>
                        </tr><?php endif; ?>
                    <tr>
                        <td class="text-right">原始密码：</td>
                        <td>
                            <input type="password" name="oldpwd" class="form-control"
                                   placeholder="置空,为不修改"
                                   datatype="*0-32"
                                   errormsg="密码 最长只能是32个字符"
                                   data-plugin-type="tooltip"
                                   title="<span style='color: #CC0000'>密码</span>置空,为不修改,最长只能是32个字符~！">
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">新密码：</td>
                        <td>
                            <input type="password" name="password" class="form-control"
                                   placeholder="置空,为不修改"
                                   datatype="*0-32"
                                   errormsg="密码 最长只能是32个字符"
                                   data-plugin-type="tooltip"
                                   title="<span style='color: #CC0000'>密码</span>置空,为不修改,最长只能是32个字符~！">
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default fui-close">关闭</button>
                <button type="submit" class="btn btn-primary green">保存</button>
            </div>
        </div>
    </div>
</form>
<script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/SysUser/update.js"></script>
<!-- 结束 内容 块 -->