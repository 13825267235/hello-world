<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 内容 块 -->
<form id="user_form" method="post" action="/<?php echo C('MODEL_NAME');?>/User/addServe">
    <div class="modal-dialog modal-full">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close fui-close" aria-hidden="true">&times;</button>
                <h4 class="modal-title font-green-sharp">新增会员</h4>
            </div>
            <div class="modal-body">
                <table class="table table-hover table-striped table-bordered Xui-table">
                    <tbody>
                    <tr>
                        <th class="text-right col-md-3"><span class="text-danger">*</span>用户名：</th>
                        <td>
                            <input
                                    type="text"
                                    name="username"
                                    class="form-control"
                                    placeholder="请输入用户名"
                                    nullmsg="请输入用户名"
                                    ajaxurl="<?php echo U('Admin/User/inspectUsername');?>"
                                    datatype="*1-32"
                                    errormsg="用户名,最长只能是32个字符">

                        </td>
                        <th class="text-right col-md-3">指定代理：</th>
                        <td>
                            <select name="parent_id" class="form-control select2-allow-clear" data-plugin-type="select2">
                                <option value="">无</option>
                                <?php if(is_array($dlUserData)): $i = 0; $__LIST__ = $dlUserData;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo['id']); ?>"><?php echo ($vo['username']); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <th class="text-right"><span class="text-danger">*</span>密码：</th>
                        <td>
                            <input
                                    type="text"
                                    name="password"
                                    class="form-control"
                                    value="123456"
                                    placeholder="请输入密码"
                                    nullmsg="请输入密码"
                                    datatype="*1-32"
                                    errormsg="密码 最长只能是32个字符"
                                    data-plugin-type="tooltip"
                                    title="<span style='color: #CC0000'>密码</span>置空,默认就是123456,最长只能是32个字符~！">
                        </td>
                        <th class="text-right">账号类型：</th>
                        <td>
                            <label>
                                <input type="radio" name="type" class="icheck" value="0" data-plugin-type="icheck" checked>
                                会员
                            </label>
                            <label>
                                <input type="radio" name="type" class="icheck" value="1" data-plugin-type="icheck" >
                                代理
                            </label>
                        </td>
                    </tr>

                    <tr>
                        <th class="text-right">会员姓名：</th>
                        <td>
                            <input type="text" name="name" class="form-control">
                        </td>
                        <th class="text-right">电话：</th>
                        <td>
                            <input type="text" name="phone" class="form-control">
                        </td>
                    </tr>

                    <tr>
                        <th class="text-right">邮箱：</th>
                        <td>
                            <input type="text" name="em" class="form-control">
                        </td>
                        <th class="text-right">QQ：</th>
                        <td>
                            <input type="text"  name="qq"class="form-control">
                        </td>
                    </tr>

                    <tr>
                        <th class="text-right">微信：</th>
                        <td>
                            <input type="text"  name="wx" class="form-control">
                        </td>
                        <th class="text-right">开户行：</th>
                        <td>
                            <select name="bank_id" class="form-control select2-allow-clear" data-plugin-type="select2">
                                <option value="">无</option>
                                <?php if(is_array($bankModel)): $i = 0; $__LIST__ = $bankModel;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo['id']); ?>"><?php echo ($vo['bank_name']); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                            </select>
                        </td>
                    </tr>

                    <tr>
                        <th class="text-right">银行地址：</th>
                        <td>
                            <input type="text" name="countname" class="form-control">
                        </td>
                        <th class="text-right">银行卡卡号：</th>
                        <td>
                            <input type="number" name="account" class="form-control">
                        </td>
                    </tr>

                    <tr>
                        <th class="text-right">会员状态：</th>
                        <td >
                            <label>
                                <input type="radio" name="enable" class="icheck" value="0" data-plugin-type="icheck" checked>
                                开启
                            </label>
                            <label>
                                <input type="radio" name="enable" class="icheck" value="1" data-plugin-type="icheck">
                                禁用
                            </label>
                        </td>
                        <th class="text-right">会员等级：</th>
                        <td >
                            <select name="grade" class="form-control select2-allow-clear" data-plugin-type="select2">
                                <?php if(is_array($layered)): $i = 0; $__LIST__ = $layered;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; if($vo["is_default"] == 0): ?><option value="<?php echo ($vo['id']); ?>">默认<?php echo ($vo['name']); ?></option><?php endif; ?>
                                    <option value="<?php echo ($vo['id']); ?>"><?php echo ($vo['name']); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                            </select>
                        </td>
                    </tr>

                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default fui-close">关闭</button>
                <button type="submit" class="btn btn-primary green">保存</button>
            </div>
        </div>
    </div>
</form>


<script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/User/add.js"></script>
<!-- 结束 内容 块 -->