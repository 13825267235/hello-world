<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 CSS 页面级 插件 -->

<!-- 结束 CSS 页面级 插件 -->


    <div class="row <?php echo C('ANIMATED');?>">
        <div class="col-sm-12">
            <div class="table-toolbar">
                <div class="form-inline" role="form">
                    <form id="table_sys_user_form">

                        <?php if(in_array('SysUser_add',$userInfo)): ?><div class="form-group">
                                <button class="btn green" type="button" id="sys_user_add">
                                    新增用户 <i class="fa fa-plus"></i>
                                </button>
                            </div><?php endif; ?>
                        <!--<div class="form-group pull-right">-->
                            <!--<div class="input-icon right">-->
                                <!--<i class="icon-magnifier" id="SysUserSearchButt"></i>-->
                                <!--<input type="text" class="form-control input-circle" name="search" placeholder="用户名">-->
                            <!--</div>-->
                        <!--</div>-->
                    </form>
                </div>
            </div>
            <table id="tb_sys_user_departments"></table>

        </div>
    </div>


<!-- 开始 JAVASCRIPT 页面级 插件 -->

<!-- 结束 JAVASCRIPT 页面级 插件 -->

<!-- 开始 JAVASCRIPT 页面级 代码 -->

    <script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/SysUser/index.js"></script>

<!-- 结束 JAVASCRIPT 页面级 代码 -->