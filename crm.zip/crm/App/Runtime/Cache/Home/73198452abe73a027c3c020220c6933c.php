<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 内容 块 -->
<form id="sys_user_update_form" method="post" action="/<?php echo C('MODEL_NAME');?>/User/updateServe">
    <input type="hidden" name="id" value="<?php echo ($id); ?>">
    <input type="hidden" name="action" value="update">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close fui-close" aria-hidden="true">&times;</button>
                <h4 class="modal-title font-green-sharp">修改会员</h4>
            </div>

            <div class="modal-body">
                <table class="table table-hover table-striped table-bordered Xui-table">
                    <tbody>
                    <input name="username" value="<?php echo ($data['username']); ?>" type="hidden">
                    <tr>
                        <td class="text-right col-md-4">用户名：</td>
                        <td>
                            <p class="form-control-static">
                                <span style='color: #CC0000'><?php echo ($data['username']); ?></span>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">新密码：</td>
                        <td>
                            <input type="password" name="password" class="form-control"
                                   placeholder="置空,为不修改(6-15位数字或者字母)"
                                   datatype="*0-15"
                                   errormsg="密码 最长只能是15个字符"
                                   data-plugin-type="tooltip"
                                   title="<span style='color: #CC0000'>密码</span>置空,为不修改,最长只能是15个字符~！">
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default fui-close">关闭</button>
                <button type="submit" class="btn btn-primary green">保存</button>
            </div>
        </div>
    </div>
</form>
<script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/SysUser/update.js"></script>
<!-- 结束 内容 块 -->