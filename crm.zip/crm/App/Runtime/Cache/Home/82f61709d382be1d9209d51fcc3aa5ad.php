<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 内容 块 -->
<form id="sys_user_update_form" method="post" action="/<?php echo C('MODEL_NAME');?>/SysUser/serve">
    <input type="hidden" name="action" value="add">
    <div class="modal-dialog ">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close fui-close" aria-hidden="true">&times;</button>
                <h4 class="modal-title font-green-sharp">新增</h4>
            </div>

            <div class="modal-body">
                <table class="table table-hover table-striped table-bordered Xui-table">
                    <tbody>
                    <tr>
                        <td class="text-right col-md-4">用户名：</td>
                        <td>
                            <input
                                    type="text"
                                    name="username"
                                    class="form-control"
                                    placeholder="请输入用户名"
                                    ajaxurl="/<?php echo C('MODEL_NAME');?>/SysUser/inspectUsername"
                                    nullmsg="请输入用户名"
                                    datatype="*1-32"
                                    errormsg="用户名,最长只能是32个字符">
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">密码：</td>
                        <td>
                            <input type="password" name="password" class="form-control"
                                   placeholder="请输入密码"
                                   datatype="*1-32"
                                   nullmsg="请输入密码"
                                   errormsg="密码，最少1位，最长只能是32个字符"
                                   data-plugin-type="tooltip"
                                   title="<span style='color: #CC0000'>密码</span>置空,为不修改,最长只能是32个字符~！">
                        </td>
                    </tr>
                    <tr>
                        <td class="text-right">角色：</td>
                        <td>
                            <select class="form-control" name="role_id">
                                <?php if(is_array($roleData)): $i = 0; $__LIST__ = $roleData;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>"><?php echo ($vo["name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                            </select>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-default fui-close">关闭</button>
                <button type="submit" class="btn btn-primary green">保存</button>
            </div>
        </div>
    </div>
</form>
<script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/SysUser/add.js"></script>
<!-- 结束 内容 块 -->