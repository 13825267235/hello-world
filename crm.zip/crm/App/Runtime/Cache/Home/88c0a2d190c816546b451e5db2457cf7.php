<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 CSS 页面级 插件 -->

<!-- 结束 CSS 页面级 插件 -->

    <div class="row <?php echo C('ANIMATED');?>">
        <div class="col-sm-12">
            <table class="table table-bordered table-striped Xui-table">
                <tbody>
                <tr>
                    <th class="text-right col-md-3">会员分层：</th>
                    <td class="col-md-9">
                        <select id="pushmode" class="form-control">
                            <option value="1" selected="selected">全部会员</option>
                            <!--<option value="2">指定会员</option>-->
                            <!--<option value="3">指定分层</option>-->
                        </select>
                    </td>
                </tr>
                <tr class="modetype modetypezdhy" style="display:none;">
                    <th class="text-right col-md-3">指定会员：</th>
                    <td>
                        <select id="user_data" multiple="multiple" class="form-control"></select>
                    </td>
                </tr>
                <tr class="modetype modetypezdfc" style="display:none;">
                    <th class="text-right col-md-3">指定分层：</th>
                    <td>
                        <select name="gradesss" id="gradesss" class="form-control">
                            <?php if(is_array($infoData)): $i = 0; $__LIST__ = $infoData;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["grade"]); ?>"><?php echo ($vo["grade_name"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th class="text-right col-md-3">方式：</th>
                    <td>
                        <label>
                            <input type="radio" name="types" class="icheck types" value="0" data-plugin-type="icheck" checked>
                            站内消息
                        </label>
                        <label>
                            <input type="radio" name="types" class="icheck types" value="1" data-plugin-type="icheck" >
                            弹窗消息
                        </label>
                    </td>
                </tr>
                <!--<tr>-->
                    <!--<th class="text-right col-md-3">过期时间（天）：</th>-->
                    <!--<td>-->
                        <!--<input type="number" class="form-control" name="overdue_time" placeholder="填写过期时间,不填则为不过期" id="overdue_time">-->
                    <!--</td>-->
                <!--</tr>-->
                <tr>
                    <th class="text-right col-md-3">标题：</th>
                    <td>
                        <input id="titles" class="form-control" >
                    </td>
                </tr>
                <tr>
                    <th class="text-right col-md-3">内容：</th>
                    <td>
                        <textarea id="contents" class="form-control" rows="5"></textarea>
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary green" id="sendoutss">发送</button>
                        </div>
                    </td>
                </tr>
                </tbody>
            </table>
            <table id="tb_Push_departments"></table>
        </div>
    </div>


<!-- 开始 JAVASCRIPT 页面级 插件 -->

<!-- 结束 JAVASCRIPT 页面级 插件 -->

<!-- 开始 JAVASCRIPT 页面级 代码 -->

    <script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Push/index.js"></script>

<!-- 结束 JAVASCRIPT 页面级 代码 -->