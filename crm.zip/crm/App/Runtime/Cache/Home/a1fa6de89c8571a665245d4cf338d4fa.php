<?php if (!defined('THINK_PATH')) exit();?><form id="user_see_form" method="post" action="">
    <div class="modal-dialog modal-full">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close fui-close" aria-hidden="true">&times;</button>
                <h4 class="modal-title font-green-sharp">会员详情</h4>
            </div>
            <div class="modal-body">
                <div class="tabbable-line"  >
                    <ul class="nav nav-tabs">
                        <li class="active">
                            <a href="#portlet_settings_tab0" data-toggle="tab" aria-expanded="true"> 用户信息 </a>
                        </li>

                        <li>
                            <a href="#portlet_settings_tab1" data-toggle="tab" aria-expanded="false">大掌柜 </a>
                        </li>
                        <li>
                            <a href="#portlet_settings_tab2" data-toggle="tab" aria-expanded="false">二掌柜 </a>
                        </li>
                        <li>
                            <a href="#portlet_settings_tab3" data-toggle="tab" aria-expanded="false">三掌柜 </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="portlet_settings_tab0">
                            <table class="table table-hover table-striped table-bordered Xui-table">
                                <tbody>
                                <tr>
                                    <th class="text-right col-md-3">用户名：</th>
                                    <td><?php echo ($data['username']); ?></td>
                                    <th class="text-right col-md-2">推荐人：</th>
                                    <td>
                                        <?php if($data["parent_id"] == 0): ?>无
                                            <?php else: ?>
                                            <?php echo ($data['parent_id']); endif; ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="text-right ">等级：</th>
                                    <td><?php echo ($data['grade_name']); ?></td>

                                    <th class="text-right">昵称：</th>
                                    <td><?php echo ($data['nickname']); ?></td>
                                </tr>
                                <tr>
                                    <th class="text-right">注册时间：</th>
                                    <td colspan="3">
                                        <?php echo (date('Y-m-d H:i:s',$data['create_time'])); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="text-right ">注册ip：</th>
                                    <td><?php echo ($data['reg_ip']); ?></td>
                                    <th class="text-right">用户状态：</th>
                                    <td>
                                        <?php if($data["enable"] == 0): ?>开启
                                            <?php else: ?>
                                            禁止<?php endif; ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td class="text-center" colspan="4">
                                        实名认证信息
                                    </td>
                                </tr>
                                <tr>
                                    <th class="text-right">真实姓名：</th>
                                    <td colspan="3"><?php echo ($data["realname"]); ?></td>
                                </tr>
                                <tr>
                                    <th class="text-right">身份证号：</th>
                                    <td colspan="3"><?php echo ($data["ic"]); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="text-right">银行名称：</th>
                                    <td colspan="3"> <?php echo ($data["bank_name"]); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="text-right">银行卡号</th>
                                    <td colspan="3"> <?php echo ($data["account"]); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="text-right">开户地址：</th>
                                    <td colspan="3"> <?php echo ($data["countname"]); ?>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="text-right">预留电话：</th>
                                    <td colspan="3"> <?php echo ($data["phone"]); ?>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane" id="portlet_settings_tab1">
                            <table class="table table-bordered table-striped Xui-table">
                                <tbody>
                                <tr>
                                    <th class="text-center col-md-2">帐号id</th>
                                    <th class="text-center col-md-2">帐号名</th>
                                    <th class="text-center col-md-2">等级</th>
                                    <th class="text-center col-md-2">分润金额</th>
                                </tr>
                                <notempry name="one">
                                    <?php if(is_array($one)): $i = 0; $__LIST__ = $one;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
                                            <td class="text-center"><?php echo ($v["id"]); ?></td>
                                            <td class="text-center"><?php echo ($v["username"]); ?></td>
                                            <td class="text-center"><?php echo ($v["grade_name"]); ?></td>
                                            <td class="text-center"><?php echo ($v["fenrun"]); ?></td>
                                        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                                </notempry>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane" id="portlet_settings_tab2">
                            <table class="table table-bordered table-striped Xui-table">
                                <tbody>
                                <tr>
                                    <th class="text-center col-md-2">帐号id</th>
                                    <th class="text-center col-md-2">帐号名</th>
                                    <th class="text-center col-md-2">等级</th>
                                    <th class="text-center col-md-2">分润金额</th>
                                </tr>
                                <notempry name="two">
                                    <?php if(is_array($two)): $i = 0; $__LIST__ = $two;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
                                            <td class="text-center"><?php echo ($v["id"]); ?></td>
                                            <td class="text-center"><?php echo ($v["username"]); ?></td>
                                            <td class="text-center"><?php echo ($v["grade_name"]); ?></td>
                                            <td class="text-center"><?php echo ($v["fenrun"]); ?></td>
                                        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                                </notempry>
                                </tbody>
                            </table>
                        </div>
                        <div class="tab-pane" id="portlet_settings_tab3">
                            <table class="table table-bordered table-striped Xui-table">
                                <tbody>
                                <tr>
                                    <th class="text-center col-md-2">帐号id</th>
                                    <th class="text-center col-md-2">帐号名</th>
                                    <th class="text-center col-md-2">等级</th>
                                    <th class="text-center col-md-2">分润金额</th>
                                </tr>
                                <notempry name="three">
                                    <?php if(is_array($three)): $i = 0; $__LIST__ = $three;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><tr>
                                            <td class="text-center"><?php echo ($v["id"]); ?></td>
                                            <td class="text-center"><?php echo ($v["username"]); ?></td>
                                            <td class="text-center"><?php echo ($v["grade_name"]); ?></td>
                                            <td class="text-center"><?php echo ($v["fenrun"]); ?></td>
                                        </tr><?php endforeach; endif; else: echo "" ;endif; ?>
                                </notempry>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default fui-close">关闭</button>
            </div>
        </div>
    </div>
</form>