<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 CSS 页面级 插件 -->



<!-- 结束 CSS 页面级 插件 -->


    <div class="row <?php echo C('ANIMATED');?>">
        <div class="col-sm-12">
            <div class="table-toolbar">
                <div class="form-inline" role="form">
                    <form id="table_res_form">
                        <div class="form-group">
                            <button class="btn green" type="button" id="RES_ADD">
                                新增菜单 <i class="fa fa-plus"></i>
                            </button>
                        </div>
                        <div class="form-group pull-right">
                            <form id="table_datas_form"></form>
                        </div>
                    </form>
                </div>
            </div>
            <table id="tb_res_departments"></table>
        </div>
    </div>


<!-- 开始 JAVASCRIPT 页面级 插件 -->



<!-- 结束 JAVASCRIPT 页面级 插件 -->

<!-- 开始 JAVASCRIPT 页面级 代码 -->

    <script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Res/index.js"></script>

<!-- 结束 JAVASCRIPT 页面级 代码 -->