<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 CSS 页面级 插件 -->



<!-- 结束 CSS 页面级 插件 -->


    <div class="row <?php echo C('ANIMATED');?>">
        <div class="col-sm-12">
            <div class="table-toolbar">
                <div class="form-inline" role="form">

                    <form id="table_role_form">
                        <?php if(in_array('Role_add',$userInfo)): ?><div class="form-group">
                            <button class="btn green" type="button" id="Role_add">
                                新增角色 <i class="fa fa-plus"></i>
                            </button>
                        </div><?php endif; ?>
                    </form>

                </div>
            </div>
            <table id="tb_role_departments"></table>
        </div>
    </div>


<!-- 开始 JAVASCRIPT 页面级 插件 -->



<!-- 结束 JAVASCRIPT 页面级 插件 -->

<!-- 开始 JAVASCRIPT 页面级 代码 -->

    <script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Role/index.js"></script>

<!-- 结束 JAVASCRIPT 页面级 代码 -->