<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 CSS 页面级 插件 -->



<!-- 结束 CSS 页面级 插件 -->


    <div class="row <?php echo C('ANIMATED');?>">
        <div class="col-sm-12">

            <div class="tabbable-line">
                <ul class="nav nav-tabs">
                    <li class="active">
                        <a href="#portlet_settings_tab1" data-toggle="tab" aria-expanded="true"> 网站配置 </a>
                    </li>
                </ul>
                <div class="tab-content">

                    <div class="tab-pane active" id="portlet_settings_tab1">
                        <table class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <td style="width:15%" class="text-center"><strong> 客服电话 </strong></td>
                                    <td style="width:50%">
                                        <a href="javascript:;" id="webname" name="web_phone" data-value="<?php echo ($data["web_phone"]); ?>"></a>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <!--<div class="form-body">

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label font-green-sharp"><strong>网站名称：</strong></label>
                                        <input type="text" placeholder="small" class="form-control" name="CONFIG_WEB_NAME" value="<?php echo C('CONFIG_WEB_NAME');?>">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="control-label font-green-sharp"><strong>网站开关：</strong></label>
                                        <div class="icheck-inline">
                                            <label>
                                                <input type="radio" name="CONFIG_WEB_SWITCH" class="icheck" value="1" data-plugin-type="icheck" <?php if(C('CONFIG_WEB_SWITCH')==1) echo 'checked'; ?>>
                                                开
                                            </label>
                                            <label>
                                                <input type="radio" name="CONFIG_WEB_SWITCH" class="icheck" value="0" data-plugin-type="icheck" <?php if(C('CONFIG_WEB_SWITCH')==0) echo 'checked'; ?>>
                                                关
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label font-green-sharp"><strong>LOG：</strong></label>
                                        <input type="hidden" name="CONFIG_LOG" id="LOG">
                                        <input type="file" name="logs"  multiple class="file-loading myfile" />
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label font-green-sharp"><strong>首页公告：</strong></label>
                                        <script id="kjnotice1" name="CONFIG_HOME_BULLETIN" type="text/plain"><?php echo htmlspecialchars_decode(C('CONFIG_HOME_BULLETIN'));?></script>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label font-green-sharp"><strong>网站关闭公告：</strong></label>
                                        <script id="web_close_service_result" name="CONFIG_WEB_CLOSE_SERVICE_RESULT" type="text/plain"><?php echo htmlspecialchars_decode(C('CONFIG_WEB_CLOSE_SERVICE_RESULT')); ?></script>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label font-green-sharp"><strong>滚动公告：</strong></label>
                                        <script id="web_gg" name="CONFIG_WEB_GG" type="text/plain"><?php echo htmlspecialchars_decode(C('CONFIG_WEB_GG')); ?></script>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label font-green-sharp"><strong>中奖公告：</strong></label>
                                        <script id="kjnotice" name="CONFIG_WINNING_BULLETIN" type="text/plain"><?php echo htmlspecialchars_decode(C('CONFIG_WINNING_BULLETIN')); ?></script>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="control-label font-green-sharp"><strong>平台简介：</strong></label>
                                        <script id="kjnotice2" name="CONFIG_PLATFORM_INTRODUCTION" type="text/plain"><?php echo htmlspecialchars_decode(C('CONFIG_PLATFORM_INTRODUCTION')); ?></script>
                                    </div>
                                </div>
                            </div>

                        </div>-->
                    </div>

                </div>
            </div>

            <!--<div class="portlet light bordered">

                <div class="portlet-title tabbable-line">

                    <div class="caption ">

                    </div>
                    <ul class="nav nav-tabs">
                    <li class="active">
                        <a href="#portlet_settings_tab1" data-toggle="tab" aria-expanded="true"> 网站设置 </a>
                    </li>

                    <li>
                        <a href="#portlet_settings_tab2" data-toggle="tab" aria-expanded="false"> 投注设置 </a>
                    </li>
                    <li>
                        <a href="#portlet_settings_tab3" data-toggle="tab" aria-expanded="false"> 提现/充值/返点 </a>
                    </li>
                    <li>
                        <a href="#portlet_settings_tab4" data-toggle="tab" aria-expanded="false"> 活动设置 </a>
                    </li>
                </ul>
                </div>

                <div class="portlet-body form">

                    <form action="<?php echo U('Admin/Settings/serve');?>" class="horizontal-form" method="post" id="settings_form">

                        <div class="tab-content">

                            <div class="tab-pane active" id="portlet_settings_tab1">
                                <div class="form-body">

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>网站名称：</strong></label>
                                                <input type="text" placeholder="small" class="form-control" name="CONFIG_WEB_NAME" value="<?php echo C('CONFIG_WEB_NAME');?>">
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>网站开关：</strong></label>
                                                <div class="icheck-inline">
                                                    <label>
                                                        <input type="radio" name="CONFIG_WEB_SWITCH" class="icheck" value="1" data-plugin-type="icheck" <?php if(C('CONFIG_WEB_SWITCH')==1) echo 'checked'; ?>>
                                                        开
                                                    </label>
                                                    <label>
                                                        <input type="radio" name="CONFIG_WEB_SWITCH" class="icheck" value="0" data-plugin-type="icheck" <?php if(C('CONFIG_WEB_SWITCH')==0) echo 'checked'; ?>>
                                                        关
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>LOG：</strong></label>
                                                <input type="hidden" name="CONFIG_LOG" id="LOG">
                                                <input type="file" name="logs"  multiple class="file-loading myfile" />
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>首页公告：</strong></label>
                                                <script id="kjnotice1" name="CONFIG_HOME_BULLETIN" type="text/plain"><?php echo htmlspecialchars_decode(C('CONFIG_HOME_BULLETIN'));?></script>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>网站关闭公告：</strong></label>
                                                <script id="web_close_service_result" name="CONFIG_WEB_CLOSE_SERVICE_RESULT" type="text/plain"><?php echo htmlspecialchars_decode(C('CONFIG_WEB_CLOSE_SERVICE_RESULT')); ?></script>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>滚动公告：</strong></label>
                                                <script id="web_gg" name="CONFIG_WEB_GG" type="text/plain"><?php echo htmlspecialchars_decode(C('CONFIG_WEB_GG')); ?></script>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>中奖公告：</strong></label>
                                                <script id="kjnotice" name="CONFIG_WINNING_BULLETIN" type="text/plain"><?php echo htmlspecialchars_decode(C('CONFIG_WINNING_BULLETIN')); ?></script>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>平台简介：</strong></label>
                                                <script id="kjnotice2" name="CONFIG_PLATFORM_INTRODUCTION" type="text/plain"><?php echo htmlspecialchars_decode(C('CONFIG_PLATFORM_INTRODUCTION')); ?></script>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="tab-pane" id="portlet_settings_tab2">
                                <div class="form-body">

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>总投注开关：</strong></label>
                                                <div class="icheck-inline">
                                                    <label>
                                                        <input type="radio" name="CONFIG_SWITCH_BUY" class="icheck" value="1" data-plugin-type="icheck" <?php if(C('CONFIG_SWITCH_BUY')==1) echo 'checked'; ?>>
                                                        开
                                                    </label>
                                                    <label>
                                                        <input type="radio" name="CONFIG_SWITCH_BUY" class="icheck" value="0" data-plugin-type="icheck" <?php if(C('CONFIG_SWITCH_BUY')==0) echo 'checked'; ?>>
                                                        关
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>代理投注开关：</strong></label>
                                                <div class="icheck-inline">
                                                    <label>
                                                        <input type="radio" name="CONFIG_SWITCH_DL_BUY" class="icheck" value="1" data-plugin-type="icheck" <?php if(C('CONFIG_SWITCH_DL_BUY')==1) echo 'checked'; ?>>
                                                        开
                                                    </label>
                                                    <label>
                                                        <input type="radio" name="CONFIG_SWITCH_DL_BUY" class="icheck" value="0" data-plugin-type="icheck" <?php if(C('CONFIG_SWITCH_DL_BUY')==0) echo 'checked'; ?>>
                                                        关
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>总代投注开关：</strong></label>
                                                <div class="icheck-inline">
                                                    <label>
                                                        <input type="radio" name="CONFIG_SWITCH_ZDL_BUY" class="icheck" value="1" data-plugin-type="icheck" <?php if(C('CONFIG_SWITCH_ZDL_BUY')==1) echo 'checked'; ?>>
                                                        开
                                                    </label>
                                                    <label>
                                                        <input type="radio" name="CONFIG_SWITCH_ZDL_BUY" class="icheck" value="0" data-plugin-type="icheck" <?php if(C('CONFIG_SWITCH_ZDL_BUY')==0) echo 'checked'; ?>>
                                                        关
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>上级充值开关：</strong></label>
                                                <div class="icheck-inline">
                                                    <label>
                                                        <input type="radio" name="CONFIG_RECHARGE" class="icheck" value="1" data-plugin-type="icheck" <?php if(C('CONFIG_RECHARGE')==1) echo 'checked'; ?>>
                                                        开
                                                    </label>
                                                    <label>
                                                        <input type="radio" name="CONFIG_RECHARGE" class="icheck" value="0" data-plugin-type="icheck" <?php if(C('CONFIG_RECHARGE')==0) echo 'checked'; ?>>
                                                        关
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>投注记录开关：</strong></label>
                                                <div class="icheck-inline">
                                                    <label>
                                                        <input type="radio" name="CONFIG_TZJL" class="icheck" value="1" data-plugin-type="icheck" <?php if(C('CONFIG_TZJL')==1) echo 'checked'; ?>>
                                                        开
                                                    </label>
                                                    <label>
                                                        <input type="radio" name="CONFIG_TZJL" class="icheck" value="0" data-plugin-type="icheck" <?php if(C('CONFIG_TZJL')==0) echo 'checked'; ?>>
                                                        关
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group has-error">
                                                <label class="control-label font-green-sharp"><strong>投注模式：</strong></label>
                                                <div class="icheck-inline">
                                                    <label>
                                                        <input type="checkbox" name="CONFIG_YUANMOSI" class="icheck" value="1" data-plugin-type="icheck" <?php if(C('CONFIG_YUANMOSI')==1) echo 'checked'; ?>>
                                                        元
                                                    </label>
                                                    <label>
                                                        <input type="checkbox" name="CONFIG_JIAOMOSI" class="icheck" value="0" data-plugin-type="icheck" <?php if(C('CONFIG_JIAOMOSI')==1) echo 'checked'; ?>>
                                                        角
                                                    </label>
                                                    <label>
                                                        <input type="checkbox" name="CONFIG_FENMOSI" class="icheck" value="0" data-plugin-type="icheck" <?php if(C('CONFIG_FENMOSI')==1) echo 'checked'; ?>>
                                                        分
                                                    </label>
                                                    <label>
                                                        <input type="checkbox" name="CONFIG_LIMOSI" class="icheck" value="0" data-plugin-type="icheck" <?php if(C('CONFIG_LIMOSI')==1) echo 'checked'; ?>>
                                                        厘
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <h3 class="form-section">最大投注/中奖限制</h3>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>最大注数：</strong></label>
                                                <input type="text" class="form-control" name="CONFIG_BET_MAX_COUNT">
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>最大中奖：</strong></label>
                                                <input type="text" class="form-control" name="CONFIG_BET_MAX_ZJ_AMOUNT">
                                            </div>
                                        </div>
                                    </div>

                                    <h3 class="form-section">系统彩种利润</h3>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>最大投注限制：</strong></label>
                                                <div class="icheck-inline">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">当期投注人数小于</span>
                                                        <input type="text" class="form-control" name="CONFIG_LI_RUNCOUNT" value="<?php echo C('CONFIG_LI_RUNCOUNT');?>">
                                                        <span class="input-group-addon">人则随机出号，否则利率开奖</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>系统彩种利润：</strong></label>
                                                <div class="icheck-inline">
                                                    <label>
                                                        <input type="radio" name="CONFIG_LI_RUN_LV" class="icheck" value="2" data-plugin-type="icheck" <?php if(C('CONFIG_LI_RUN_LV')==2) echo 'checked'; ?>>
                                                        高
                                                    </label>
                                                    <label>
                                                        <input type="radio" name="CONFIG_LI_RUN_LV" class="icheck" value="0" data-plugin-type="icheck" <?php if(C('CONFIG_LI_RUN_LV')==0) echo 'checked'; ?>>
                                                        低
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="tab-pane" id="portlet_settings_tab3">
                                <div class="form-body">

                                    <h3 class="form-section"><strong>提现规则设置</strong></h3>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>提现时消费必须满：</strong></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="CONFIG_CASH_MIN_AMOUNT" value="<?php echo C('CONFIG_CASH_MIN_AMOUNT');?>">
                                                    <span class="input-group-addon">%</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>规定的提现时间段：</strong></label>
                                                <div class="input-group">
                                                    <span class="input-group-addon">从</span>
                                                    <input type="text" class="form-control timepicker timepicker-24" ng-model="model.StartTime" name="CONFIG_CASHA_FROM_TIME" value="<?php echo C('CONFIG_CASHA_FROM_TIME');?>">
                                                    <span class="input-group-addon">到</span>
                                                    <input type="text" class="form-control timepicker timepicker-24" name="CONFIG_CASH_TO_TIME" value="<?php echo C('CONFIG_CASH_TO_TIME');?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>提现时最低金额必须：</strong></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" data-touchspin-money="money" name="CONFIG_CASH_MIN" value="<?php echo C('CONFIG_CASH_MIN');?>">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>提现时最高金额：</strong></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" data-touchspin-money="money" name="CONFIG_CASH_MAX" value="<?php echo C('CONFIG_CASH_MAX');?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <h3 class="form-section"><strong>充值规则设置</strong></h3>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>最低金额：</strong></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control " data-touchspin-money="money" name="CONFIG_RECHARGE_MIN" value="<?php echo C('CONFIG_RECHARGE_MIN');?>" >
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>最高金额：</strong></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control " data-touchspin-money="money" name="CONFIG_RECHARGE_MAX" value="<?php echo C('CONFIG_RECHARGE_MAX');?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <h3 class="form-section"><strong>返点规则设置</strong></h3>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>返点最大值：</strong></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="CONFIG_FAN_DIAN_MAX" value="<?php echo C('CONFIG_FAN_DIAN_MAX');?>">
                                                    <span class="input-group-addon">%</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>返点最小值：</strong></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="CONFIG_FAN_DIAN_MIN" value="<?php echo C('CONFIG_FAN_DIAN_MIN');?>">
                                                    <span class="input-group-addon">%</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>最大返点限制，元模式：</strong></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="CONFIG_BET_MODE_MAX_FAN_DIAN_YUAN" value="<?php echo C('CONFIG_BET_MODE_MAX_FAN_DIAN_YUAN');?>">
                                                    <span class="input-group-addon">%</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>最大返点限制，角模式：</strong></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="CONFIG_BET_MODE_MAX_FAN_DIAN_JIAO" value="<?php echo C('CONFIG_BET_MODE_MAX_FAN_DIAN_JIAO');?>">
                                                    <span class="input-group-addon">%</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>最大返点限制，分模式：</strong></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="CONFIG_BET_MODE_MAX_FAN_DIAN1_FEN" value="<?php echo C('CONFIG_BET_MODE_MAX_FAN_DIAN1_FEN');?>">
                                                    <span class="input-group-addon">%</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>最大返点限制，厘模式：</strong></label>
                                                <div class="input-group">
                                                    <input type="text" class="form-control" name="CONFIG_BET_MODE_MAX_FAN_DIAN_LI" value="<?php echo C('CONFIG_BET_MODE_MAX_FAN_DIAN_LI');?>">
                                                    <span class="input-group-addon">%</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="tab-pane" id="portlet_settings_tab4">
                                <div class="form-body">

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>绑定银行赠送活动：</strong></label>
                                                <input type="text"  class="form-control" name="CONFIG_HUO_DONG_REISTER"
                                                       data-plugin-type="tooltip"
                                                       title="首次注册绑定工行送N元，如果为0则关闭活动"
                                                       value="<?php echo C('CONFIG_HUO_DONG_REISTER');?>"
                                                >
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>每天签到赠送活动：</strong></label>
                                                <input type="text" class="form-control"  name="CONFIG_HUO_DONG_SIGN"
                                                       data-plugin-type="tooltip"
                                                       title="每天签到每次送N元，如果为0则关闭活动"
                                                       value="<?php echo C('CONFIG_HUO_DONG_SIGN');?>"
                                                >
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>充值赠送活动：</strong></label>
                                                <input type="text" class="form-control"  name="CONFIG_CZZS" id="czzs"
                                                       data-plugin-type="tooltip"
                                                       title="每次充值赠送活动N%，如果为0则关闭活动"
                                                       value="<?php echo C('CONFIG_CZZS');?>">
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="control-label font-green-sharp"><strong>注册赠送活动：</strong></label>
                                                <input type="text" class="form-control"  name="CONFIG_ZCZS"
                                                       data-plugin-type="tooltip"
                                                       title="注册赠送活动N元，如果为0则关闭活动"
                                                       value="<?php echo C('CONFIG_ZCZS');?>">
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>

                    </form>
                    <div class="form-actions">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col-md-offset-3 col-md-9">
                                        <button type="button" class="btn green"  id="settings_save">保存</button>
                                        <button type="button" class="btn default">重置</button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6"> </div>
                        </div>
                    </div>
                </div>
            </div>-->
        </div>
    </div>


<!-- 开始 JAVASCRIPT 页面级 插件 -->



<!-- 结束 JAVASCRIPT 页面级 插件 -->

<!-- 开始 JAVASCRIPT 页面级 代码 -->

    <script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Setting/index.js"></script>

<!-- 结束 JAVASCRIPT 页面级 代码 -->