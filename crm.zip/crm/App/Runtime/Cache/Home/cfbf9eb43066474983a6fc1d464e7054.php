<?php if (!defined('THINK_PATH')) exit();?>
<!-- 开始 CSS 页面级 插件 -->

<!-- 结束 CSS 页面级 插件 -->

    <div class="row <?php echo C('ANIMATED');?>">
        <div class="col-md-3" >
            <div class="portlet light bordered">
                <div class="portlet-title tabbable-line">
                    <div class="caption font-green-sharp">
                        <i class="fa fa-list font-green-sharp"></i>
                        <span class="caption-subject font-green-sharp bold uppercase" >问题分级</span>
                    </div>
                </div>
                <div class="portlet-body form">
                    <ul id="tree" class="ztree" style="width:350px; overflow:auto;"></ul>
                </div>
            </div>
        </div>

        <div class="col-md-9">
            <div class="portlet light bordered">
                <div class="portlet-title tabbable-line">
                    <div class="caption font-green-sharp">
                        <i class="fa fa-table font-green-sharp"></i>
                        <span class="caption-subject font-green-sharp bold uppercase" id="helpTitleShow" >所有内容</span>
                        <input id="help" type="hidden">
                    </div>
                </div>
                <div class="portlet-body form" id="helpTable">

                </div>
            </div>
        </div>
    </div>


<!-- 开始 JAVASCRIPT 页面级 插件 -->


<!-- 结束 JAVASCRIPT 页面级 插件 -->

<!-- 开始 JAVASCRIPT 页面级 代码 -->

    <script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Operator/index.js"></script>

<!-- 结束 JAVASCRIPT 页面级 代码 -->