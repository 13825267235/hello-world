<?php if (!defined('THINK_PATH')) exit();?><!-- 开始 CSS 页面级 插件 -->

<!-- 结束 CSS 页面级 插件 -->


    <div class="row <?php echo C('ANIMATED');?>">
        <div class="col-sm-12">
            <div class="table-toolbar">
                <div class="form-inline" role="form">
                    <form id="table_form">
                        <div class="form-group fui-data-wrap">
                            <div class="form-inline">
                                <div class="input-group">
                                    <input type="text" class="form-control fui-date" name="searchStatrDate" placeholder="开始日期" id="startTime" >
                                    <span class="glyphicon glyphicon-th form-control-feedback btn" aria-hidden="true" ></span>
                                </div>
                                <button type="button" class="btn btn-default fui-date-btn" data-target="today" id="today">今日</button>
                                <button type="button" class="btn btn-default fui-date-btn" data-target="yesterday" id="yesterday">昨日</button>
                                <button type="button" class="btn btn-default fui-date-btn" data-target="thisWeek" id="thisWeek">本周</button>
                                <button type="button" class="btn btn-default fui-date-btn" data-target="thisWeek" id="whole">全部</button>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="username" value="" placeholder="用户名">
                                </div>
                                <div class="input-group">
                                    <input type="text" class="form-control" name="nub" value="" placeholder="卡号">
                                </div>
                                <!--<div class="input-group">-->
                                    <!--<select class="form-control" name="type">-->
                                        <!--<option value="">类型</option>-->
                                        <!--<option value="0" >正在审核</option>-->
                                        <!--<option value="1" >已认证</option>-->
                                    <!--</select>-->
                                <!--</div>-->
                                <button type="button" class="btn green" id="SearchButt">
                                    查询<i class="fa fa-search"></i>
                                </button>

                                <div class="form-inline mt5px">
                                    <div class="input-group">
                                        <input type="text" name="searchEndDate" class="form-control fui-date" placeholder="结束日期" id="endTime">
                                        <span class="glyphicon glyphicon-th form-control-feedback btn" aria-hidden="true"></span>
                                    </div>
                                    <button type="button" class="btn btn-default fui-date-btn" data-target="lastWeek" id="lastWeek">上周</button>
                                    <button type="button" class="btn btn-default fui-date-btn" data-target="thisMonth" id="thisMonth">本月</button>
                                    <button type="button" class="btn btn-default fui-date-btn" data-target="lastMonth" id="lastMonth">上月</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <table id="tb_departments"></table>

        </div>
    </div>


<!-- 开始 JAVASCRIPT 页面级 插件 -->

<!-- 结束 JAVASCRIPT 页面级 插件 -->

<!-- 开始 JAVASCRIPT 页面级 代码 -->

    <script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Payrc/index.js"></script>

<!-- 结束 JAVASCRIPT 页面级 代码 -->