<?php if (!defined('THINK_PATH')) exit();?><form id="user_see_form" method="post" action="">
    <div class="modal-dialog modal-full">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close fui-close" aria-hidden="true">&times;</button>
                <h4 class="modal-title font-green-sharp">信用卡详情</h4>
            </div>
            <div class="modal-body">

                <table class="table table-hover table-striped table-bordered Xui-table">
                    <tbody>
                    <tr>
                        <th class="text-right col-md-2">帐号：</th>
                        <td class="col-md-3" ><?php echo ($data['username']); ?></td>
                    </tr>
                    <tr>
                        <th class="text-right col-md-2">用户名：</th>
                        <td class="col-md-3" ><?php echo ($data['realname']); ?></td>
                    </tr>
                    <tr>
                        <th class="text-right col-md-2">身份证号：</th>
                        <td class="col-md-3" ><?php echo ($data['ic']); ?></td>
                    </tr>
                    <tr>
                        <th class="text-right col-md-2">银行名称：</th>
                        <td class="col-md-3" ><?php echo ($data['bank_name']); ?></td>
                    </tr>
                    <tr>
                        <th class="text-right col-md-2">银行卡号：</th>
                        <td class="col-md-3" ><?php echo ($data['account']); ?></td>
                    </tr>
                    <tr>
                        <th class="text-right col-md-2">开户地址：</th>
                        <td class="col-md-3" ><?php echo ($data['countname']); ?></td>
                    </tr>
                    <tr>
                        <th class="text-right col-md-2">预留电话：</th>
                        <td class="col-md-3" ><?php echo ($data['phone']); ?></td>
                    </tr>

                    </tbody>
                </table>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default fui-close">关闭</button>
            </div>
        </div>
    </div>
</form>