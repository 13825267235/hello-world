<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en" class="ie8 no-js">
<html lang="en" class="ie9 no-js">
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>OA后台</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="width=device-width, initial-scale=1" name="viewport" />
    <meta content="" name="description" />
    <meta content="" name="author" />

    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="<?php echo C('PUBLIC_PLUGIN');?>googleapis/googleapis.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo C('PUBLIC_PLUGIN');?>font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo C('PUBLIC_PLUGIN');?>simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo C('PUBLIC_PLUGIN');?>uniform/css/uniform.default.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
    <!--<link href="<?php echo C('PUBLIC_PLUGIN');?>custom.css" rel="stylesheet" type="text/css" />-->
    <link href="<?php echo C('PUBLIC_PLUGIN');?>animsition/animsition.css" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->

    <!-- BEGIN THEME GLOBAL STYLES -->
    


    <!-- END THEME GLOBAL STYLES -->

    <!-- BEGIN THEME LAYOUT STYLES -->
    
        <link href="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/css/layout.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/css/themes/light2.min.css" rel="stylesheet" type="text/css" id="style_color" />
        <link href="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/css/custom.min.css" rel="stylesheet" type="text/css" />
    
    <!-- END THEME LAYOUT STYLES -->

    <!-- BEGIN PAGE LEVEL STYLES -->
    
    <link rel="stylesheet" href="<?php echo C('PUBLIC_PLUGIN');?>assets/css/reset.css">
    <link rel="stylesheet" href="<?php echo C('PUBLIC_PLUGIN');?>assets/css/supersized.css">
    <link rel="stylesheet" href="<?php echo C('PUBLIC_PLUGIN');?>assets/css/style.css">

    <!-- END PAGE LEVEL STYLES -->


    

    <!--<link rel="shortcut icon" href="favicon.ico" />-->
</head>



</head>

<body class="login">






    <div class="page-container">
        <h1>OA后台</h1>

            <form class="login-form" id="login-form" action="/<?php echo C('MODEL_NAME');?>/Login/login" method="post">
            <input type="text" name="username" class="username" placeholder="请输入您的账号" nullmsg="请输入账号" datatype="*1-20" errormsg="账号最多20个字符">
            <input type="password" name="password" class="password" placeholder="请输入您的密码"  nullmsg="请输入密码" datatype="*1-10" errormsg="密码最多10个字符">
            <input type="text" name="vcode" class="vcode"  placeholder="请输入验证码" nullmsg="请验证码" datatype="*1-4" errormsg="验证码最多3个字符"/>
            <img id="vcode_image" height="36" width="85" title="看不清楚，换一张图片"
                 src="/<?php echo C('MODEL_NAME');?>/Login/getVerify"
                 class="img-rounded"
                 onclick="this.src=this.src+'?'"
                 style="position: relative;top: 0px;left: 0px;">
            <button type="submit"
                    style="position: relative;top: -14px;left: 0px;">
                点击登录
            </button>

        </form>
        <!--<div class="connect">-->
        <!--<p>Or connect with:</p>-->
        <!--<p>-->
        <!--<a class="facebook" href=""></a>-->
        <!--<a class="twitter" href=""></a>-->
        <!--</p>-->
        <!--</div>-->
    </div>





<!--<script>-->
    <!--var PAGE_ING = "<?php echo C('PAGE_ING');?>"; // 获取每页显示多少数据-->
    <!--var USERINFO = '<?php echo (json_encode($USERINFO)); ?>'; // 获取登录者的信息-->
    <!--USERINFO = eval('(' + USERINFO + ')');-->
    <!--var payWyDataCache = '<?php echo (json_encode($payWyDataCache)); ?>'; // 获取银行接口数据-->
    <!--payWyDataCache = eval('(' + payWyDataCache + ')');-->
    <!--var REQUESTIP = '<?php echo ($REQUESTIP); ?>'; // 获取ip-->
<!--</script>-->

<!--[if lt IE 9]>
<script src="<?php echo C('PUBLIC_PLUGIN');?>respond.min.js"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>excanvas.min.js"></script>
<![endif]-->

<!-- BEGIN CORE PLUGINS -->
<script src="<?php echo C('PUBLIC_PLUGIN');?>jquery.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>jquery.cookie.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>js.cookie.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>jquery.blockui.min.js" type="text/javascript"></script>
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>uniform/jquery.uniform.min.js" type="text/javascript"></script>-->
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
<!-- END CORE PLUGINS -->

<!--开始 开关 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-switch/css/bootstrap-switch.min.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
<!--结束 开关-->


<!--开始 信息弹窗-->
<link href="<?php echo C('PUBLIC_PLUGIN');?>SweetAlert/sweetalert.css" rel="stylesheet" type="text/css"/>
<script src="<?php echo C('PUBLIC_PLUGIN');?>SweetAlert/sweetalert.min.js"></script>
<!--结束 信息弹窗-->

<!-- 开始 表单验证-->
<link href="<?php echo C('PUBLIC_PLUGIN');?>Validformv5.3.2/css/style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>Validformv5.3.2/js/Validformv5.3.2.js"></script>
<!--结束 表单验证-->

<!-- 开始 弹窗-->
<link href="<?php echo C('PUBLIC_PLUGIN');?>layer-v3.0.3/layer/skin/default/layer.css" rel="stylesheet" type="text/css" />
<link href="<?php echo C('PUBLIC_PLUGIN');?>layer-v3.0.3/layer/skin/user/user.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>layer-v3.0.3/layer/layer.js"></script>
<!--结束 弹窗-->

<!-- 开始 时间 框插件 -->
<script src="<?php echo C('PUBLIC_PLUGIN');?>moment.min.js" type="text/javascript"></script>
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-datetimepicker-master/css/bootstrap-datetimepicker.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-datetimepicker-master/locale/zh-cn.js" type="text/javascript" ></script>
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-datetimepicker-master/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>-->
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-datetimepicker-master/js/bootstrap-datetimepicker.js" type="text/javascript"></script>

<!-- 结束 时间 框插件 -->

<!-- 开始 筛选 时间 插件-->
<!--<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-daterangepicker/daterangepicker.min.css" rel="stylesheet" type="text/css" />-->
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-daterangepicker/daterangepicker.js" type="text/javascript"></script>-->
<!-- 结束 筛选 时间 插件-->


<!-- 开始 bootsrap 表格 插件-->
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-table/bootstrap-table.css" rel="stylesheet" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-table/bootstrap-table.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-table/locale/bootstrap-table-zh-CN.js"></script>
<!-- 结束 bootsrap 表格 插件-->


<!-- 开始 表格 编辑器 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-editable/bootstrap-editable/css/bootstrap-editable.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-editable/bootstrap-editable/js/bootstrap-editable.js" type="text/javascript"></script>
<!--<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap3-editable-1.5.1/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet" type="text/css" />-->
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap3-editable-1.5.1/bootstrap3-editable/js/bootstrap-editable.js" type="text/javascript"></script>-->

<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-editable/bootstrap-editable/js/bootstrap-table-editable.js" type="text/javascript"></script>
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-editable/inputs-ext/address/address.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-editable/inputs-ext/address/address.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-editable/inputs-ext/wysihtml5/wysihtml5.js" type="text/javascript"></script>
<!-- 结束 表格 编辑器 -->

<!-- 开始 提示 插件 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-touchspin/bootstrap.touchspin.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-touchspin/bootstrap.touchspin.js" type="text/javascript"></script>
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap/js/bootstrap.js" type="text/javascript"></script>-->
<!-- 结束 提示 插件 -->

<!-- 开始 提示 插件 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>icheck/skins/all.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>icheck/icheck.min.js" type="text/javascript"></script>
<!-- 结束 提示 插件 -->

<!-- 开始 百度编辑器 插件 -->
<script src="<?php echo C('PUBLIC_PLUGIN');?>ueditor1_4_3_3-utf8/ueditor.config.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>ueditor1_4_3_3-utf8/ueditor.all.js" type="text/javascript"> </script>
<!--建议手动加在语言，避免在ie下有时因为加载语言失败导致编辑器加载失败-->
<!--这里加载的语言文件会覆盖你在配置项目里添加的语言类型，比如你在配置项目里配置的是英文，这里加载的中文，那最后就是中文-->
<script src="<?php echo C('PUBLIC_PLUGIN');?>ueditor1_4_3_3-utf8/lang/zh-cn/zh-cn.js" type="text/javascript"></script>
<!-- 结束 百度编辑器 插件 -->

<!-- 开始 上传 插件 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-fileinput-master/css/fileinput.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-fileinput-master/js/fileinput.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-fileinput-master/js/locales/zh.js" type="text/javascript"></script>
<!-- 结束 上传 插件 -->

<!-- 开始 树 插件 -->
<!--<link href="<?php echo C('PUBLIC_PLUGIN');?>zTree_v3-master/css/zTreeStyle/zTreeStyle.css" rel="stylesheet" type="text/css" />-->
<link href="<?php echo C('PUBLIC_PLUGIN');?>zTree_v3-master/css/metroStyle/metroStyle.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>zTree_v3-master/js/jquery.ztree.core.js" type="text/javascript"></script>
<!--带编辑功能-->
<!--<script src="<?php echo C('PUBLIC_PLUGIN');?>zTree_v3-master/js/jquery.ztree.exedit.js" type="text/javascript"></script>-->
<!-- 结束 树 插件 -->

<!-- 开始 动画数字 插件 -->
<script src="<?php echo C('PUBLIC_PLUGIN');?>counterup/jquery.waypoints.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>counterup/jquery.counterup.min.js" type="text/javascript"></script>
<!-- 开始 动画数字 插件 -->

<!-- 开始 下拉筛选 插件 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>select2/css/select2.css" rel="stylesheet" type="text/css" />
<link href="<?php echo C('PUBLIC_PLUGIN');?>select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>select2/js/select2.full.js" type="text/javascript"></script>
<!-- 开始 下拉筛选 插件 -->

<!-- 开始 自动补全 插件 -->
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-suggest/js/bootstrap-suggest.min.js" type="text/javascript"></script>
<!-- 开始 自动补全 插件 -->

<!-- 开始 下拉插件 插件 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>select2/css/select2.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo C('PUBLIC_PLUGIN');?>select2/css/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>select2/js/select2.full.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>select2/js/i18n/zh-CN.js" type="text/javascript"></script>
<!-- 开始 下拉插件 插件 -->

<!-- 开始 下拉插件 插件 -->
<link href="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-select/css/bootstrap-select.min.css" rel="stylesheet" type="text/css" />
<script src="<?php echo C('PUBLIC_PLUGIN');?>bootstrap-select/js/bootstrap-select.min.js" type="text/javascript"></script>
<!-- 开始 下拉插件 插件 -->


<!-- BEGIN THEME GLOBAL SCRIPTS -->
<script src="<?php echo C('PUBLIC_JS');?>app.js" type="text/javascript"></script>
<!-- END THEME GLOBAL SCRIPTS -->


<!-- BEGIN THEME LAYOUT SCRIPTS -->
<script src="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/js/layout.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>layouts/layout/js/demo.min.js" type="text/javascript"></script>
<script src="<?php echo C('PUBLIC_PLUGIN');?>layouts/global/scripts/quick-sidebar.min.js" type="text/javascript"></script>
<!-- END THEME LAYOUT SCRIPTS -->

<!--省级联动-->
<script src="<?php echo C('PUBLIC_JS');?>area.js" type="text/javascript"></script>
<script>
    var model_name="<?php echo C('MODEL_NAME');?>";
</script>

    <script src="<?php echo C('PUBLIC_PLUGIN');?>assets/js/supersized.3.2.7.min.js"></script>
    <script src="<?php echo C('PUBLIC_PLUGIN');?>assets/js/supersized-init.js"></script>
    <script src="<?php echo C('PUBLIC_PLUGIN');?>assets/js/scripts.js"></script>
    <script type="text/javascript" src="<?php echo C('APP'); echo C('MODEL_NAME');?>/Static/Login/login.js"></script>



</body>
</html>